﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;



namespace WindowsFormsApp1
{
    
    public partial class StudentInformation : Form
    {
        public static StudentInformation instance1;
        public DataGridView dgv;
        public Label SItotal;

        MySqlConnection conn = new MySqlConnection("server=127.0.0.1;port=3306;username=root;password=root123;database=librarydb");

        private bool dragging = false;
        private Point dragCursorPoint;
        private Point dragFormPoint;

            public StudentInformation()
        {
            InitializeComponent();
            instance1 = this;
            dgv = dataGridView1;
            SItotal = lblTotal;
        }

        private void PopulateTable()
        {
            try
            {

                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT ID,FullName,College_Dept,Address,Add_By,Date_Added FROM studentinfo", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;

                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
        }
        private void StudentInformation_Load(object sender, EventArgs e)
        {
            PopulateTable();

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                string sqlquery = "SELECT ID, FullName, College_Dept, Address, Add_By, Date_Added FROM studentinfo where ID like '" + txtSearch.Text + "%'  or FullName like '" + txtSearch.Text + "%'";

                conn.Open();

                MySqlCommand sqlCommand = new MySqlCommand(sqlquery, conn);
                MySqlDataAdapter sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                DataTable dt = new DataTable();
                sqlDataAdapter.Fill(dt);
                dataGridView1.DataSource = dt;

                lblTotal.Text = $"Total Records: {dataGridView1.RowCount}";
                conn.Close();
            }
            catch (Exception) { }
            //=========================================================================Search textbox=============================================================================
            if (dataGridView1.SelectedRows.Count > 0)
            {

                string CurrentBID = dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[0].Value.ToString();
                if (CurrentBID != null)
                {

                    pbDisplay.Image = null;
                    lblname.Text = "";
                    try
                    {
                        conn.Open();
                        MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT Student_Image, FullName FROM studentinfo where ID ='" + CurrentBID + "' ", conn);
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);


                        string name = dt.Rows[0].ItemArray[1].ToString();


                        lblname.Text = name;

                        byte[] image = (byte[])dt.Rows[0].ItemArray[0];


                        MemoryStream ms = new MemoryStream(image);
                        pbDisplay.Image = Image.FromStream(ms);

                    }
                    catch (Exception)
                    { }
                    conn.Close();
                }
            }
            //=====================================================================clear textbox=============================================================================
            if (txtSearch.Text == "")
            {
                PopulateTable();
             
                    string CurrentBID = dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[0].Value.ToString();
                  
                        pbDisplay.Image = null;
                        lblname.Text = "";
                        try
                        {
                            conn.Open();
                            MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT Student_Image, FullName FROM studentinfo where ID ='" + CurrentBID + "' ", conn);
                            DataTable dt = new DataTable();
                            adapter.Fill(dt);


                            string name = dt.Rows[0].ItemArray[1].ToString();


                            lblname.Text = name;

                            byte[] image = (byte[])dt.Rows[0].ItemArray[0];


                            MemoryStream ms = new MemoryStream(image);
                            pbDisplay.Image = Image.FromStream(ms);

                        }
                        catch (Exception)
                        { }
                        conn.Close();
                    
                
            }
        }
        #region move windows
        private void label7_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void panel3_MouseDown(object sender, MouseEventArgs e)
        {
            dragging = true;
            dragCursorPoint = Cursor.Position;
            dragFormPoint = this.Location;
        }

        private void panel3_MouseUp(object sender, MouseEventArgs e)
        {
            dragging = false;
        }

        private void panel3_MouseMove(object sender, MouseEventArgs e)
        {
            if (dragging)
            {
                Point dif = Point.Subtract(Cursor.Position, new Size(dragCursorPoint));
                this.Location = Point.Add(dragFormPoint, new Size(dif));
            }
        }
        #endregion
        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {

            if (dataGridView1.SelectedRows.Count > 0)
            {
                
                string CurrentBID = dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[0].Value.ToString();
                if (CurrentBID != null)
                {

                    pbDisplay.Image = null;
                    lblname.Text = "";
                    try
                    {
                        conn.Open();
                        MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT Student_Image, FullName FROM studentinfo where ID ='" + CurrentBID + "' ", conn);
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);


                        string name = dt.Rows[0].ItemArray[1].ToString();


                        lblname.Text = name;

                        byte[] image = (byte[])dt.Rows[0].ItemArray[0];


                        MemoryStream ms = new MemoryStream(image);
                        pbDisplay.Image = Image.FromStream(ms);

                    }
                    catch (Exception)
                    { }
                    conn.Close();
                }
            }
        }
    }
}
