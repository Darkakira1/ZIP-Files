﻿
namespace WindowsFormsApp1
{
    partial class AddStudent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtSName = new System.Windows.Forms.TextBox();
            this.txtStudenNo = new System.Windows.Forms.TextBox();
            this.txtFacultyNo = new System.Windows.Forms.TextBox();
            this.txtCollegeDept = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.pbImage = new System.Windows.Forms.PictureBox();
            this.btnAddImage = new System.Windows.Forms.Button();
            this.btnAddStuden = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtAddedBy = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbImage)).BeginInit();
            this.SuspendLayout();
            // 
            // txtSName
            // 
            this.txtSName.Location = new System.Drawing.Point(121, 46);
            this.txtSName.Name = "txtSName";
            this.txtSName.Size = new System.Drawing.Size(236, 20);
            this.txtSName.TabIndex = 0;
            // 
            // txtStudenNo
            // 
            this.txtStudenNo.Location = new System.Drawing.Point(121, 84);
            this.txtStudenNo.Name = "txtStudenNo";
            this.txtStudenNo.Size = new System.Drawing.Size(106, 20);
            this.txtStudenNo.TabIndex = 1;
            // 
            // txtFacultyNo
            // 
            this.txtFacultyNo.Location = new System.Drawing.Point(242, 84);
            this.txtFacultyNo.Name = "txtFacultyNo";
            this.txtFacultyNo.Size = new System.Drawing.Size(115, 20);
            this.txtFacultyNo.TabIndex = 2;
            // 
            // txtCollegeDept
            // 
            this.txtCollegeDept.Location = new System.Drawing.Point(121, 128);
            this.txtCollegeDept.Name = "txtCollegeDept";
            this.txtCollegeDept.Size = new System.Drawing.Size(236, 20);
            this.txtCollegeDept.TabIndex = 3;
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(121, 166);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(236, 20);
            this.txtAddress.TabIndex = 4;
            // 
            // pbImage
            // 
            this.pbImage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pbImage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbImage.Location = new System.Drawing.Point(408, 18);
            this.pbImage.Name = "pbImage";
            this.pbImage.Size = new System.Drawing.Size(138, 102);
            this.pbImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbImage.TabIndex = 6;
            this.pbImage.TabStop = false;
            // 
            // btnAddImage
            // 
            this.btnAddImage.Location = new System.Drawing.Point(440, 126);
            this.btnAddImage.Name = "btnAddImage";
            this.btnAddImage.Size = new System.Drawing.Size(75, 23);
            this.btnAddImage.TabIndex = 7;
            this.btnAddImage.Text = "Add Image";
            this.btnAddImage.UseVisualStyleBackColor = true;
            this.btnAddImage.Click += new System.EventHandler(this.btnAddImage_Click);
            // 
            // btnAddStuden
            // 
            this.btnAddStuden.Location = new System.Drawing.Point(133, 241);
            this.btnAddStuden.Name = "btnAddStuden";
            this.btnAddStuden.Size = new System.Drawing.Size(200, 52);
            this.btnAddStuden.TabIndex = 8;
            this.btnAddStuden.Text = "Add Student";
            this.btnAddStuden.UseVisualStyleBackColor = true;
            this.btnAddStuden.Click += new System.EventHandler(this.btnAddStuden_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(77, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(139, 107);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Student No.";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(272, 107);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Faculty No.";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(39, 126);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "College/Dept.";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(36, 166);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "Home Address";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(56, 202);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "Added By ";
            // 
            // txtAddedBy
            // 
            this.txtAddedBy.Location = new System.Drawing.Point(121, 202);
            this.txtAddedBy.Name = "txtAddedBy";
            this.txtAddedBy.Size = new System.Drawing.Size(236, 20);
            this.txtAddedBy.TabIndex = 15;
            // 
            // AddStudent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(565, 330);
            this.Controls.Add(this.txtAddedBy);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnAddStuden);
            this.Controls.Add(this.btnAddImage);
            this.Controls.Add(this.pbImage);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.txtCollegeDept);
            this.Controls.Add(this.txtFacultyNo);
            this.Controls.Add(this.txtStudenNo);
            this.Controls.Add(this.txtSName);
            this.Name = "AddStudent";
            this.Text = "AddStudent";
            ((System.ComponentModel.ISupportInitialize)(this.pbImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtSName;
        private System.Windows.Forms.TextBox txtStudenNo;
        private System.Windows.Forms.TextBox txtFacultyNo;
        private System.Windows.Forms.TextBox txtCollegeDept;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.PictureBox pbImage;
        private System.Windows.Forms.Button btnAddImage;
        private System.Windows.Forms.Button btnAddStuden;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtAddedBy;
    }
}