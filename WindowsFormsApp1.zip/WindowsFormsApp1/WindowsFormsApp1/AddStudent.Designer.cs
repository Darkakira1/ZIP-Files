﻿
namespace WindowsFormsApp1
{
    partial class AddStudent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtSName = new System.Windows.Forms.TextBox();
            this.txtStudenNo = new System.Windows.Forms.TextBox();
            this.txtFacultyNo = new System.Windows.Forms.TextBox();
            this.txtCollegeDept = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.pbImage = new System.Windows.Forms.PictureBox();
            this.btnAddImage = new System.Windows.Forms.Button();
            this.btnAddStuden = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtAddedBy = new System.Windows.Forms.TextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.txtName_edit = new System.Windows.Forms.TextBox();
            this.txtAddedBy_edit = new System.Windows.Forms.TextBox();
            this.txtSID_edit = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtFID_Edit = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtDept_edit = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtAddress_edit = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.pbImage_edit = new System.Windows.Forms.PictureBox();
            this.label11 = new System.Windows.Forms.Label();
            this.btnChangeImage_edit = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.btnInformation_edit = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.btnTutorial = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pbImage)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbImage_edit)).BeginInit();
            this.SuspendLayout();
            // 
            // txtSName
            // 
            this.txtSName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtSName.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSName.Location = new System.Drawing.Point(143, 64);
            this.txtSName.Name = "txtSName";
            this.txtSName.Size = new System.Drawing.Size(236, 25);
            this.txtSName.TabIndex = 1;
            // 
            // txtStudenNo
            // 
            this.txtStudenNo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtStudenNo.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStudenNo.Location = new System.Drawing.Point(143, 111);
            this.txtStudenNo.Name = "txtStudenNo";
            this.txtStudenNo.Size = new System.Drawing.Size(106, 25);
            this.txtStudenNo.TabIndex = 2;
            // 
            // txtFacultyNo
            // 
            this.txtFacultyNo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtFacultyNo.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFacultyNo.Location = new System.Drawing.Point(264, 111);
            this.txtFacultyNo.Name = "txtFacultyNo";
            this.txtFacultyNo.Size = new System.Drawing.Size(115, 25);
            this.txtFacultyNo.TabIndex = 3;
            // 
            // txtCollegeDept
            // 
            this.txtCollegeDept.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtCollegeDept.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCollegeDept.Location = new System.Drawing.Point(143, 165);
            this.txtCollegeDept.Name = "txtCollegeDept";
            this.txtCollegeDept.Size = new System.Drawing.Size(236, 25);
            this.txtCollegeDept.TabIndex = 4;
            // 
            // txtAddress
            // 
            this.txtAddress.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtAddress.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress.Location = new System.Drawing.Point(143, 208);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(236, 25);
            this.txtAddress.TabIndex = 5;
            // 
            // pbImage
            // 
            this.pbImage.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pbImage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pbImage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbImage.Location = new System.Drawing.Point(419, 63);
            this.pbImage.Name = "pbImage";
            this.pbImage.Size = new System.Drawing.Size(152, 119);
            this.pbImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbImage.TabIndex = 6;
            this.pbImage.TabStop = false;
            // 
            // btnAddImage
            // 
            this.btnAddImage.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAddImage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddImage.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddImage.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnAddImage.Location = new System.Drawing.Point(447, 188);
            this.btnAddImage.Name = "btnAddImage";
            this.btnAddImage.Size = new System.Drawing.Size(92, 28);
            this.btnAddImage.TabIndex = 0;
            this.btnAddImage.Text = "Add Image";
            this.btnAddImage.UseVisualStyleBackColor = true;
            this.btnAddImage.Click += new System.EventHandler(this.btnAddImage_Click);
            // 
            // btnAddStuden
            // 
            this.btnAddStuden.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnAddStuden.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddStuden.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddStuden.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnAddStuden.Location = new System.Drawing.Point(155, 328);
            this.btnAddStuden.Name = "btnAddStuden";
            this.btnAddStuden.Size = new System.Drawing.Size(200, 52);
            this.btnAddStuden.TabIndex = 7;
            this.btnAddStuden.Text = "Add Members";
            this.btnAddStuden.UseVisualStyleBackColor = true;
            this.btnAddStuden.Click += new System.EventHandler(this.btnAddStuden_Click);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label1.Location = new System.Drawing.Point(95, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 16);
            this.label1.TabIndex = 9;
            this.label1.Text = "Name";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label2.Location = new System.Drawing.Point(161, 140);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 16);
            this.label2.TabIndex = 10;
            this.label2.Text = "Student No.";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label3.Location = new System.Drawing.Point(294, 140);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 16);
            this.label3.TabIndex = 11;
            this.label3.Text = "Faculty No.";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label4.Location = new System.Drawing.Point(51, 165);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 16);
            this.label4.TabIndex = 12;
            this.label4.Text = "College/Dept.";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label5.Location = new System.Drawing.Point(44, 209);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(93, 16);
            this.label5.TabIndex = 13;
            this.label5.Text = "Home Address";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label6.Location = new System.Drawing.Point(68, 254);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 16);
            this.label6.TabIndex = 14;
            this.label6.Text = "Added By ";
            // 
            // txtAddedBy
            // 
            this.txtAddedBy.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtAddedBy.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddedBy.Location = new System.Drawing.Point(143, 254);
            this.txtAddedBy.Name = "txtAddedBy";
            this.txtAddedBy.Size = new System.Drawing.Size(236, 25);
            this.txtAddedBy.TabIndex = 6;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(170, 65);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(647, 467);
            this.tabControl1.TabIndex = 15;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.tabPage1.Controls.Add(this.txtSName);
            this.tabPage1.Controls.Add(this.txtAddedBy);
            this.tabPage1.Controls.Add(this.txtStudenNo);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.txtFacultyNo);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.txtCollegeDept);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.txtAddress);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.pbImage);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.btnAddImage);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.btnAddStuden);
            this.tabPage1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(639, 438);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Add Books";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.tabPage2.Controls.Add(this.btnTutorial);
            this.tabPage2.Controls.Add(this.txtName_edit);
            this.tabPage2.Controls.Add(this.txtAddedBy_edit);
            this.tabPage2.Controls.Add(this.txtSID_edit);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.txtFID_Edit);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.txtDept_edit);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.txtAddress_edit);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.pbImage_edit);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.btnChangeImage_edit);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.btnInformation_edit);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(639, 438);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Update";
            // 
            // txtName_edit
            // 
            this.txtName_edit.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtName_edit.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName_edit.Location = new System.Drawing.Point(143, 132);
            this.txtName_edit.Name = "txtName_edit";
            this.txtName_edit.Size = new System.Drawing.Size(236, 25);
            this.txtName_edit.TabIndex = 16;
            // 
            // txtAddedBy_edit
            // 
            this.txtAddedBy_edit.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtAddedBy_edit.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddedBy_edit.Location = new System.Drawing.Point(143, 270);
            this.txtAddedBy_edit.Name = "txtAddedBy_edit";
            this.txtAddedBy_edit.Size = new System.Drawing.Size(236, 25);
            this.txtAddedBy_edit.TabIndex = 21;
            // 
            // txtSID_edit
            // 
            this.txtSID_edit.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtSID_edit.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSID_edit.Location = new System.Drawing.Point(143, 57);
            this.txtSID_edit.Name = "txtSID_edit";
            this.txtSID_edit.Size = new System.Drawing.Size(106, 25);
            this.txtSID_edit.TabIndex = 17;
            this.txtSID_edit.TextChanged += new System.EventHandler(this.txtSID_edit_TextChanged);
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label7.Location = new System.Drawing.Point(68, 270);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 16);
            this.label7.TabIndex = 29;
            this.label7.Text = "Added By ";
            // 
            // txtFID_Edit
            // 
            this.txtFID_Edit.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtFID_Edit.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFID_Edit.Location = new System.Drawing.Point(264, 57);
            this.txtFID_Edit.Name = "txtFID_Edit";
            this.txtFID_Edit.Size = new System.Drawing.Size(115, 25);
            this.txtFID_Edit.TabIndex = 18;
            this.txtFID_Edit.TextChanged += new System.EventHandler(this.txtFID_Edit_TextChanged);
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label8.Location = new System.Drawing.Point(44, 225);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(93, 16);
            this.label8.TabIndex = 28;
            this.label8.Text = "Home Address";
            // 
            // txtDept_edit
            // 
            this.txtDept_edit.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtDept_edit.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDept_edit.Location = new System.Drawing.Point(143, 174);
            this.txtDept_edit.Name = "txtDept_edit";
            this.txtDept_edit.Size = new System.Drawing.Size(236, 25);
            this.txtDept_edit.TabIndex = 19;
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label9.Location = new System.Drawing.Point(51, 174);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(86, 16);
            this.label9.TabIndex = 27;
            this.label9.Text = "College/Dept.";
            // 
            // txtAddress_edit
            // 
            this.txtAddress_edit.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtAddress_edit.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress_edit.Location = new System.Drawing.Point(143, 224);
            this.txtAddress_edit.Name = "txtAddress_edit";
            this.txtAddress_edit.Size = new System.Drawing.Size(236, 25);
            this.txtAddress_edit.TabIndex = 20;
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label10.Location = new System.Drawing.Point(294, 86);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(75, 16);
            this.label10.TabIndex = 26;
            this.label10.Text = "Faculty No.";
            // 
            // pbImage_edit
            // 
            this.pbImage_edit.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pbImage_edit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pbImage_edit.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbImage_edit.Location = new System.Drawing.Point(419, 70);
            this.pbImage_edit.Name = "pbImage_edit";
            this.pbImage_edit.Size = new System.Drawing.Size(152, 119);
            this.pbImage_edit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbImage_edit.TabIndex = 22;
            this.pbImage_edit.TabStop = false;
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label11.Location = new System.Drawing.Point(161, 86);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(77, 16);
            this.label11.TabIndex = 25;
            this.label11.Text = "Student No.";
            // 
            // btnChangeImage_edit
            // 
            this.btnChangeImage_edit.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnChangeImage_edit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChangeImage_edit.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChangeImage_edit.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnChangeImage_edit.Location = new System.Drawing.Point(441, 195);
            this.btnChangeImage_edit.Name = "btnChangeImage_edit";
            this.btnChangeImage_edit.Size = new System.Drawing.Size(106, 28);
            this.btnChangeImage_edit.TabIndex = 15;
            this.btnChangeImage_edit.Text = "Change Image";
            this.btnChangeImage_edit.UseVisualStyleBackColor = true;
            this.btnChangeImage_edit.Click += new System.EventHandler(this.btnChangeImage_edit_Click);
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label12.Location = new System.Drawing.Point(95, 135);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(42, 16);
            this.label12.TabIndex = 24;
            this.label12.Text = "Name";
            // 
            // btnInformation_edit
            // 
            this.btnInformation_edit.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnInformation_edit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInformation_edit.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInformation_edit.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnInformation_edit.Location = new System.Drawing.Point(155, 335);
            this.btnInformation_edit.Name = "btnInformation_edit";
            this.btnInformation_edit.Size = new System.Drawing.Size(200, 52);
            this.btnInformation_edit.TabIndex = 23;
            this.btnInformation_edit.Text = "Update Information";
            this.btnInformation_edit.UseVisualStyleBackColor = true;
            this.btnInformation_edit.Click += new System.EventHandler(this.btnInformation_edit_Click);
            // 
            // btnTutorial
            // 
            this.btnTutorial.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTutorial.Location = new System.Drawing.Point(98, 57);
            this.btnTutorial.Name = "btnTutorial";
            this.btnTutorial.Size = new System.Drawing.Size(23, 25);
            this.btnTutorial.TabIndex = 30;
            this.btnTutorial.Text = "?";
            this.toolTip1.SetToolTip(this.btnTutorial, "Search By using Student No. Or Faculty No.");
            this.btnTutorial.UseVisualStyleBackColor = true;
            this.btnTutorial.Click += new System.EventHandler(this.btnTutorial_Click);
            // 
            // AddStudent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(42)))), ((int)(((byte)(55)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(967, 626);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AddStudent";
            this.Text = "AddStudent";
            this.Load += new System.EventHandler(this.AddStudent_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbImage)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbImage_edit)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtSName;
        private System.Windows.Forms.TextBox txtStudenNo;
        private System.Windows.Forms.TextBox txtFacultyNo;
        private System.Windows.Forms.TextBox txtCollegeDept;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.PictureBox pbImage;
        private System.Windows.Forms.Button btnAddImage;
        private System.Windows.Forms.Button btnAddStuden;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtAddedBy;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox txtName_edit;
        private System.Windows.Forms.TextBox txtAddedBy_edit;
        private System.Windows.Forms.TextBox txtSID_edit;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtFID_Edit;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtDept_edit;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtAddress_edit;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PictureBox pbImage_edit;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnChangeImage_edit;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnInformation_edit;
        private System.Windows.Forms.Button btnTutorial;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}