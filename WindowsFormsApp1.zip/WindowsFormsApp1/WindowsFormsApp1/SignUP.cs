﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp1
{
    public partial class SignUP : Form
    {
        MySqlConnection conn = new MySqlConnection("server=127.0.0.1;port=3306;username=root;password=root123;database=librarydb");


        public SignUP()
        {
            InitializeComponent();
        }


        private void SignUP_Load(object sender, EventArgs e)
        {

        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            string user = txtUName.Text;
            string pword = txtPword.Text;
            string sagot = txtAnswer.Text;



            bool isvalid = true;
            

            if (user.Trim().Length <= 2 && pword.Trim().Length <=2)
            {
                MessageBox.Show("Please Enter Username Or Password");
                isvalid = false;
            }

            if (sagot == "")
            {
                MessageBox.Show("Answer Cannot Be Empty");
                isvalid = false;
            }


            if (isvalid)
            {
                conn.Open();

                string cmdstring = "Insert Into table_account(Username,Password,Answer) Values (@uname, @pword,@answer)";
                MySqlCommand cmd = new MySqlCommand(cmdstring, conn);
                cmd.Parameters.AddWithValue("@uname", user);
                cmd.Parameters.AddWithValue("@pword", pword);
                cmd.Parameters.AddWithValue("@answer", sagot);

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Account Created");
                    conn.Close();
                }
                catch (Exception exx)
                {
                    MessageBox.Show("" + exx);
                }
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void txtUName_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
