﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp1
{
    public partial class DashboardButton : Form
    {
        MySqlConnection conn = new MySqlConnection("server=127.0.0.1;port=3306;username=root;password=root123;database=librarydb");


        public static DashboardButton instance2;
        public Label bookstotal;
        public Label studenttotal;
        public Label facultytotal;
        public Label issuedtotal;
        public Label returntotal;
        public Label expiredtotal;


        public DashboardButton()
        {
            InitializeComponent();


            instance2 = this;


            bookstotal = lblBookstotal;
            studenttotal = lblStudenttotal;
            facultytotal = lblFacultyTotal;
            issuedtotal = lblIssuedTotal;
            returntotal = lblReturnTotal;
            expiredtotal = lblTotalExpired;
        }

        
        private void DashboardButton_Load(object sender, EventArgs e)
        {
            //============================================================books total ===========================================================
            try
            {

                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("Select ISBN_no as 'ISBN No',Name_of_Book as 'Book Tittle',Book_Author as 'Author',Book_Categories as 'Categories',Book_Status as 'Status', Book_quantity as 'Quantity' From table_inventorybooks Where NOT Book_Status = 'Lost'", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);



                lblBookstotal.Text = dt.Rows.Count.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            conn.Close();
            //========================================================== student total =========================================================================

            try
            {

                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT * FROM studentinfo", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                lblStudenttotal.Text = dt.Rows.Count.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            conn.Close();

            //========================================================== Faculty total =============================================================
           
            try
            {

                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT * FROM facultyinfo", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                lblFacultyTotal.Text = dt.Rows.Count.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            conn.Close();
            //======================================================== Book Issued Total =========================================================
            try
            {

                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT IDissued as 'Issued No', Student_name as 'Person Name', Book_Tittle as 'Book Tittle', Book_Issued as 'Book Issued', Book_Return as 'Book Return'  FROM bookissued Where  Book_Status = 'Borrowed' ", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                lblIssuedTotal.Text = dt.Rows.Count.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            conn.Close();
            //======================================================== Book Return Total ==========================================================
            try
            {

                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT IDissued as 'Issued No', Student_name as 'Person Name', Book_Tittle as 'Book Tittle', Book_Issued as 'Book Issued', Book_Return as 'Book Return'  FROM bookissued Where  Book_Status = 'Return' ", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                lblReturnTotal.Text = dt.Rows.Count.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            conn.Close();
            //======================================================== Book Expired Total ============================================================
            try
            {

                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT IDissued as 'Issued No', Student_name as 'Person Name', Book_Tittle as 'Book Tittle', Book_Issued as 'Book Issued', Book_Return as 'Book Return'  FROM bookissued Where  Book_Status = 'OverDue' ", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                lblTotalExpired.Text = dt.Rows.Count.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            conn.Close();
        }
    }
}
