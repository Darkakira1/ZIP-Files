﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class BooksInformation : Form
    {
        public static BooksInformation instance;
        public ComboBox cbcategories;
        public DataGridView dgv;
        public Label BItotal;


        MySqlConnection conn = new MySqlConnection("server=127.0.0.1;port=3306;username=root;password=root123;database=librarydb");



        public BooksInformation()
        {
            InitializeComponent();
            instance = this;
            cbcategories = comboBox1;
            dgv = dataGridView1;
            BItotal = lblTotal;
        }

        private void PopulateTable()
        {
            try
            {
                
                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("Select ISBN_no as 'ISBN No',Name_of_Book as 'Book Tittle',Book_Author as 'Author',Book_Categories as 'Categories',Book_Status as 'Status' From table_inventorybooks Where NOT Book_Status = 'Lost'", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;
                lblTotal.Text = $"Total Records: {dataGridView1.RowCount}";

                
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
        }
        private void BooksInformation_Load(object sender, EventArgs e)
        {
            PopulateTable();

           
           
        //=====================================++++++++Combobox Book Categories+++++++===============================================
  

            try
            {
                string sqlquery = "Select Distinct Book_Categories From table_inventorybooks Where NOT Book_Status = 'Lost'";
                conn.Open();
                MySqlCommand command = new MySqlCommand(sqlquery, conn);
                MySqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    comboBox1.Items.Add(reader.GetString("Book_Categories"));
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("error" + ex);

            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

            string sqlquery = "Select ISBN_no as 'ISBN No',Name_of_Book as 'Book Tittle',Book_Author as 'Author',Book_Categories as 'Categories',Book_Status as 'Status'From table_inventorybooks where ISBN_no like '" + txtSearch.Text + "%' AND NOT Book_Status = 'Lost' or Name_of_Book like '" + txtSearch.Text + "%' AND NOT Book_Status = 'Lost'  ";
            conn.Open();

            MySqlCommand sqlCommand = new MySqlCommand(sqlquery, conn);
            MySqlDataAdapter sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            DataTable dt = new DataTable();
            sqlDataAdapter.Fill(dt);
            dataGridView1.DataSource = dt;

            lblTotal.Text = $"Total Records: {dataGridView1.RowCount}";
            conn.Close();

            if (txtSearch.Text == "")
            {
                PopulateTable();
            }
        }

        public void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {


            conn.Open();
            string sqlquery = "Select ISBN_no as 'ISBN No',Name_of_Book as 'Book Tittle',Book_Author as 'Author',Book_Categories as 'Categories',Book_Status as 'Status' From table_inventorybooks where Book_Categories like '" + cbcategories.Text + "' AND NOT Book_Status = 'Lost' ";
            

            MySqlCommand sqlCommand = new MySqlCommand(sqlquery, conn);
            MySqlDataAdapter sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            DataTable dt = new DataTable();
            sqlDataAdapter.Fill(dt);
            dataGridView1.DataSource = dt;

            lblTotal.Text = $"Total Records: {dataGridView1.RowCount}";
            conn.Close();

            


        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            PopulateTable();

            try
            {
                string sqlquery = "Select Distinct Book_Categories From table_inventorybooks Where NOT Book_Status = 'Lost'";
                conn.Open();
                MySqlCommand command = new MySqlCommand(sqlquery, conn);
                MySqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    comboBox1.Items.IsReadOnly.ToString() ;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("error" + ex);

            }
        }
    }
}
