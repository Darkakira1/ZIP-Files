﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApp1
{


    public partial class BooksInformation : Form
    {
        public static BooksInformation instance;
        public ComboBox cbcategories;
        public DataGridView dgv;
        public Label BItotal;


        MySqlConnection conn = new MySqlConnection("server=127.0.0.1;port=3306;username=root;password=root123;database=librarydb");


        

        public BooksInformation()
        {
            InitializeComponent();
            instance = this;
            cbcategories = cbCategories_Choose;
            dgv = dataGridView1;
            BItotal = lblTotal;
        }

        private void PopulateTable()
        {
            try
            {
                
                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("Select Accession‎_No as 'Accession No',  Name_of_Book as 'Book Tittle', Book_quantity as 'Book Quantity', Book_Status as 'Status' From table_inventorybooks Where NOT Book_Status = 'Lost'", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;
                lblTotal.Text = $"Totals: {dataGridView1.RowCount}";  

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            conn.Close();
        }
        private void BooksInformation_Load(object sender, EventArgs e)
        {
            PopulateTable();
            cbCategories_Choose.SelectedIndex = 0;

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            cbCategories_Choose.SelectedIndex = 0;

           

            try
            {
                string sqlquery = "Select Accession‎_No as 'Accession No',  Name_of_Book as 'Book Tittle', Book_quantity as 'Book Quantity', Book_Status as 'Status' From table_inventorybooks where Accession‎_No like '" + txtSearch.Text + "%' AND NOT Book_Status = 'Lost' or Name_of_Book like '%" + txtSearch.Text + "%' AND NOT Book_Status = 'Lost' ";
                conn.Open();

                MySqlCommand sqlCommand = new MySqlCommand(sqlquery, conn);
                MySqlDataAdapter sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                DataTable dt = new DataTable();
                sqlDataAdapter.Fill(dt);
                dataGridView1.DataSource = dt;
                lblTotal.Text = $"Totals: {dataGridView1.RowCount}";
                
            }catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            conn.Close();
            //=====================================================================================++++Searching Books+++++====================================================================================
            lblTittle.Text = "";
            lblAuthor.Text = "";
            lblAccessionNo.Text = "";
            lblISBN.Text = "";
            lblCallno.Text = "";
            lblCategories.Text = "";
            lblPublisher.Text = "";
            lblYearPublish.Text = "";
            if (dataGridView1 != null && dataGridView1.SelectedRows.Count > 0)
            {
                string CurrentBID = dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[0].Value.ToString();
                if (CurrentBID != null)
                {
                    try
                    {
                        conn.Open();                                          //  0-----------1----------2---------------3--------4---------5-----------------6---------------7-------------8-------------9----------10-------------
                        MySqlDataAdapter query = new MySqlDataAdapter("Select Accession‎_No, ISBN_no, Name_of_Book, Book_Author, Call_No, Book_Publish, Book_Categories, Book_quantity, Book_Status, Book_Image, Publisher_name From table_inventorybooks Where Accession‎_No = " + CurrentBID, conn);
                        DataTable dt = new DataTable();
                        query.Fill(dt);


                        pbBookImage.Image = null;
                       

                        string accession = dt.Rows[0].ItemArray[0].ToString();
                        string ISBN = dt.Rows[0].ItemArray[1].ToString();
                        string tittle = dt.Rows[0].ItemArray[2].ToString();
                        string author = dt.Rows[0].ItemArray[3].ToString();
                        string callno = dt.Rows[0].ItemArray[4].ToString();
                        string publish = dt.Rows[0].ItemArray[5].ToString();
                        string categories = dt.Rows[0].ItemArray[6].ToString();

                        string publisher = dt.Rows[0].ItemArray[10].ToString();




                        lblAccessionNo.Text = accession;
                        lblISBN.Text = ISBN;
                        lblTittle.Text = tittle;
                        lblAuthor.Text = author;
                        lblCallno.Text = callno;
                        lblYearPublish.Text = publish;
                        lblCategories.Text = categories;
                        lblPublisher.Text = publisher;
                        //rtbDescription.Text = descrip;


                        byte[] image = (byte[])dt.Rows[0].ItemArray[9];
                        MemoryStream ms = new MemoryStream(image);
                        pbBookImage.Image = Image.FromStream(ms);

                    }
                    catch (Exception)
                    { }
                    conn.Close();
                }
            }
            //=================================================================================++++Clear TextBox+++++++=========================================================================
            if (txtSearch.Text == "")
            {
                PopulateTable();

                if (dataGridView1 != null && dataGridView1.SelectedRows.Count > 0)
                {
                    string CurrentBID = dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[0].Value.ToString();
                    if (CurrentBID != null)
                    {
                        try
                        {
                            

                            conn.Open();                                          //  0-----------1----------2---------------3--------4---------5-----------------6---------------7-------------8-------------9----------10-------------
                            MySqlDataAdapter query = new MySqlDataAdapter("Select Accession‎_No, ISBN_no, Name_of_Book, Book_Author, Call_No, Book_Publish, Book_Categories, Book_quantity, Book_Status, Book_Image, Publisher_name From table_inventorybooks Where Accession‎_No = " + CurrentBID, conn);
                            DataTable dt = new DataTable();
                            query.Fill(dt);


                            pbBookImage.Image = null;
                            lblTittle.Text = "";
                            lblAuthor.Text = "";
                            //lblPublish.Text = "";
                            //rtbDescription.Text = "";

                            string accession = dt.Rows[0].ItemArray[0].ToString();
                            string ISBN = dt.Rows[0].ItemArray[1].ToString();
                            string tittle = dt.Rows[0].ItemArray[2].ToString();
                            string author = dt.Rows[0].ItemArray[3].ToString();
                            string callno = dt.Rows[0].ItemArray[4].ToString();
                            string publish = dt.Rows[0].ItemArray[5].ToString();
                            string categories = dt.Rows[0].ItemArray[6].ToString();

                            string publisher = dt.Rows[0].ItemArray[10].ToString();




                            lblAccessionNo.Text = accession;
                            lblISBN.Text = ISBN;
                            lblTittle.Text = tittle;
                            lblAuthor.Text = author;
                            lblCallno.Text = callno;
                            lblYearPublish.Text = publish;
                            lblCategories.Text = categories;
                            lblPublisher.Text = publisher;
                            //rtbDescription.Text = descrip;


                            byte[] image = (byte[])dt.Rows[0].ItemArray[9];
                            MemoryStream ms = new MemoryStream(image);
                            pbBookImage.Image = Image.FromStream(ms);

                        }
                        catch (Exception)
                        { }
                        conn.Close();
                    }
                }
            }

        }


        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {


            lblTittle.Text = "";
            lblAuthor.Text = "";
            lblAccessionNo.Text = "";
            lblISBN.Text = "";
            lblCallno.Text = "";
            lblCategories.Text = "";
            lblPublisher.Text = "";
            lblYearPublish.Text = "";
            if (dataGridView1 != null && dataGridView1.SelectedRows.Count > 0 )
            {  
                string CurrentBID = dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[0].Value.ToString();
                if (CurrentBID != null)
                {
                    try
                    {
                        conn.Open();                                          //  0-----------1----------2---------------3--------4---------5-----------------6---------------7-------------8-------------9----------10-------------
                        MySqlDataAdapter query = new MySqlDataAdapter("Select Accession‎_No, ISBN_no, Name_of_Book, Book_Author, Call_No, Book_Publish, Book_Categories, Book_quantity, Book_Status, Book_Image, Publisher_name From table_inventorybooks Where Accession‎_No = " + CurrentBID, conn);
                        DataTable dt = new DataTable();
                        query.Fill(dt);


                        pbBookImage.Image = null;
                        lblTittle.Text = "";
                        lblAuthor.Text = "";
                        //lblPublish.Text = "";
                        //rtbDescription.Text = "";

                        string accession = dt.Rows[0].ItemArray[0].ToString();
                        string ISBN = dt.Rows[0].ItemArray[1].ToString();
                        string tittle = dt.Rows[0].ItemArray[2].ToString();
                        string author = dt.Rows[0].ItemArray[3].ToString();
                        string callno = dt.Rows[0].ItemArray[4].ToString();
                        string publish = dt.Rows[0].ItemArray[5].ToString();
                        string categories = dt.Rows[0].ItemArray[6].ToString();

                        string publisher = dt.Rows[0].ItemArray[10].ToString();




                        lblAccessionNo.Text = accession;
                        lblISBN.Text = ISBN;
                        lblTittle.Text = tittle;
                        lblAuthor.Text = author;
                        lblCallno.Text = callno;
                        lblYearPublish.Text = publish;
                        lblCategories.Text = categories;
                        lblPublisher.Text = publisher;
                        //rtbDescription.Text = descrip;


                        byte[] image = (byte[])dt.Rows[0].ItemArray[9];
                        MemoryStream ms = new MemoryStream(image);
                        pbBookImage.Image = Image.FromStream(ms);
                       
                    }
                    catch (Exception)
                    {  }
                    conn.Close();
                }
            }
          
        }

        private void cbCategories_Choose_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            try
            {
                string sqlquery = "Select Accession‎_No as 'Accession No',  Name_of_Book as 'Book Tittle', Book_quantity as 'Book Quantity', Book_Status as 'Status' From table_inventorybooks where Book_Categories like '" + cbCategories_Choose.Text + "%' AND NOT Book_Status = 'Lost' ";
                conn.Open();

                MySqlCommand sqlCommand = new MySqlCommand(sqlquery, conn);
                MySqlDataAdapter sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                DataTable dt = new DataTable();
                sqlDataAdapter.Fill(dt);
                dataGridView1.DataSource = dt;

                lblTotal.Text = $"Totals: {dataGridView1.RowCount}";
            }
            catch (Exception)
            { }
            conn.Close();

            //=====================================================================================++++Selected Row+++++====================================================================================
            lblTittle.Text = "";
            lblAuthor.Text = "";
            lblAccessionNo.Text = "";
            lblISBN.Text = "";
            lblCallno.Text = "";
            lblCategories.Text = "";
            lblPublisher.Text = "";
            lblYearPublish.Text = "";
            if (dataGridView1 != null && dataGridView1.SelectedRows.Count > 0)
            {

                string CurrentBID = dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[0].Value.ToString();
                if (CurrentBID != null)
                {
                    try
                    {
                        conn.Open();                                          //  0-----------1----------2---------------3--------4---------5-----------------6---------------7-------------8-------------9----------10-------------
                        MySqlDataAdapter query = new MySqlDataAdapter("Select Accession‎_No, ISBN_no, Name_of_Book, Book_Author, Call_No, Book_Publish, Book_Categories, Book_quantity, Book_Status, Book_Image, Publisher_name From table_inventorybooks Where Accession‎_No = " + CurrentBID, conn);
                        DataTable dt = new DataTable();
                        query.Fill(dt);


                        pbBookImage.Image = null;
                        lblTittle.Text = "";
                        lblAuthor.Text = "";
                        //lblPublish.Text = "";
                        //rtbDescription.Text = "";

                        string accession = dt.Rows[0].ItemArray[0].ToString();
                        string ISBN = dt.Rows[0].ItemArray[1].ToString();
                        string tittle = dt.Rows[0].ItemArray[2].ToString();
                        string author = dt.Rows[0].ItemArray[3].ToString();
                        string callno = dt.Rows[0].ItemArray[4].ToString();
                        string publish = dt.Rows[0].ItemArray[5].ToString();
                        string categories = dt.Rows[0].ItemArray[6].ToString();

                        string publisher = dt.Rows[0].ItemArray[10].ToString();




                        lblAccessionNo.Text = accession;
                        lblISBN.Text = ISBN;
                        lblTittle.Text = tittle;
                        lblAuthor.Text = author;
                        lblCallno.Text = callno;
                        lblYearPublish.Text = publish;
                        lblCategories.Text = categories;
                        lblPublisher.Text = publisher;
                        //rtbDescription.Text = descrip;


                        byte[] image = (byte[])dt.Rows[0].ItemArray[9];
                        MemoryStream ms = new MemoryStream(image);
                        pbBookImage.Image = Image.FromStream(ms);

                    }
                    catch (Exception)
                    { }
                    conn.Close();
                }
            }
            //=================================================================================++++ALL Combobox+++++++=========================================================================
            if (cbCategories_Choose.Text == "All")
            {

                PopulateTable();
                if (dataGridView1 != null && dataGridView1.SelectedRows.Count > 0)
                {

                    string CurrentBID = dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[0].Value.ToString();
                    if (CurrentBID != null)
                    {

                        try
                        {

                           
                            conn.Open();                                          //  0-----------1----------2---------------3--------4---------5-----------------6---------------7-------------8-------------9----------10-------------
                            MySqlDataAdapter query = new MySqlDataAdapter("Select Accession‎_No, ISBN_no, Name_of_Book, Book_Author, Call_No, Book_Publish, Book_Categories, Book_quantity, Book_Status, Book_Image, Publisher_name From table_inventorybooks Where Accession‎_No = " + CurrentBID, conn);
                            DataTable dt = new DataTable();
                            query.Fill(dt);


                            pbBookImage.Image = null;
                            lblTittle.Text = "";
                            lblAuthor.Text = "";
                            //lblPublish.Text = "";
                            //rtbDescription.Text = "";

                            string accession = dt.Rows[0].ItemArray[0].ToString();
                            string ISBN = dt.Rows[0].ItemArray[1].ToString();
                            string tittle = dt.Rows[0].ItemArray[2].ToString();
                            string author = dt.Rows[0].ItemArray[3].ToString();
                            string callno = dt.Rows[0].ItemArray[4].ToString();
                            string publish = dt.Rows[0].ItemArray[5].ToString();
                            string categories = dt.Rows[0].ItemArray[6].ToString();

                            string publisher = dt.Rows[0].ItemArray[10].ToString();




                            lblAccessionNo.Text = accession;
                            lblISBN.Text = ISBN;
                            lblTittle.Text = tittle;
                            lblAuthor.Text = author;
                            lblCallno.Text = callno;
                            lblYearPublish.Text = publish;
                            lblCategories.Text = categories;
                            lblPublisher.Text = publisher;
                            //rtbDescription.Text = descrip;


                            byte[] image = (byte[])dt.Rows[0].ItemArray[9];
                            MemoryStream ms = new MemoryStream(image);
                            pbBookImage.Image = Image.FromStream(ms);

                        }
                        catch (Exception)
                        { }
                        conn.Close();
                    }
                }
            }

        }
    }
}
