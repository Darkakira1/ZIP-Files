﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApp1
{


    public partial class BooksInformation : Form
    {
        public static BooksInformation instance;
        public ComboBox cbcategories;
        public DataGridView dgv;
        public Label BItotal;


        MySqlConnection conn = new MySqlConnection("server=127.0.0.1;port=3306;username=root;password=root123;database=librarydb");


        

        public BooksInformation()
        {
            InitializeComponent();
            instance = this;
            cbcategories = cbCategories_Choose;
            dgv = dataGridView1;
            BItotal = lblTotal;
        }

        private void PopulateTable()
        {
            try
            {
                
                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("Select ISBN_no as 'ISBN no.',  Name_of_Book as 'Book Tittle', Book_quantity as 'Book Quantity' From table_inventorybooks Where NOT Book_Status = 'Lost'", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;
                lblTotal.Text = $"Total Records: {dataGridView1.RowCount}";

                
               

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            conn.Close();
        }
        private void BooksInformation_Load(object sender, EventArgs e)
        {
            PopulateTable();
            


            //=====================================++++++++Combobox Book Categories+++++++===============================================


            try
            {
                string sqlquery = "Select Distinct Book_Categories From table_inventorybooks Where NOT Book_Status = 'Lost'";
                conn.Open();
                MySqlCommand command = new MySqlCommand(sqlquery, conn);
                MySqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    cbCategories_Choose.Items.Add(reader.GetString("Book_Categories"));
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("error" + ex);

            }
            conn.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                string sqlquery = "Select ISBN_no as 'ISBN no.', Name_of_Book as 'Book Tittle' , Book_quantity as 'Quantity' From table_inventorybooks where ISBN_no like '" + txtSearch.Text + "%' AND NOT Book_Status = 'Lost' or Name_of_Book like '" + txtSearch.Text + "%' AND NOT Book_Status = 'Lost'  ";
                conn.Open();

                MySqlCommand sqlCommand = new MySqlCommand(sqlquery, conn);
                MySqlDataAdapter sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                DataTable dt = new DataTable();
                sqlDataAdapter.Fill(dt);
                dataGridView1.DataSource = dt;
                lblTotal.Text = $"Total Records: {dataGridView1.RowCount}";
                
            }catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            conn.Close();
//=====================================================================================++++Searching Books+++++====================================================================================
            if (dataGridView1.SelectedRows.Count > 0)
            {
                string CurrentBID = dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[0].Value.ToString();
                if (CurrentBID != null)
                {
                    try
                    {
                        conn.Open();
                        MySqlDataAdapter query = new MySqlDataAdapter("Select Book_Image, Name_of_Book, Book_Author, Book_Publish, Book_Description  From table_inventorybooks Where ISBN_no = " + CurrentBID, conn);
                        DataTable dt = new DataTable();
                        query.Fill(dt);



                        pbBookImage.Image = null;
                        lblTittle.Text = "";
                        lblAuthor.Text = "";
                        lblPublish.Text = "";
                        rtbDescription.Text = "";


                        string tittle = dt.Rows[0].ItemArray[1].ToString();
                        string author = dt.Rows[0].ItemArray[2].ToString();
                        string publish = dt.Rows[0].ItemArray[3].ToString();
                        string descrip = dt.Rows[0].ItemArray[4].ToString();

                        lblTittle.Text = tittle;
                        lblAuthor.Text = author;
                        lblPublish.Text = publish;
                        rtbDescription.Text = descrip;


                        byte[] image = (byte[])dt.Rows[0].ItemArray[0];
                        MemoryStream ms = new MemoryStream(image);
                        pbBookImage.Image = Image.FromStream(ms);

                    }
                    catch (Exception)
                    { }
                    conn.Close();
                }
            }
//=================================================================================++++Clear TextBox+++++++=========================================================================
            if (txtSearch.Text == "")
            {
                PopulateTable();
                try
                {
                    string CurrentBID = dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[0].Value.ToString();
                    conn.Open();
                    MySqlDataAdapter query = new MySqlDataAdapter("Select Book_Image, Name_of_Book, Book_Author, Book_Publish, Book_Description  From table_inventorybooks Where ISBN_no = " + CurrentBID, conn);
                    DataTable dt = new DataTable();
                    query.Fill(dt);



                    pbBookImage.Image = null;
                    lblTittle.Text = "";
                    lblAuthor.Text = "";
                    lblPublish.Text = "";
                    rtbDescription.Text = "";


                    string tittle = dt.Rows[0].ItemArray[1].ToString();
                    string author = dt.Rows[0].ItemArray[2].ToString();
                    string publish = dt.Rows[0].ItemArray[3].ToString();
                    string descrip = dt.Rows[0].ItemArray[4].ToString();

                    lblTittle.Text = tittle;
                    lblAuthor.Text = author;
                    lblPublish.Text = publish;
                    rtbDescription.Text = descrip;


                    byte[] image = (byte[])dt.Rows[0].ItemArray[0];
                    MemoryStream ms = new MemoryStream(image);
                    pbBookImage.Image = Image.FromStream(ms);

                }
                catch (Exception)
                { }
                conn.Close();
            }

        }

        public void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            try
            {
                string sqlquery = "Select ISBN_no as 'ISBN no.', Name_of_Book as 'Book Tittle' , Book_quantity as 'Quantity' From table_inventorybooks where Book_Categories like '" + cbCategories_Choose.Text + "%' AND NOT Book_Status = 'Lost' ";
                conn.Open();

                MySqlCommand sqlCommand = new MySqlCommand(sqlquery, conn);
                MySqlDataAdapter sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                DataTable dt = new DataTable();
                sqlDataAdapter.Fill(dt);
                dataGridView1.DataSource = dt;

                lblTotal.Text = $"Total Records: {dataGridView1.RowCount}";
            }
            catch (Exception)
            { }
            conn.Close();

//=====================================================================================++++Selected Row+++++====================================================================================
            if (dataGridView1.SelectedRows.Count > 0)
            {
                string CurrentBID = dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[0].Value.ToString();
                if (CurrentBID != null)
                {
                    try
                    {
                        conn.Open();
                        MySqlDataAdapter query = new MySqlDataAdapter("Select Book_Image, Name_of_Book, Book_Author, Book_Publish, Book_Description  From table_inventorybooks Where ISBN_no = " + CurrentBID, conn);
                        DataTable dt = new DataTable();
                        query.Fill(dt);



                        pbBookImage.Image = null;
                        lblTittle.Text = "";
                        lblAuthor.Text = "";
                        lblPublish.Text = "";
                        rtbDescription.Text = "";


                        string tittle = dt.Rows[0].ItemArray[1].ToString();
                        string author = dt.Rows[0].ItemArray[2].ToString();
                        string publish = dt.Rows[0].ItemArray[3].ToString();
                        string descrip = dt.Rows[0].ItemArray[4].ToString();

                        lblTittle.Text = tittle;
                        lblAuthor.Text = author;
                        lblPublish.Text = publish;
                        rtbDescription.Text = descrip;


                        byte[] image = (byte[])dt.Rows[0].ItemArray[0];
                        MemoryStream ms = new MemoryStream(image);
                        pbBookImage.Image = Image.FromStream(ms);

                    }
                    catch (Exception)
                    { }
                    conn.Close();
                }
            }
//=================================================================================++++ALL Combobox+++++++=========================================================================
            if (cbCategories_Choose.Text == "All") {

                PopulateTable();
                try
                {
                    string CurrentBID = dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[0].Value.ToString();
                    conn.Open();
                    MySqlDataAdapter query = new MySqlDataAdapter("Select Book_Image, Name_of_Book, Book_Author, Book_Publish, Book_Description  From table_inventorybooks Where ISBN_no = " + CurrentBID, conn);
                    DataTable dt = new DataTable();
                    query.Fill(dt);



                    pbBookImage.Image = null;
                    lblTittle.Text = "";
                    lblAuthor.Text = "";
                    lblPublish.Text = "";
                    rtbDescription.Text = "";


                    string tittle = dt.Rows[0].ItemArray[1].ToString();
                    string author = dt.Rows[0].ItemArray[2].ToString();
                    string publish = dt.Rows[0].ItemArray[3].ToString();
                    string descrip = dt.Rows[0].ItemArray[4].ToString();

                    lblTittle.Text = tittle;
                    lblAuthor.Text = author;
                    lblPublish.Text = publish;
                    rtbDescription.Text = descrip;


                    byte[] image = (byte[])dt.Rows[0].ItemArray[0];
                    MemoryStream ms = new MemoryStream(image);
                    pbBookImage.Image = Image.FromStream(ms);

                }
                catch (Exception)
                { }
                conn.Close();
            }
         

        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {


           // DataGridView dgv = sender as DataGridView;
            if (dataGridView1.SelectedRows.Count > 0)
            {
                string CurrentBID = dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[0].Value.ToString();
                if (CurrentBID != null)
                {
                    try
                    {

                        

                        conn.Open();
                        MySqlDataAdapter query = new MySqlDataAdapter("Select Book_Image, Name_of_Book, Book_Author, Book_Publish, Book_Description  From table_inventorybooks Where ISBN_no = " + CurrentBID, conn);
                        DataTable dt = new DataTable();
                        query.Fill(dt);



                        pbBookImage.Image = null;
                        lblTittle.Text = "";
                        lblAuthor.Text = "";
                        lblPublish.Text = "";
                        rtbDescription.Text = "";


                        string tittle = dt.Rows[0].ItemArray[1].ToString();
                        string author = dt.Rows[0].ItemArray[2].ToString();
                        string publish = dt.Rows[0].ItemArray[3].ToString();
                        string descrip = dt.Rows[0].ItemArray[4].ToString();

                        lblTittle.Text = tittle;
                        lblAuthor.Text = author;
                        lblPublish.Text = publish;
                        rtbDescription.Text = descrip;


                        byte[] image = (byte[])dt.Rows[0].ItemArray[0];
                        MemoryStream ms = new MemoryStream(image);
                        pbBookImage.Image = Image.FromStream(ms);

                    }
                    catch (Exception ex)
                    {  }
                    conn.Close();
                }
            }
          
        }
    }
}
