﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace WindowsFormsApp1
{


    public partial class AddStudent : Form
    {

        MySqlConnection conn = new MySqlConnection("server=127.0.0.1;port=3306;username=root;password=root123;database=librarydb");


        private bool dragging = false;
        private Point dragCursorPoint;
        private Point dragFormPoint;

        public AddStudent()
        {
            InitializeComponent();

        }

        public void clearfield()
        {
            txtStudenNo.Text = "";
            txtFacultyNo.Text = "";
            txtSName.Text = "";
            txtAddress.Text = "";
            txtCollegeDept.Text = "";
            txtAddedBy.Text = "";

        }

        string imgLocation = "";

        private void btnAddStuden_Click(object sender, EventArgs e)
        {
            

      
            string sID = txtStudenNo.Text;
            string fID = txtFacultyNo.Text;
            string PfullName = txtSName.Text;
            string SDept = txtCollegeDept.Text;
            string HAddress = txtAddress.Text;
            string Addby = txtAddedBy.Text;
            byte[] image = null;

            try
            {


                FileStream stream = new FileStream(imgLocation, FileMode.Open, FileAccess.Read);
                BinaryReader brs = new BinaryReader(stream);

                image = brs.ReadBytes((int)stream.Length);
            }
            catch (Exception Ex)
            {

            }

            bool isValid = true;


            if (sID.Trim().Length <= 2 && fID.Trim().Length <= 2)
            {
                MessageBox.Show("Please Enter Proper ID No. ");
                isValid = false; 
            } 
 

            if (PfullName.Trim().Length <= 4)
            {
                MessageBox.Show("Please Enter Your Full Name! ");
                isValid = false;
            }

            if (HAddress.Trim().Length <= 3)
            {
                MessageBox.Show("Address Cannot be Empty");
                isValid = false;
            }

            if (fID !="" && sID !="")
            {
                MessageBox.Show("One ID number Only");
                isValid = false;
            }

            //-----------------------------------++++++++++Adding Student Members++++++++++----------------------------------
            if (isValid && fID == "") {
                conn.Open();
              
                string cmdstring = "Insert Into studentinfo(ID,FullName,College_Dept,Address,Add_By,Student_Image) Values (@sid,@fname,@college_dept, @address,@add_by,@Simage)";
                MySqlCommand cmd = new MySqlCommand(cmdstring, conn);
                cmd.Parameters.AddWithValue("@sid", sID);
                cmd.Parameters.AddWithValue("@fname", PfullName);
                cmd.Parameters.AddWithValue("@college_dept", SDept);
                cmd.Parameters.AddWithValue("@address", HAddress);
                cmd.Parameters.AddWithValue("@add_by", Addby);

                cmd.Parameters.AddWithValue("@Simage", image);



                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Student Added!");
                    conn.Close();
                    clearfield();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error " + ex);
                }

                conn.Close();
              
            }


            //----------------------------------------++++++++++Adding Faculty Memebers+++++++++++----------------
            else if (isValid && sID =="")
            {
                conn.Open();

                string cmdstring = "Insert Into facultyinfo(FID,FullName,College_Dept,Address,Add_By,Faculty_Image) Values (@Fid,@fname,@college_dept, @address,@add_by,@Fimage)";
                MySqlCommand cmd = new MySqlCommand(cmdstring, conn);
                cmd.Parameters.AddWithValue("@Fid", fID);
                cmd.Parameters.AddWithValue("@fname", PfullName);
                cmd.Parameters.AddWithValue("@college_dept", SDept);
                cmd.Parameters.AddWithValue("@address", HAddress);
                cmd.Parameters.AddWithValue("@add_by", Addby);

                cmd.Parameters.AddWithValue("@Fimage", image);

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Faculty Added");
                    conn.Close();
                    clearfield();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error " + ex);
                }

                conn.Close();

            }



            
        }

        private void btnAddImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Choose Image(*.jpg; *.png; *.gif)|*.jpg; *.png; *.gif| All Files *.*|*.*";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                imgLocation = ofd.FileName.ToString();
                pbImage.ImageLocation = imgLocation;
            }
        }

        private void label7_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void panel3_MouseDown(object sender, MouseEventArgs e)
        {
            dragging = true;
            dragCursorPoint = Cursor.Position;
            dragFormPoint = this.Location;
        }

        private void panel3_MouseUp(object sender, MouseEventArgs e)
        {
            dragging = false;
        }

        private void panel3_MouseMove(object sender, MouseEventArgs e)
        {
            if (dragging)
            {
                Point dif = Point.Subtract(Cursor.Position, new Size(dragCursorPoint));
                this.Location = Point.Add(dragFormPoint, new Size(dif));
            }
        }
    }
}
