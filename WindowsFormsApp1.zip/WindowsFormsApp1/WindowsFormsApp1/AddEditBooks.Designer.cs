﻿
namespace WindowsFormsApp1
{
    partial class AddEditBooks
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.rtbDescription = new System.Windows.Forms.RichTextBox();
            this.pn5 = new System.Windows.Forms.Panel();
            this.txtPublish = new System.Windows.Forms.TextBox();
            this.nudQuantity = new System.Windows.Forms.NumericUpDown();
            this.lbl5 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.pn4 = new System.Windows.Forms.Panel();
            this.pn3 = new System.Windows.Forms.Panel();
            this.pn2 = new System.Windows.Forms.Panel();
            this.pn1 = new System.Windows.Forms.Panel();
            this.btnchImage = new System.Windows.Forms.Button();
            this.pbbookimage = new System.Windows.Forms.PictureBox();
            this.cbBookCategories_add = new System.Windows.Forms.TextBox();
            this.txtAuthor_Add = new System.Windows.Forms.TextBox();
            this.txtNameBook_Add = new System.Windows.Forms.TextBox();
            this.txtISBN_add = new System.Windows.Forms.TextBox();
            this.lbl4 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.pn8 = new System.Windows.Forms.Panel();
            this.rtbDescription_edit = new System.Windows.Forms.RichTextBox();
            this.pn10 = new System.Windows.Forms.Panel();
            this.txtPublish_Edit = new System.Windows.Forms.TextBox();
            this.lbl10 = new System.Windows.Forms.Label();
            this.nudQuantity_Edit = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.pn9 = new System.Windows.Forms.Panel();
            this.pn7 = new System.Windows.Forms.Panel();
            this.pn6 = new System.Windows.Forms.Panel();
            this.pbImage_edit = new System.Windows.Forms.PictureBox();
            this.lbl9 = new System.Windows.Forms.Label();
            this.lbl8 = new System.Windows.Forms.Label();
            this.lbl7 = new System.Windows.Forms.Label();
            this.lbl6 = new System.Windows.Forms.Label();
            this.btnEdit = new System.Windows.Forms.Button();
            this.txtcategories_Edit = new System.Windows.Forms.TextBox();
            this.txtAuthor_Edit = new System.Windows.Forms.TextBox();
            this.txtBookTittle_edit = new System.Windows.Forms.TextBox();
            this.txtISBN_edit = new System.Windows.Forms.TextBox();
            this.GroupBox = new System.Windows.Forms.GroupBox();
            this.rbLost_Edit = new System.Windows.Forms.RadioButton();
            this.rbActive_edit = new System.Windows.Forms.RadioButton();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btnDelete = new System.Windows.Forms.Button();
            this.dgvAdd_edit = new System.Windows.Forms.DataGridView();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.lblSearch = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudQuantity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbbookimage)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudQuantity_Edit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbImage_edit)).BeginInit();
            this.GroupBox.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAdd_edit)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button1.Location = new System.Drawing.Point(34, 425);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(104, 28);
            this.button1.TabIndex = 8;
            this.button1.Text = "Add";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(12, 32);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(390, 532);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.tabPage1.Controls.Add(this.rtbDescription);
            this.tabPage1.Controls.Add(this.pn5);
            this.tabPage1.Controls.Add(this.txtPublish);
            this.tabPage1.Controls.Add(this.nudQuantity);
            this.tabPage1.Controls.Add(this.lbl5);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.pn4);
            this.tabPage1.Controls.Add(this.pn3);
            this.tabPage1.Controls.Add(this.pn2);
            this.tabPage1.Controls.Add(this.pn1);
            this.tabPage1.Controls.Add(this.btnchImage);
            this.tabPage1.Controls.Add(this.pbbookimage);
            this.tabPage1.Controls.Add(this.cbBookCategories_add);
            this.tabPage1.Controls.Add(this.txtAuthor_Add);
            this.tabPage1.Controls.Add(this.txtNameBook_Add);
            this.tabPage1.Controls.Add(this.txtISBN_add);
            this.tabPage1.Controls.Add(this.lbl4);
            this.tabPage1.Controls.Add(this.lbl3);
            this.tabPage1.Controls.Add(this.lbl2);
            this.tabPage1.Controls.Add(this.lbl1);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage1.Location = new System.Drawing.Point(4, 23);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(382, 505);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Add Books";
            // 
            // rtbDescription
            // 
            this.rtbDescription.Location = new System.Drawing.Point(129, 18);
            this.rtbDescription.Name = "rtbDescription";
            this.rtbDescription.Size = new System.Drawing.Size(232, 122);
            this.rtbDescription.TabIndex = 1;
            this.rtbDescription.Text = "";
            // 
            // pn5
            // 
            this.pn5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pn5.ForeColor = System.Drawing.Color.White;
            this.pn5.Location = new System.Drawing.Point(34, 358);
            this.pn5.Name = "pn5";
            this.pn5.Size = new System.Drawing.Size(321, 1);
            this.pn5.TabIndex = 23;
            // 
            // txtPublish
            // 
            this.txtPublish.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtPublish.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPublish.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPublish.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txtPublish.Location = new System.Drawing.Point(134, 338);
            this.txtPublish.Name = "txtPublish";
            this.txtPublish.Size = new System.Drawing.Size(222, 14);
            this.txtPublish.TabIndex = 6;
            this.txtPublish.Enter += new System.EventHandler(this.txtPublish_Enter);
            // 
            // nudQuantity
            // 
            this.nudQuantity.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.nudQuantity.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudQuantity.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.nudQuantity.Location = new System.Drawing.Point(129, 381);
            this.nudQuantity.Name = "nudQuantity";
            this.nudQuantity.Size = new System.Drawing.Size(46, 21);
            this.nudQuantity.TabIndex = 7;
            // 
            // lbl5
            // 
            this.lbl5.AutoSize = true;
            this.lbl5.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl5.Location = new System.Drawing.Point(57, 338);
            this.lbl5.Name = "lbl5";
            this.lbl5.Size = new System.Drawing.Size(72, 14);
            this.lbl5.TabIndex = 22;
            this.lbl5.Text = "Date Publish :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label10.Location = new System.Drawing.Point(44, 383);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(74, 14);
            this.label10.TabIndex = 25;
            this.label10.Text = "Book Quantity";
            // 
            // pn4
            // 
            this.pn4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pn4.ForeColor = System.Drawing.Color.White;
            this.pn4.Location = new System.Drawing.Point(34, 320);
            this.pn4.Name = "pn4";
            this.pn4.Size = new System.Drawing.Size(321, 1);
            this.pn4.TabIndex = 20;
            // 
            // pn3
            // 
            this.pn3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pn3.ForeColor = System.Drawing.Color.White;
            this.pn3.Location = new System.Drawing.Point(34, 279);
            this.pn3.Name = "pn3";
            this.pn3.Size = new System.Drawing.Size(321, 1);
            this.pn3.TabIndex = 19;
            // 
            // pn2
            // 
            this.pn2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pn2.ForeColor = System.Drawing.Color.White;
            this.pn2.Location = new System.Drawing.Point(34, 240);
            this.pn2.Name = "pn2";
            this.pn2.Size = new System.Drawing.Size(321, 1);
            this.pn2.TabIndex = 18;
            // 
            // pn1
            // 
            this.pn1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pn1.ForeColor = System.Drawing.Color.White;
            this.pn1.Location = new System.Drawing.Point(34, 202);
            this.pn1.Name = "pn1";
            this.pn1.Size = new System.Drawing.Size(321, 1);
            this.pn1.TabIndex = 17;
            // 
            // btnchImage
            // 
            this.btnchImage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnchImage.Location = new System.Drawing.Point(24, 117);
            this.btnchImage.Name = "btnchImage";
            this.btnchImage.Size = new System.Drawing.Size(96, 23);
            this.btnchImage.TabIndex = 0;
            this.btnchImage.Text = "Choose Image";
            this.btnchImage.UseVisualStyleBackColor = true;
            this.btnchImage.Click += new System.EventHandler(this.btnchImage_Click);
            // 
            // pbbookimage
            // 
            this.pbbookimage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbbookimage.Location = new System.Drawing.Point(24, 18);
            this.pbbookimage.Name = "pbbookimage";
            this.pbbookimage.Size = new System.Drawing.Size(96, 93);
            this.pbbookimage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbbookimage.TabIndex = 7;
            this.pbbookimage.TabStop = false;
            // 
            // cbBookCategories_add
            // 
            this.cbBookCategories_add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.cbBookCategories_add.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.cbBookCategories_add.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbBookCategories_add.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.cbBookCategories_add.Location = new System.Drawing.Point(135, 299);
            this.cbBookCategories_add.Name = "cbBookCategories_add";
            this.cbBookCategories_add.Size = new System.Drawing.Size(222, 14);
            this.cbBookCategories_add.TabIndex = 5;
            this.cbBookCategories_add.Enter += new System.EventHandler(this.cbBookCategories_add_Enter);
            // 
            // txtAuthor_Add
            // 
            this.txtAuthor_Add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtAuthor_Add.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAuthor_Add.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAuthor_Add.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txtAuthor_Add.Location = new System.Drawing.Point(134, 260);
            this.txtAuthor_Add.Name = "txtAuthor_Add";
            this.txtAuthor_Add.Size = new System.Drawing.Size(222, 14);
            this.txtAuthor_Add.TabIndex = 4;
            this.txtAuthor_Add.Enter += new System.EventHandler(this.txtAuthor_Add_Enter);
            // 
            // txtNameBook_Add
            // 
            this.txtNameBook_Add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtNameBook_Add.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNameBook_Add.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNameBook_Add.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txtNameBook_Add.Location = new System.Drawing.Point(134, 220);
            this.txtNameBook_Add.Name = "txtNameBook_Add";
            this.txtNameBook_Add.Size = new System.Drawing.Size(222, 14);
            this.txtNameBook_Add.TabIndex = 3;
            this.txtNameBook_Add.Enter += new System.EventHandler(this.txtNameBook_Add_Enter);
            // 
            // txtISBN_add
            // 
            this.txtISBN_add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtISBN_add.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtISBN_add.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtISBN_add.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txtISBN_add.Location = new System.Drawing.Point(134, 183);
            this.txtISBN_add.Name = "txtISBN_add";
            this.txtISBN_add.Size = new System.Drawing.Size(222, 14);
            this.txtISBN_add.TabIndex = 2;
            this.txtISBN_add.Enter += new System.EventHandler(this.txtISBN_add_Enter);
            // 
            // lbl4
            // 
            this.lbl4.AutoSize = true;
            this.lbl4.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl4.Location = new System.Drawing.Point(37, 299);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(92, 14);
            this.lbl4.TabIndex = 4;
            this.lbl4.Text = "Book Categories :";
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.BackColor = System.Drawing.Color.Transparent;
            this.lbl3.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl3.Location = new System.Drawing.Point(83, 260);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(46, 14);
            this.lbl3.TabIndex = 3;
            this.lbl3.Text = "Author :";
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.BackColor = System.Drawing.Color.Transparent;
            this.lbl2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl2.Location = new System.Drawing.Point(48, 223);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(80, 14);
            this.lbl2.TabIndex = 2;
            this.lbl2.Text = "Name of Book :";
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl1.Location = new System.Drawing.Point(74, 184);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(55, 14);
            this.lbl1.TabIndex = 1;
            this.lbl1.Text = "ISBN No. :";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.tabPage2.Controls.Add(this.pn8);
            this.tabPage2.Controls.Add(this.rtbDescription_edit);
            this.tabPage2.Controls.Add(this.pn10);
            this.tabPage2.Controls.Add(this.txtPublish_Edit);
            this.tabPage2.Controls.Add(this.lbl10);
            this.tabPage2.Controls.Add(this.nudQuantity_Edit);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.button2);
            this.tabPage2.Controls.Add(this.pn9);
            this.tabPage2.Controls.Add(this.pn7);
            this.tabPage2.Controls.Add(this.pn6);
            this.tabPage2.Controls.Add(this.pbImage_edit);
            this.tabPage2.Controls.Add(this.lbl9);
            this.tabPage2.Controls.Add(this.lbl8);
            this.tabPage2.Controls.Add(this.lbl7);
            this.tabPage2.Controls.Add(this.lbl6);
            this.tabPage2.Controls.Add(this.btnEdit);
            this.tabPage2.Controls.Add(this.txtcategories_Edit);
            this.tabPage2.Controls.Add(this.txtAuthor_Edit);
            this.tabPage2.Controls.Add(this.txtBookTittle_edit);
            this.tabPage2.Controls.Add(this.txtISBN_edit);
            this.tabPage2.Controls.Add(this.GroupBox);
            this.tabPage2.Location = new System.Drawing.Point(4, 23);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(382, 505);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Update";
            // 
            // pn8
            // 
            this.pn8.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pn8.ForeColor = System.Drawing.Color.White;
            this.pn8.Location = new System.Drawing.Point(32, 252);
            this.pn8.Name = "pn8";
            this.pn8.Size = new System.Drawing.Size(321, 1);
            this.pn8.TabIndex = 20;
            // 
            // rtbDescription_edit
            // 
            this.rtbDescription_edit.Location = new System.Drawing.Point(130, 18);
            this.rtbDescription_edit.Name = "rtbDescription_edit";
            this.rtbDescription_edit.Size = new System.Drawing.Size(232, 122);
            this.rtbDescription_edit.TabIndex = 1;
            this.rtbDescription_edit.Text = "";
            // 
            // pn10
            // 
            this.pn10.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pn10.ForeColor = System.Drawing.Color.White;
            this.pn10.Location = new System.Drawing.Point(32, 324);
            this.pn10.Name = "pn10";
            this.pn10.Size = new System.Drawing.Size(321, 1);
            this.pn10.TabIndex = 26;
            // 
            // txtPublish_Edit
            // 
            this.txtPublish_Edit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtPublish_Edit.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPublish_Edit.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPublish_Edit.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txtPublish_Edit.Location = new System.Drawing.Point(129, 303);
            this.txtPublish_Edit.Name = "txtPublish_Edit";
            this.txtPublish_Edit.Size = new System.Drawing.Size(222, 14);
            this.txtPublish_Edit.TabIndex = 6;
            this.txtPublish_Edit.Enter += new System.EventHandler(this.textBox2_Enter);
            // 
            // lbl10
            // 
            this.lbl10.AutoSize = true;
            this.lbl10.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl10.Location = new System.Drawing.Point(49, 303);
            this.lbl10.Name = "lbl10";
            this.lbl10.Size = new System.Drawing.Size(72, 14);
            this.lbl10.TabIndex = 25;
            this.lbl10.Text = "Date Publish :";
            // 
            // nudQuantity_Edit
            // 
            this.nudQuantity_Edit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.nudQuantity_Edit.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudQuantity_Edit.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.nudQuantity_Edit.Location = new System.Drawing.Point(114, 345);
            this.nudQuantity_Edit.Name = "nudQuantity_Edit";
            this.nudQuantity_Edit.Size = new System.Drawing.Size(45, 21);
            this.nudQuantity_Edit.TabIndex = 7;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label9.Location = new System.Drawing.Point(29, 347);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(74, 14);
            this.label9.TabIndex = 23;
            this.label9.Text = "Book Quantity";
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button2.Location = new System.Drawing.Point(25, 117);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(96, 23);
            this.button2.TabIndex = 0;
            this.button2.Text = "Choose Image";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // pn9
            // 
            this.pn9.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pn9.ForeColor = System.Drawing.Color.White;
            this.pn9.Location = new System.Drawing.Point(31, 287);
            this.pn9.Name = "pn9";
            this.pn9.Size = new System.Drawing.Size(321, 1);
            this.pn9.TabIndex = 21;
            // 
            // pn7
            // 
            this.pn7.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pn7.ForeColor = System.Drawing.Color.White;
            this.pn7.Location = new System.Drawing.Point(32, 216);
            this.pn7.Name = "pn7";
            this.pn7.Size = new System.Drawing.Size(321, 1);
            this.pn7.TabIndex = 19;
            // 
            // pn6
            // 
            this.pn6.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pn6.ForeColor = System.Drawing.Color.White;
            this.pn6.Location = new System.Drawing.Point(32, 185);
            this.pn6.Name = "pn6";
            this.pn6.Size = new System.Drawing.Size(321, 1);
            this.pn6.TabIndex = 18;
            // 
            // pbImage_edit
            // 
            this.pbImage_edit.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbImage_edit.Location = new System.Drawing.Point(25, 18);
            this.pbImage_edit.Name = "pbImage_edit";
            this.pbImage_edit.Size = new System.Drawing.Size(96, 93);
            this.pbImage_edit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbImage_edit.TabIndex = 15;
            this.pbImage_edit.TabStop = false;
            // 
            // lbl9
            // 
            this.lbl9.AutoSize = true;
            this.lbl9.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl9.Location = new System.Drawing.Point(29, 267);
            this.lbl9.Name = "lbl9";
            this.lbl9.Size = new System.Drawing.Size(92, 14);
            this.lbl9.TabIndex = 13;
            this.lbl9.Text = "Book Categories :";
            // 
            // lbl8
            // 
            this.lbl8.AutoSize = true;
            this.lbl8.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl8.Location = new System.Drawing.Point(75, 234);
            this.lbl8.Name = "lbl8";
            this.lbl8.Size = new System.Drawing.Size(46, 14);
            this.lbl8.TabIndex = 12;
            this.lbl8.Text = "Author :";
            // 
            // lbl7
            // 
            this.lbl7.AutoSize = true;
            this.lbl7.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl7.Location = new System.Drawing.Point(41, 198);
            this.lbl7.Name = "lbl7";
            this.lbl7.Size = new System.Drawing.Size(80, 14);
            this.lbl7.TabIndex = 11;
            this.lbl7.Text = "Name of Book :";
            // 
            // lbl6
            // 
            this.lbl6.AutoSize = true;
            this.lbl6.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl6.Location = new System.Drawing.Point(64, 164);
            this.lbl6.Name = "lbl6";
            this.lbl6.Size = new System.Drawing.Size(55, 14);
            this.lbl6.TabIndex = 10;
            this.lbl6.Text = "ISBN No. :";
            // 
            // btnEdit
            // 
            this.btnEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEdit.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnEdit.Location = new System.Drawing.Point(25, 455);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(123, 34);
            this.btnEdit.TabIndex = 8;
            this.btnEdit.Text = "Edit";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // txtcategories_Edit
            // 
            this.txtcategories_Edit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtcategories_Edit.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtcategories_Edit.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcategories_Edit.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txtcategories_Edit.Location = new System.Drawing.Point(131, 267);
            this.txtcategories_Edit.Name = "txtcategories_Edit";
            this.txtcategories_Edit.Size = new System.Drawing.Size(222, 14);
            this.txtcategories_Edit.TabIndex = 5;
            this.txtcategories_Edit.Enter += new System.EventHandler(this.txtcategories_Edit_Enter);
            // 
            // txtAuthor_Edit
            // 
            this.txtAuthor_Edit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtAuthor_Edit.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAuthor_Edit.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAuthor_Edit.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txtAuthor_Edit.Location = new System.Drawing.Point(130, 234);
            this.txtAuthor_Edit.Name = "txtAuthor_Edit";
            this.txtAuthor_Edit.Size = new System.Drawing.Size(222, 14);
            this.txtAuthor_Edit.TabIndex = 4;
            this.txtAuthor_Edit.Enter += new System.EventHandler(this.txtAuthor_Edit_Enter);
            // 
            // txtBookTittle_edit
            // 
            this.txtBookTittle_edit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtBookTittle_edit.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtBookTittle_edit.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBookTittle_edit.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txtBookTittle_edit.Location = new System.Drawing.Point(130, 196);
            this.txtBookTittle_edit.Name = "txtBookTittle_edit";
            this.txtBookTittle_edit.Size = new System.Drawing.Size(222, 14);
            this.txtBookTittle_edit.TabIndex = 3;
            this.txtBookTittle_edit.Enter += new System.EventHandler(this.txtBookTittle_edit_Enter);
            // 
            // txtISBN_edit
            // 
            this.txtISBN_edit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtISBN_edit.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtISBN_edit.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtISBN_edit.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txtISBN_edit.Location = new System.Drawing.Point(133, 164);
            this.txtISBN_edit.Name = "txtISBN_edit";
            this.txtISBN_edit.Size = new System.Drawing.Size(222, 14);
            this.txtISBN_edit.TabIndex = 2;
            this.txtISBN_edit.Enter += new System.EventHandler(this.txtISBN_edit_Enter);
            // 
            // GroupBox
            // 
            this.GroupBox.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.GroupBox.Controls.Add(this.rbLost_Edit);
            this.GroupBox.Controls.Add(this.rbActive_edit);
            this.GroupBox.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.GroupBox.Location = new System.Drawing.Point(25, 376);
            this.GroupBox.Name = "GroupBox";
            this.GroupBox.Size = new System.Drawing.Size(330, 63);
            this.GroupBox.TabIndex = 0;
            this.GroupBox.TabStop = false;
            this.GroupBox.Text = "Status";
            // 
            // rbLost_Edit
            // 
            this.rbLost_Edit.AutoSize = true;
            this.rbLost_Edit.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.rbLost_Edit.Location = new System.Drawing.Point(6, 43);
            this.rbLost_Edit.Name = "rbLost_Edit";
            this.rbLost_Edit.Size = new System.Drawing.Size(46, 18);
            this.rbLost_Edit.TabIndex = 1;
            this.rbLost_Edit.TabStop = true;
            this.rbLost_Edit.Text = "Lost";
            this.rbLost_Edit.UseVisualStyleBackColor = true;
            // 
            // rbActive_edit
            // 
            this.rbActive_edit.AutoSize = true;
            this.rbActive_edit.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbActive_edit.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.rbActive_edit.Location = new System.Drawing.Point(6, 19);
            this.rbActive_edit.Name = "rbActive_edit";
            this.rbActive_edit.Size = new System.Drawing.Size(56, 18);
            this.rbActive_edit.TabIndex = 0;
            this.rbActive_edit.TabStop = true;
            this.rbActive_edit.Text = "Active";
            this.rbActive_edit.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.btnDelete);
            this.tabPage3.Location = new System.Drawing.Point(4, 23);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(382, 505);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Delete";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(39, 54);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(143, 108);
            this.btnDelete.TabIndex = 0;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // dgvAdd_edit
            // 
            this.dgvAdd_edit.AllowUserToAddRows = false;
            this.dgvAdd_edit.AllowUserToDeleteRows = false;
            this.dgvAdd_edit.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvAdd_edit.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvAdd_edit.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dgvAdd_edit.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAdd_edit.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvAdd_edit.GridColor = System.Drawing.SystemColors.ControlDarkDark;
            this.dgvAdd_edit.Location = new System.Drawing.Point(432, 62);
            this.dgvAdd_edit.MultiSelect = false;
            this.dgvAdd_edit.Name = "dgvAdd_edit";
            this.dgvAdd_edit.ReadOnly = true;
            this.dgvAdd_edit.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvAdd_edit.Size = new System.Drawing.Size(513, 502);
            this.dgvAdd_edit.TabIndex = 2;
            this.dgvAdd_edit.SelectionChanged += new System.EventHandler(this.dgvAdd_edit_SelectionChanged);
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(557, 29);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(319, 20);
            this.txtSearch.TabIndex = 3;
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // lblSearch
            // 
            this.lblSearch.AutoSize = true;
            this.lblSearch.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearch.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lblSearch.Location = new System.Drawing.Point(501, 32);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new System.Drawing.Size(49, 16);
            this.lblSearch.TabIndex = 5;
            this.lblSearch.Text = "Search";
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Location = new System.Drawing.Point(828, 572);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(37, 13);
            this.lblTotal.TabIndex = 6;
            this.lblTotal.Text = "Total: ";
            // 
            // AddEditBooks
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(967, 626);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.lblSearch);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.dgvAdd_edit);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AddEditBooks";
            this.Text = "AddEditBooks";
            this.Load += new System.EventHandler(this.AddEditBooks_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudQuantity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbbookimage)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudQuantity_Edit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbImage_edit)).EndInit();
            this.GroupBox.ResumeLayout(false);
            this.GroupBox.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAdd_edit)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox txtAuthor_Add;
        private System.Windows.Forms.TextBox txtNameBook_Add;
        private System.Windows.Forms.TextBox txtISBN_add;
        private System.Windows.Forms.Label lbl4;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dgvAdd_edit;
        private System.Windows.Forms.Label lbl9;
        private System.Windows.Forms.Label lbl8;
        private System.Windows.Forms.Label lbl7;
        private System.Windows.Forms.Label lbl6;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.TextBox txtcategories_Edit;
        private System.Windows.Forms.TextBox txtAuthor_Edit;
        private System.Windows.Forms.TextBox txtBookTittle_edit;
        private System.Windows.Forms.TextBox txtISBN_edit;
        private System.Windows.Forms.GroupBox GroupBox;
        private System.Windows.Forms.RadioButton rbLost_Edit;
        private System.Windows.Forms.RadioButton rbActive_edit;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.TextBox cbBookCategories_add;
        private System.Windows.Forms.PictureBox pbbookimage;
        private System.Windows.Forms.Button btnchImage;
        private System.Windows.Forms.PictureBox pbImage_edit;
        private System.Windows.Forms.Panel pn1;
        private System.Windows.Forms.Panel pn4;
        private System.Windows.Forms.Panel pn3;
        private System.Windows.Forms.Panel pn2;
        private System.Windows.Forms.Panel pn9;
        private System.Windows.Forms.Panel pn7;
        private System.Windows.Forms.Panel pn6;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.NumericUpDown nudQuantity_Edit;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.NumericUpDown nudQuantity;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel pn5;
        private System.Windows.Forms.TextBox txtPublish;
        private System.Windows.Forms.Label lbl5;
        private System.Windows.Forms.Panel pn10;
        private System.Windows.Forms.TextBox txtPublish_Edit;
        private System.Windows.Forms.Label lbl10;
        private System.Windows.Forms.RichTextBox rtbDescription;
        private System.Windows.Forms.RichTextBox rtbDescription_edit;
        private System.Windows.Forms.Panel pn8;
    }
}