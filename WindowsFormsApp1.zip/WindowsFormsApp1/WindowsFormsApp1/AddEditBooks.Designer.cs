﻿
namespace WindowsFormsApp1
{
    partial class AddEditBooks
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtCallno_Add = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtAccession_add = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btncategoriesEnable = new System.Windows.Forms.Button();
            this.cbBookCategories_add = new System.Windows.Forms.ComboBox();
            this.pn5 = new System.Windows.Forms.Panel();
            this.txtPublish = new System.Windows.Forms.TextBox();
            this.nudQuantity = new System.Windows.Forms.NumericUpDown();
            this.lbl5 = new System.Windows.Forms.Label();
            this.lbl5_1 = new System.Windows.Forms.Label();
            this.pn4 = new System.Windows.Forms.Panel();
            this.pn3 = new System.Windows.Forms.Panel();
            this.pn2 = new System.Windows.Forms.Panel();
            this.pn1 = new System.Windows.Forms.Panel();
            this.btnchImage = new System.Windows.Forms.Button();
            this.pbbookimage = new System.Windows.Forms.PictureBox();
            this.txtAuthor_Add = new System.Windows.Forms.TextBox();
            this.txtNameBook_Add = new System.Windows.Forms.TextBox();
            this.txtISBN_add = new System.Windows.Forms.TextBox();
            this.lbl4 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txtCallno_edit = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtAccession_edit = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btncategoriesEnable_edit = new System.Windows.Forms.Button();
            this.txtcategories_Edit = new System.Windows.Forms.ComboBox();
            this.pn8 = new System.Windows.Forms.Panel();
            this.pn10 = new System.Windows.Forms.Panel();
            this.txtPublish_Edit = new System.Windows.Forms.TextBox();
            this.lbl10 = new System.Windows.Forms.Label();
            this.nudQuantity_Edit = new System.Windows.Forms.NumericUpDown();
            this.lbl11 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.pn9 = new System.Windows.Forms.Panel();
            this.pn7 = new System.Windows.Forms.Panel();
            this.pn6 = new System.Windows.Forms.Panel();
            this.pbImage_edit = new System.Windows.Forms.PictureBox();
            this.lbl9 = new System.Windows.Forms.Label();
            this.lbl8 = new System.Windows.Forms.Label();
            this.lbl7 = new System.Windows.Forms.Label();
            this.lbl6 = new System.Windows.Forms.Label();
            this.btnEdit = new System.Windows.Forms.Button();
            this.txtAuthor_Edit = new System.Windows.Forms.TextBox();
            this.txtBookTittle_edit = new System.Windows.Forms.TextBox();
            this.txtISBN_edit = new System.Windows.Forms.TextBox();
            this.GroupBox = new System.Windows.Forms.GroupBox();
            this.rbLost_Edit = new System.Windows.Forms.RadioButton();
            this.rbActive_edit = new System.Windows.Forms.RadioButton();
            this.dgvAdd_edit = new System.Windows.Forms.DataGridView();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.lblSearch = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.lblTotal = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.txtPublisher_add = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.txtPublisher_edit = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudQuantity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbbookimage)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudQuantity_Edit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbImage_edit)).BeginInit();
            this.GroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAdd_edit)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button1.Location = new System.Drawing.Point(34, 423);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(104, 28);
            this.button1.TabIndex = 8;
            this.button1.Text = "Add";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(12, 32);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(390, 532);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.tabPage1.Controls.Add(this.panel5);
            this.tabPage1.Controls.Add(this.txtPublisher_add);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.panel2);
            this.tabPage1.Controls.Add(this.txtCallno_Add);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Controls.Add(this.txtAccession_add);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.btncategoriesEnable);
            this.tabPage1.Controls.Add(this.cbBookCategories_add);
            this.tabPage1.Controls.Add(this.pn5);
            this.tabPage1.Controls.Add(this.txtPublish);
            this.tabPage1.Controls.Add(this.nudQuantity);
            this.tabPage1.Controls.Add(this.lbl5);
            this.tabPage1.Controls.Add(this.lbl5_1);
            this.tabPage1.Controls.Add(this.pn4);
            this.tabPage1.Controls.Add(this.pn3);
            this.tabPage1.Controls.Add(this.pn2);
            this.tabPage1.Controls.Add(this.pn1);
            this.tabPage1.Controls.Add(this.btnchImage);
            this.tabPage1.Controls.Add(this.pbbookimage);
            this.tabPage1.Controls.Add(this.txtAuthor_Add);
            this.tabPage1.Controls.Add(this.txtNameBook_Add);
            this.tabPage1.Controls.Add(this.txtISBN_add);
            this.tabPage1.Controls.Add(this.lbl4);
            this.tabPage1.Controls.Add(this.lbl3);
            this.tabPage1.Controls.Add(this.lbl2);
            this.tabPage1.Controls.Add(this.lbl1);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage1.Location = new System.Drawing.Point(4, 23);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(382, 505);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Add Books";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel2.ForeColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(34, 249);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(321, 1);
            this.panel2.TabIndex = 33;
            // 
            // txtCallno_Add
            // 
            this.txtCallno_Add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtCallno_Add.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCallno_Add.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCallno_Add.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txtCallno_Add.Location = new System.Drawing.Point(134, 230);
            this.txtCallno_Add.Name = "txtCallno_Add";
            this.txtCallno_Add.Size = new System.Drawing.Size(222, 14);
            this.txtCallno_Add.TabIndex = 32;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label3.Location = new System.Drawing.Point(82, 230);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 14);
            this.label3.TabIndex = 31;
            this.label3.Text = "Call No :";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(161, 57);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 1);
            this.panel1.TabIndex = 30;
            // 
            // txtAccession_add
            // 
            this.txtAccession_add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtAccession_add.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAccession_add.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAccession_add.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txtAccession_add.Location = new System.Drawing.Point(211, 37);
            this.txtAccession_add.Name = "txtAccession_add";
            this.txtAccession_add.Size = new System.Drawing.Size(150, 14);
            this.txtAccession_add.TabIndex = 29;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label1.Location = new System.Drawing.Point(131, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 14);
            this.label1.TabIndex = 28;
            this.label1.Text = "Accession‎ No:";
            // 
            // btncategoriesEnable
            // 
            this.btncategoriesEnable.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncategoriesEnable.ForeColor = System.Drawing.Color.Black;
            this.btncategoriesEnable.Location = new System.Drawing.Point(336, 336);
            this.btncategoriesEnable.Name = "btncategoriesEnable";
            this.btncategoriesEnable.Size = new System.Drawing.Size(25, 23);
            this.btncategoriesEnable.TabIndex = 27;
            this.btncategoriesEnable.Text = "?";
            this.btncategoriesEnable.UseVisualStyleBackColor = true;
            this.btncategoriesEnable.Click += new System.EventHandler(this.btncategoriesEnable_Click);
            this.btncategoriesEnable.MouseHover += new System.EventHandler(this.btncategoriesEnable_MouseHover);
            // 
            // cbBookCategories_add
            // 
            this.cbBookCategories_add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.cbBookCategories_add.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbBookCategories_add.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cbBookCategories_add.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbBookCategories_add.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.cbBookCategories_add.FormattingEnabled = true;
            this.cbBookCategories_add.Items.AddRange(new object[] {
            "--Select Categories--"});
            this.cbBookCategories_add.Location = new System.Drawing.Point(134, 336);
            this.cbBookCategories_add.Name = "cbBookCategories_add";
            this.cbBookCategories_add.Size = new System.Drawing.Size(191, 23);
            this.cbBookCategories_add.TabIndex = 26;
            this.cbBookCategories_add.Enter += new System.EventHandler(this.cbBookCategories_add_Enter_1);
            // 
            // pn5
            // 
            this.pn5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pn5.ForeColor = System.Drawing.Color.White;
            this.pn5.Location = new System.Drawing.Point(33, 291);
            this.pn5.Name = "pn5";
            this.pn5.Size = new System.Drawing.Size(321, 1);
            this.pn5.TabIndex = 23;
            // 
            // txtPublish
            // 
            this.txtPublish.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtPublish.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPublish.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPublish.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txtPublish.Location = new System.Drawing.Point(133, 271);
            this.txtPublish.Name = "txtPublish";
            this.txtPublish.Size = new System.Drawing.Size(222, 14);
            this.txtPublish.TabIndex = 6;
            this.txtPublish.Enter += new System.EventHandler(this.txtPublish_Enter);
            // 
            // nudQuantity
            // 
            this.nudQuantity.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.nudQuantity.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudQuantity.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.nudQuantity.Location = new System.Drawing.Point(129, 383);
            this.nudQuantity.Name = "nudQuantity";
            this.nudQuantity.Size = new System.Drawing.Size(46, 21);
            this.nudQuantity.TabIndex = 7;
            this.nudQuantity.Enter += new System.EventHandler(this.nudQuantity_Enter);
            // 
            // lbl5
            // 
            this.lbl5.AutoSize = true;
            this.lbl5.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl5.Location = new System.Drawing.Point(56, 271);
            this.lbl5.Name = "lbl5";
            this.lbl5.Size = new System.Drawing.Size(73, 14);
            this.lbl5.TabIndex = 22;
            this.lbl5.Text = "Year Publish :";
            // 
            // lbl5_1
            // 
            this.lbl5_1.AutoSize = true;
            this.lbl5_1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl5_1.Location = new System.Drawing.Point(44, 385);
            this.lbl5_1.Name = "lbl5_1";
            this.lbl5_1.Size = new System.Drawing.Size(74, 14);
            this.lbl5_1.TabIndex = 25;
            this.lbl5_1.Text = "Book Quantity";
            // 
            // pn4
            // 
            this.pn4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pn4.ForeColor = System.Drawing.Color.White;
            this.pn4.Location = new System.Drawing.Point(33, 364);
            this.pn4.Name = "pn4";
            this.pn4.Size = new System.Drawing.Size(321, 1);
            this.pn4.TabIndex = 20;
            // 
            // pn3
            // 
            this.pn3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pn3.ForeColor = System.Drawing.Color.White;
            this.pn3.Location = new System.Drawing.Point(34, 210);
            this.pn3.Name = "pn3";
            this.pn3.Size = new System.Drawing.Size(321, 1);
            this.pn3.TabIndex = 19;
            // 
            // pn2
            // 
            this.pn2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pn2.ForeColor = System.Drawing.Color.White;
            this.pn2.Location = new System.Drawing.Point(34, 171);
            this.pn2.Name = "pn2";
            this.pn2.Size = new System.Drawing.Size(321, 1);
            this.pn2.TabIndex = 18;
            // 
            // pn1
            // 
            this.pn1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pn1.ForeColor = System.Drawing.Color.White;
            this.pn1.Location = new System.Drawing.Point(161, 99);
            this.pn1.Name = "pn1";
            this.pn1.Size = new System.Drawing.Size(200, 1);
            this.pn1.TabIndex = 17;
            // 
            // btnchImage
            // 
            this.btnchImage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnchImage.Location = new System.Drawing.Point(10, 110);
            this.btnchImage.Name = "btnchImage";
            this.btnchImage.Size = new System.Drawing.Size(96, 23);
            this.btnchImage.TabIndex = 0;
            this.btnchImage.Text = "Choose Image";
            this.btnchImage.UseVisualStyleBackColor = true;
            this.btnchImage.Click += new System.EventHandler(this.btnchImage_Click);
            // 
            // pbbookimage
            // 
            this.pbbookimage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbbookimage.Location = new System.Drawing.Point(10, 11);
            this.pbbookimage.Name = "pbbookimage";
            this.pbbookimage.Size = new System.Drawing.Size(96, 93);
            this.pbbookimage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbbookimage.TabIndex = 7;
            this.pbbookimage.TabStop = false;
            // 
            // txtAuthor_Add
            // 
            this.txtAuthor_Add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtAuthor_Add.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAuthor_Add.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAuthor_Add.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txtAuthor_Add.Location = new System.Drawing.Point(134, 191);
            this.txtAuthor_Add.Name = "txtAuthor_Add";
            this.txtAuthor_Add.Size = new System.Drawing.Size(222, 14);
            this.txtAuthor_Add.TabIndex = 4;
            this.txtAuthor_Add.Enter += new System.EventHandler(this.txtAuthor_Add_Enter);
            // 
            // txtNameBook_Add
            // 
            this.txtNameBook_Add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtNameBook_Add.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNameBook_Add.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNameBook_Add.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txtNameBook_Add.Location = new System.Drawing.Point(134, 151);
            this.txtNameBook_Add.Name = "txtNameBook_Add";
            this.txtNameBook_Add.Size = new System.Drawing.Size(222, 14);
            this.txtNameBook_Add.TabIndex = 3;
            this.txtNameBook_Add.Enter += new System.EventHandler(this.txtNameBook_Add_Enter);
            // 
            // txtISBN_add
            // 
            this.txtISBN_add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtISBN_add.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtISBN_add.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtISBN_add.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txtISBN_add.Location = new System.Drawing.Point(211, 79);
            this.txtISBN_add.Name = "txtISBN_add";
            this.txtISBN_add.Size = new System.Drawing.Size(150, 14);
            this.txtISBN_add.TabIndex = 2;
            this.txtISBN_add.Enter += new System.EventHandler(this.txtISBN_add_Enter);
            // 
            // lbl4
            // 
            this.lbl4.AutoSize = true;
            this.lbl4.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl4.Location = new System.Drawing.Point(36, 343);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(92, 14);
            this.lbl4.TabIndex = 4;
            this.lbl4.Text = "Book Categories :";
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.BackColor = System.Drawing.Color.Transparent;
            this.lbl3.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl3.Location = new System.Drawing.Point(83, 191);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(46, 14);
            this.lbl3.TabIndex = 3;
            this.lbl3.Text = "Author :";
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.BackColor = System.Drawing.Color.Transparent;
            this.lbl2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl2.Location = new System.Drawing.Point(48, 154);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(80, 14);
            this.lbl2.TabIndex = 2;
            this.lbl2.Text = "Name of Book :";
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl1.Location = new System.Drawing.Point(154, 79);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(55, 14);
            this.lbl1.TabIndex = 1;
            this.lbl1.Text = "ISBN No. :";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.tabPage2.Controls.Add(this.panel6);
            this.tabPage2.Controls.Add(this.txtPublisher_edit);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.panel4);
            this.tabPage2.Controls.Add(this.txtCallno_edit);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.panel3);
            this.tabPage2.Controls.Add(this.txtAccession_edit);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.btncategoriesEnable_edit);
            this.tabPage2.Controls.Add(this.txtcategories_Edit);
            this.tabPage2.Controls.Add(this.pn8);
            this.tabPage2.Controls.Add(this.pn10);
            this.tabPage2.Controls.Add(this.txtPublish_Edit);
            this.tabPage2.Controls.Add(this.lbl10);
            this.tabPage2.Controls.Add(this.nudQuantity_Edit);
            this.tabPage2.Controls.Add(this.lbl11);
            this.tabPage2.Controls.Add(this.button2);
            this.tabPage2.Controls.Add(this.pn9);
            this.tabPage2.Controls.Add(this.pn7);
            this.tabPage2.Controls.Add(this.pn6);
            this.tabPage2.Controls.Add(this.pbImage_edit);
            this.tabPage2.Controls.Add(this.lbl9);
            this.tabPage2.Controls.Add(this.lbl8);
            this.tabPage2.Controls.Add(this.lbl7);
            this.tabPage2.Controls.Add(this.lbl6);
            this.tabPage2.Controls.Add(this.btnEdit);
            this.tabPage2.Controls.Add(this.txtAuthor_Edit);
            this.tabPage2.Controls.Add(this.txtBookTittle_edit);
            this.tabPage2.Controls.Add(this.txtISBN_edit);
            this.tabPage2.Controls.Add(this.GroupBox);
            this.tabPage2.Location = new System.Drawing.Point(4, 23);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(382, 505);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Update";
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel4.ForeColor = System.Drawing.Color.White;
            this.panel4.Location = new System.Drawing.Point(34, 247);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(321, 1);
            this.panel4.TabIndex = 37;
            // 
            // txtCallno_edit
            // 
            this.txtCallno_edit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtCallno_edit.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCallno_edit.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCallno_edit.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txtCallno_edit.Location = new System.Drawing.Point(134, 228);
            this.txtCallno_edit.Name = "txtCallno_edit";
            this.txtCallno_edit.Size = new System.Drawing.Size(222, 14);
            this.txtCallno_edit.TabIndex = 36;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label4.Location = new System.Drawing.Point(82, 228);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 14);
            this.label4.TabIndex = 35;
            this.label4.Text = "Call No :";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel3.ForeColor = System.Drawing.Color.White;
            this.panel3.Location = new System.Drawing.Point(161, 57);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(200, 1);
            this.panel3.TabIndex = 34;
            // 
            // txtAccession_edit
            // 
            this.txtAccession_edit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtAccession_edit.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAccession_edit.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAccession_edit.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txtAccession_edit.Location = new System.Drawing.Point(211, 37);
            this.txtAccession_edit.Name = "txtAccession_edit";
            this.txtAccession_edit.Size = new System.Drawing.Size(150, 14);
            this.txtAccession_edit.TabIndex = 33;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label2.Location = new System.Drawing.Point(131, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 14);
            this.label2.TabIndex = 32;
            this.label2.Text = "Accession‎ No:";
            // 
            // btncategoriesEnable_edit
            // 
            this.btncategoriesEnable_edit.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncategoriesEnable_edit.ForeColor = System.Drawing.Color.Black;
            this.btncategoriesEnable_edit.Location = new System.Drawing.Point(330, 259);
            this.btncategoriesEnable_edit.Name = "btncategoriesEnable_edit";
            this.btncategoriesEnable_edit.Size = new System.Drawing.Size(25, 23);
            this.btncategoriesEnable_edit.TabIndex = 31;
            this.btncategoriesEnable_edit.Text = "?";
            this.btncategoriesEnable_edit.UseVisualStyleBackColor = true;
            this.btncategoriesEnable_edit.Click += new System.EventHandler(this.btncategoriesEnable_edit_Click);
            this.btncategoriesEnable_edit.MouseHover += new System.EventHandler(this.button3_MouseHover);
            // 
            // txtcategories_Edit
            // 
            this.txtcategories_Edit.AutoCompleteCustomSource.AddRange(new string[] {
            "--Select Categories--"});
            this.txtcategories_Edit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtcategories_Edit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtcategories_Edit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.txtcategories_Edit.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcategories_Edit.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txtcategories_Edit.FormattingEnabled = true;
            this.txtcategories_Edit.Items.AddRange(new object[] {
            "--Select Categories--"});
            this.txtcategories_Edit.Location = new System.Drawing.Point(127, 262);
            this.txtcategories_Edit.Name = "txtcategories_Edit";
            this.txtcategories_Edit.Size = new System.Drawing.Size(197, 23);
            this.txtcategories_Edit.TabIndex = 30;
            // 
            // pn8
            // 
            this.pn8.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pn8.ForeColor = System.Drawing.Color.White;
            this.pn8.Location = new System.Drawing.Point(34, 210);
            this.pn8.Name = "pn8";
            this.pn8.Size = new System.Drawing.Size(321, 1);
            this.pn8.TabIndex = 20;
            // 
            // pn10
            // 
            this.pn10.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pn10.ForeColor = System.Drawing.Color.White;
            this.pn10.Location = new System.Drawing.Point(32, 327);
            this.pn10.Name = "pn10";
            this.pn10.Size = new System.Drawing.Size(321, 1);
            this.pn10.TabIndex = 26;
            // 
            // txtPublish_Edit
            // 
            this.txtPublish_Edit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtPublish_Edit.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPublish_Edit.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPublish_Edit.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txtPublish_Edit.Location = new System.Drawing.Point(129, 306);
            this.txtPublish_Edit.Name = "txtPublish_Edit";
            this.txtPublish_Edit.Size = new System.Drawing.Size(222, 14);
            this.txtPublish_Edit.TabIndex = 6;
            this.txtPublish_Edit.Enter += new System.EventHandler(this.textBox2_Enter);
            // 
            // lbl10
            // 
            this.lbl10.AutoSize = true;
            this.lbl10.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl10.Location = new System.Drawing.Point(46, 306);
            this.lbl10.Name = "lbl10";
            this.lbl10.Size = new System.Drawing.Size(73, 14);
            this.lbl10.TabIndex = 25;
            this.lbl10.Text = "Year Publish :";
            // 
            // nudQuantity_Edit
            // 
            this.nudQuantity_Edit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.nudQuantity_Edit.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudQuantity_Edit.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.nudQuantity_Edit.Location = new System.Drawing.Point(116, 377);
            this.nudQuantity_Edit.Name = "nudQuantity_Edit";
            this.nudQuantity_Edit.Size = new System.Drawing.Size(45, 21);
            this.nudQuantity_Edit.TabIndex = 7;
            // 
            // lbl11
            // 
            this.lbl11.AutoSize = true;
            this.lbl11.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl11.Location = new System.Drawing.Point(31, 379);
            this.lbl11.Name = "lbl11";
            this.lbl11.Size = new System.Drawing.Size(74, 14);
            this.lbl11.TabIndex = 23;
            this.lbl11.Text = "Book Quantity";
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.button2.Location = new System.Drawing.Point(10, 110);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(96, 23);
            this.button2.TabIndex = 0;
            this.button2.Text = "Choose Image";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // pn9
            // 
            this.pn9.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pn9.ForeColor = System.Drawing.Color.White;
            this.pn9.Location = new System.Drawing.Point(31, 290);
            this.pn9.Name = "pn9";
            this.pn9.Size = new System.Drawing.Size(321, 1);
            this.pn9.TabIndex = 21;
            // 
            // pn7
            // 
            this.pn7.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pn7.ForeColor = System.Drawing.Color.White;
            this.pn7.Location = new System.Drawing.Point(34, 171);
            this.pn7.Name = "pn7";
            this.pn7.Size = new System.Drawing.Size(321, 1);
            this.pn7.TabIndex = 19;
            // 
            // pn6
            // 
            this.pn6.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pn6.ForeColor = System.Drawing.Color.White;
            this.pn6.Location = new System.Drawing.Point(161, 99);
            this.pn6.Name = "pn6";
            this.pn6.Size = new System.Drawing.Size(200, 1);
            this.pn6.TabIndex = 18;
            // 
            // pbImage_edit
            // 
            this.pbImage_edit.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbImage_edit.Location = new System.Drawing.Point(10, 11);
            this.pbImage_edit.Name = "pbImage_edit";
            this.pbImage_edit.Size = new System.Drawing.Size(96, 93);
            this.pbImage_edit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbImage_edit.TabIndex = 15;
            this.pbImage_edit.TabStop = false;
            // 
            // lbl9
            // 
            this.lbl9.AutoSize = true;
            this.lbl9.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl9.Location = new System.Drawing.Point(29, 270);
            this.lbl9.Name = "lbl9";
            this.lbl9.Size = new System.Drawing.Size(92, 14);
            this.lbl9.TabIndex = 13;
            this.lbl9.Text = "Book Categories :";
            // 
            // lbl8
            // 
            this.lbl8.AutoSize = true;
            this.lbl8.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl8.Location = new System.Drawing.Point(83, 191);
            this.lbl8.Name = "lbl8";
            this.lbl8.Size = new System.Drawing.Size(46, 14);
            this.lbl8.TabIndex = 12;
            this.lbl8.Text = "Author :";
            // 
            // lbl7
            // 
            this.lbl7.AutoSize = true;
            this.lbl7.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl7.Location = new System.Drawing.Point(48, 154);
            this.lbl7.Name = "lbl7";
            this.lbl7.Size = new System.Drawing.Size(80, 14);
            this.lbl7.TabIndex = 11;
            this.lbl7.Text = "Name of Book :";
            // 
            // lbl6
            // 
            this.lbl6.AutoSize = true;
            this.lbl6.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lbl6.Location = new System.Drawing.Point(154, 79);
            this.lbl6.Name = "lbl6";
            this.lbl6.Size = new System.Drawing.Size(55, 14);
            this.lbl6.TabIndex = 10;
            this.lbl6.Text = "ISBN No. :";
            // 
            // btnEdit
            // 
            this.btnEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEdit.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.btnEdit.Location = new System.Drawing.Point(25, 459);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(123, 34);
            this.btnEdit.TabIndex = 8;
            this.btnEdit.Text = "Edit";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // txtAuthor_Edit
            // 
            this.txtAuthor_Edit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtAuthor_Edit.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAuthor_Edit.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAuthor_Edit.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txtAuthor_Edit.Location = new System.Drawing.Point(134, 191);
            this.txtAuthor_Edit.Name = "txtAuthor_Edit";
            this.txtAuthor_Edit.Size = new System.Drawing.Size(222, 14);
            this.txtAuthor_Edit.TabIndex = 4;
            this.txtAuthor_Edit.Enter += new System.EventHandler(this.txtAuthor_Edit_Enter);
            // 
            // txtBookTittle_edit
            // 
            this.txtBookTittle_edit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtBookTittle_edit.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtBookTittle_edit.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBookTittle_edit.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txtBookTittle_edit.Location = new System.Drawing.Point(134, 151);
            this.txtBookTittle_edit.Name = "txtBookTittle_edit";
            this.txtBookTittle_edit.Size = new System.Drawing.Size(222, 14);
            this.txtBookTittle_edit.TabIndex = 3;
            this.txtBookTittle_edit.Enter += new System.EventHandler(this.txtBookTittle_edit_Enter);
            // 
            // txtISBN_edit
            // 
            this.txtISBN_edit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtISBN_edit.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtISBN_edit.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtISBN_edit.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txtISBN_edit.Location = new System.Drawing.Point(211, 79);
            this.txtISBN_edit.Name = "txtISBN_edit";
            this.txtISBN_edit.Size = new System.Drawing.Size(150, 14);
            this.txtISBN_edit.TabIndex = 2;
            this.txtISBN_edit.Enter += new System.EventHandler(this.txtISBN_edit_Enter);
            // 
            // GroupBox
            // 
            this.GroupBox.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.GroupBox.Controls.Add(this.rbLost_Edit);
            this.GroupBox.Controls.Add(this.rbActive_edit);
            this.GroupBox.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.GroupBox.Location = new System.Drawing.Point(211, 379);
            this.GroupBox.Name = "GroupBox";
            this.GroupBox.Size = new System.Drawing.Size(144, 63);
            this.GroupBox.TabIndex = 0;
            this.GroupBox.TabStop = false;
            this.GroupBox.Text = "Status";
            // 
            // rbLost_Edit
            // 
            this.rbLost_Edit.AutoSize = true;
            this.rbLost_Edit.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.rbLost_Edit.Location = new System.Drawing.Point(6, 43);
            this.rbLost_Edit.Name = "rbLost_Edit";
            this.rbLost_Edit.Size = new System.Drawing.Size(46, 18);
            this.rbLost_Edit.TabIndex = 1;
            this.rbLost_Edit.TabStop = true;
            this.rbLost_Edit.Text = "Lost";
            this.rbLost_Edit.UseVisualStyleBackColor = true;
            // 
            // rbActive_edit
            // 
            this.rbActive_edit.AutoSize = true;
            this.rbActive_edit.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbActive_edit.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.rbActive_edit.Location = new System.Drawing.Point(6, 19);
            this.rbActive_edit.Name = "rbActive_edit";
            this.rbActive_edit.Size = new System.Drawing.Size(56, 18);
            this.rbActive_edit.TabIndex = 0;
            this.rbActive_edit.TabStop = true;
            this.rbActive_edit.Text = "Active";
            this.rbActive_edit.UseVisualStyleBackColor = true;
            // 
            // dgvAdd_edit
            // 
            this.dgvAdd_edit.AllowUserToAddRows = false;
            this.dgvAdd_edit.AllowUserToDeleteRows = false;
            this.dgvAdd_edit.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvAdd_edit.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvAdd_edit.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dgvAdd_edit.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAdd_edit.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvAdd_edit.GridColor = System.Drawing.SystemColors.ControlDarkDark;
            this.dgvAdd_edit.Location = new System.Drawing.Point(432, 62);
            this.dgvAdd_edit.MultiSelect = false;
            this.dgvAdd_edit.Name = "dgvAdd_edit";
            this.dgvAdd_edit.ReadOnly = true;
            this.dgvAdd_edit.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvAdd_edit.Size = new System.Drawing.Size(513, 502);
            this.dgvAdd_edit.TabIndex = 2;
            this.dgvAdd_edit.SelectionChanged += new System.EventHandler(this.dgvAdd_edit_SelectionChanged);
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(557, 29);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(319, 20);
            this.txtSearch.TabIndex = 3;
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // lblSearch
            // 
            this.lblSearch.AutoSize = true;
            this.lblSearch.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearch.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lblSearch.Location = new System.Drawing.Point(501, 32);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new System.Drawing.Size(49, 16);
            this.lblSearch.TabIndex = 5;
            this.lblSearch.Text = "Search";
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Location = new System.Drawing.Point(828, 572);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(37, 13);
            this.lblTotal.TabIndex = 6;
            this.lblTotal.Text = "Total: ";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel5.ForeColor = System.Drawing.Color.White;
            this.panel5.Location = new System.Drawing.Point(33, 327);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(321, 1);
            this.panel5.TabIndex = 36;
            // 
            // txtPublisher_add
            // 
            this.txtPublisher_add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtPublisher_add.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPublisher_add.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPublisher_add.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txtPublisher_add.Location = new System.Drawing.Point(133, 307);
            this.txtPublisher_add.Name = "txtPublisher_add";
            this.txtPublisher_add.Size = new System.Drawing.Size(222, 14);
            this.txtPublisher_add.TabIndex = 34;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label5.Location = new System.Drawing.Point(71, 307);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 14);
            this.label5.TabIndex = 35;
            this.label5.Text = "Publisher :";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel6.ForeColor = System.Drawing.Color.White;
            this.panel6.Location = new System.Drawing.Point(32, 365);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(321, 1);
            this.panel6.TabIndex = 40;
            // 
            // txtPublisher_edit
            // 
            this.txtPublisher_edit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.txtPublisher_edit.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPublisher_edit.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPublisher_edit.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.txtPublisher_edit.Location = new System.Drawing.Point(132, 345);
            this.txtPublisher_edit.Name = "txtPublisher_edit";
            this.txtPublisher_edit.Size = new System.Drawing.Size(222, 14);
            this.txtPublisher_edit.TabIndex = 38;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label6.Location = new System.Drawing.Point(62, 346);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 14);
            this.label6.TabIndex = 39;
            this.label6.Text = "Publisher :";
            // 
            // AddEditBooks
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(967, 626);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.lblSearch);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.dgvAdd_edit);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AddEditBooks";
            this.Text = "AddEditBooks";
            this.Load += new System.EventHandler(this.AddEditBooks_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudQuantity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbbookimage)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudQuantity_Edit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbImage_edit)).EndInit();
            this.GroupBox.ResumeLayout(false);
            this.GroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAdd_edit)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox txtAuthor_Add;
        private System.Windows.Forms.TextBox txtNameBook_Add;
        private System.Windows.Forms.TextBox txtISBN_add;
        private System.Windows.Forms.Label lbl4;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dgvAdd_edit;
        private System.Windows.Forms.Label lbl9;
        private System.Windows.Forms.Label lbl8;
        private System.Windows.Forms.Label lbl7;
        private System.Windows.Forms.Label lbl6;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.TextBox txtAuthor_Edit;
        private System.Windows.Forms.TextBox txtBookTittle_edit;
        private System.Windows.Forms.TextBox txtISBN_edit;
        private System.Windows.Forms.GroupBox GroupBox;
        private System.Windows.Forms.RadioButton rbLost_Edit;
        private System.Windows.Forms.RadioButton rbActive_edit;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.PictureBox pbbookimage;
        private System.Windows.Forms.Button btnchImage;
        private System.Windows.Forms.PictureBox pbImage_edit;
        private System.Windows.Forms.Panel pn1;
        private System.Windows.Forms.Panel pn3;
        private System.Windows.Forms.Panel pn2;
        private System.Windows.Forms.Panel pn9;
        private System.Windows.Forms.Panel pn7;
        private System.Windows.Forms.Panel pn6;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.NumericUpDown nudQuantity_Edit;
        private System.Windows.Forms.Label lbl11;
        private System.Windows.Forms.NumericUpDown nudQuantity;
        private System.Windows.Forms.Label lbl5_1;
        private System.Windows.Forms.Panel pn5;
        private System.Windows.Forms.TextBox txtPublish;
        private System.Windows.Forms.Label lbl5;
        private System.Windows.Forms.Panel pn10;
        private System.Windows.Forms.TextBox txtPublish_Edit;
        private System.Windows.Forms.Label lbl10;
        private System.Windows.Forms.Panel pn8;
        private System.Windows.Forms.ComboBox cbBookCategories_add;
        private System.Windows.Forms.Panel pn4;
        private System.Windows.Forms.Button btncategoriesEnable;
        private System.Windows.Forms.ComboBox txtcategories_Edit;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Button btncategoriesEnable_edit;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtCallno_Add;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtAccession_add;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txtAccession_edit;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox txtCallno_edit;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox txtPublisher_add;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox txtPublisher_edit;
        private System.Windows.Forms.Label label6;
    }
}