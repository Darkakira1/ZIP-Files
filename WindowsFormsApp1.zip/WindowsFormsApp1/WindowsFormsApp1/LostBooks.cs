﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class LostBooks : Form
    {
        public static LostBooks instance;
        public DataGridView ldgv;
        MySqlConnection conn = new MySqlConnection("server=127.0.0.1;port=3306;username=root;password=root123;database=librarydb");


        private void PopulateTable()
        {
            try
            {
               
                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("Select Accession‎_No as 'Accession No', Name_of_Book as 'Books', Book_Author as 'Author',Book_Categories as 'Categories',Book_Status as 'Status' From table_inventorybooks Where Book_Status = 'Lost'", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
        }
        public LostBooks()
        {
            InitializeComponent();
            instance = this;
            ldgv = dataGridView1;

        }


       

        private void LostBooks_Load(object sender, EventArgs e)
        {
            PopulateTable();

           

        }

        private void btnReturn_Click(object sender, EventArgs e)
        {


            String CurrentBID = dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[0].Value.ToString();

            string Astatus = "Active";

            
            try
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand("Update table_inventorybooks SET Book_Status=@book_status WHERE Accession‎_No = " + CurrentBID, conn);

     
                cmd.Parameters.AddWithValue("@book_status", Astatus);

                cmd.ExecuteNonQuery();
                MessageBox.Show("Restore Succesfully!", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                conn.Close();
                PopulateTable();
               

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }

            //BooksInformation binfo = new BooksInformation();
            //binfo.UpdateEventHandler += F2_UpdateEventHandler1;
            //binfo.ShowDialog();


        }
    }
}
