﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class BookReturned : Form
    {

        private bool dragging = false;
        private Point dragCursorPoint;
        private Point dragFormPoint;


        MySqlConnection conn = new MySqlConnection("server=127.0.0.1;port=3306;username=root;password=root123;database=librarydb");
        private void PopulateTable()
        {
            try
            {

                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT IDissued as 'Issued No', Student_name as 'Person Name', ISBN_no as 'ISBN No.',Book_Tittle as 'Book Tittle', Book_Issued as 'Book Issued', Book_Return as 'Book Return',Book_Status as 'Book Status' FROM bookissued Where Book_Status = 'Return'", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dgvHistory.DataSource = dt;



            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            conn.Close();
        }

        public BookReturned()
        {
            InitializeComponent();
        }

        private void BookReturned_Load(object sender, EventArgs e)
        {
            PopulateTable();
        }


        #region design
        private void label7_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void panel3_MouseDown(object sender, MouseEventArgs e)
        {
            dragging = true;
            dragCursorPoint = Cursor.Position;
            dragFormPoint = this.Location;
        }

        private void panel3_MouseUp(object sender, MouseEventArgs e)
        {
            dragging = false;
        }

        private void panel3_MouseMove(object sender, MouseEventArgs e)
        {
            if (dragging)
            {
                Point dif = Point.Subtract(Cursor.Position, new Size(dragCursorPoint));
                this.Location = Point.Add(dragFormPoint, new Size(dif));
            }
        }


        #endregion

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                string sqlquery = "SELECT IDissued as 'Issued No', Student_name as 'Person Name', ISBN_no as 'ISBN No.',Book_Tittle as 'Book Tittle', Book_Issued as 'Book Issued', Book_Return as 'Book Return',Book_Status as 'Book Status' FROM bookissued Where IDissued like '" + txtSearch.Text + "%' AND Book_Status = 'Return'";
                conn.Open();

                MySqlCommand sqlCommand = new MySqlCommand(sqlquery, conn);
                MySqlDataAdapter sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                DataTable dt = new DataTable();
                sqlDataAdapter.Fill(dt);
                dgvHistory.DataSource = dt;
               // lblTotal.Text = $"Total Records: {dataGridView1.RowCount}";

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            conn.Close();
        }
    }
}
