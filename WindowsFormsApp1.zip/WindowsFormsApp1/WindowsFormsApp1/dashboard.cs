﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp1
{



    public partial class DashBoard : Form
    {

        public static DashBoard instance;

        AddEditBooks books = new AddEditBooks();
        BooksInformation binfo = new BooksInformation();
        LostBooks lostb = new LostBooks();
        IssuedBook Ibook = new IssuedBook();
        DashboardButton dbb = new DashboardButton();
        ExpiredBooks exbooks = new ExpiredBooks();


        MySqlConnection conn = new MySqlConnection("server=127.0.0.1;port=3306;username=root;password=root123;database=librarydb");


        private void expiredbookspopulatetable()
        {
            try
            {
                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT IDissued as 'Issued No', Student_name as 'Person Name', ISBN_no as 'ISBN No.',Book_Tittle as 'Book Tittle', Book_Issued as 'Book Issued', Book_Return as 'Book Return',Book_Status as 'Book Status' FROM bookissued Where Not Book_Status = 'Return'", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                ExpiredBooks.instance.Edgv.DataSource = dt;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            conn.Close();
        }

        private void PopulateTable()
        {
            try
            {
                
                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("Select ISBN_no as 'ISBN No',Name_of_Book as 'Book Tittle',Book_Author as 'Author',Book_Categories as 'Categories',Book_Status as 'Status', Book_quantity as 'Quantity' From table_inventorybooks Where NOT Book_Status = 'Lost'", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);


                BooksInformation.instance.dgv.DataSource = dt;
                BooksInformation.instance.BItotal.Text = $"Total Records: {BooksInformation.instance.dgv.RowCount}";

                AddEditBooks.instance.advg.DataSource = dt;
                AddEditBooks.instance.Alabel.Text = $"Total Records: {AddEditBooks.instance.advg.RowCount}";

               

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            conn.Close();
        }

        private void bookinformation()
        {
            try
            {
                
                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("Select ISBN_no as 'ISBN no.' , Name_of_Book as 'Book Tittle', Book_quantity as 'Quantity' From table_inventorybooks Where NOT Book_Status = 'Lost'", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);


                BooksInformation.instance.dgv.DataSource = dt;
                BooksInformation.instance.BItotal.Text = $"Total Records: {BooksInformation.instance.dgv.RowCount}";

                

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            conn.Close();
        }

     

        public DashBoard()
        {
            InitializeComponent();
            instance = this;

            books.Hide();
            lostb.Hide();
            binfo.Hide();
            Ibook.Hide();

            dbb.TopLevel = false;
            pnlDisplay.Controls.Add(dbb);
            dbb.BringToFront();
            dbb.Show();


            btnDashBoard.BackColor = Color.FromArgb(78, 184, 206);

          
        }

        private void btnBooks_Click(object sender, EventArgs e)
        {
            //Add/editBooks

            binfo.Hide();
            lostb.Hide();
            dbb.Hide();
            Ibook.Hide();

            books.TopLevel = false;
            pnlDisplay.Controls.Add(books);
            books.BringToFront();
            books.Show();

            PopulateTable();



            btnBooks.BackColor = Color.FromArgb(78, 184, 206);

            btnDashBoard.BackColor = Color.FromArgb(160, 160, 160);
            btnIssuedBooks.BackColor = Color.FromArgb(160, 160, 160);
            btnBookInfo.BackColor = Color.FromArgb(160, 160, 160);
            btnStudentsInfo.BackColor = Color.FromArgb(160, 160, 160);
            btnReturn.BackColor = Color.FromArgb(160, 160, 160);

        }

        private void button1_Click(object sender, EventArgs e)
        {

            //booksInformation

            books.Hide();
            lostb.Hide();
            dbb.Hide();
            Ibook.Hide();

            binfo.TopLevel = false;
            pnlDisplay.Controls.Add(binfo);
            binfo.BringToFront();
            binfo.Show();

            bookinformation(); ;
            //Comboboxref();


            btnBookInfo.BackColor = Color.FromArgb(78, 184, 206);

            btnBooks.BackColor = Color.FromArgb(160, 160, 160);
            btnIssuedBooks.BackColor = Color.FromArgb(160, 160, 160);
            btnDashBoard.BackColor = Color.FromArgb(160, 160, 160);
            btnStudentsInfo.BackColor = Color.FromArgb(160, 160, 160);
            btnReturn.BackColor = Color.FromArgb(160, 160, 160);

        }

        private void btnLostBooks_Click(object sender, EventArgs e)
        {
           

        }

        private void btnStudentsInfo_Click(object sender, EventArgs e)
        {
            //AddStudents

            AddStudent student = new AddStudent();
            books.Hide();
            lostb.Hide();
            dbb.Hide();
            Ibook.Hide();


            student.TopLevel = false;
            pnlDisplay.Controls.Add(student);
            student.BringToFront();
            student.Show();

            btnStudentsInfo.BackColor = Color.FromArgb(78, 184, 206);

            btnBooks.BackColor = Color.FromArgb(160, 160, 160);
            btnIssuedBooks.BackColor = Color.FromArgb(160, 160, 160);
            btnBookInfo.BackColor = Color.FromArgb(160, 160, 160);
            btnDashBoard.BackColor = Color.FromArgb(160, 160, 160);
            btnReturn.BackColor = Color.FromArgb(160, 160, 160);
        }

        private void studentInformationToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            StudentInformation Sinformatin = new StudentInformation();
            Sinformatin.Show();

        }

        private void facultyInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FacultyInfo finformation = new FacultyInfo();
            finformation.Show();
        }

        private void btnIssuedBooks_Click(object sender, EventArgs e)
        {
            //Issued Books

            books.Hide();
            lostb.Hide();
            binfo.Hide();


            Ibook.TopLevel = false;
            pnlDisplay.Controls.Add(Ibook);
            Ibook.BringToFront();
            Ibook.Show();



            try
            {
                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT IDissued as 'Issued No', Student_name as 'Person Name', Book_Tittle as 'Book Tittle', Book_Issued as 'Book Issued', Book_Return as 'Book Return'  FROM bookissued Where  Book_Status = 'Borrowed' ", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                IssuedBook.instance1.Idgv.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            conn.Close();



            btnIssuedBooks.BackColor = Color.FromArgb(78, 184, 206);

            btnBooks.BackColor = Color.FromArgb(160, 160, 160);
            btnDashBoard.BackColor = Color.FromArgb(160, 160, 160);
            btnBookInfo.BackColor = Color.FromArgb(160, 160, 160);
            btnStudentsInfo.BackColor = Color.FromArgb(160, 160, 160);
            btnReturn.BackColor = Color.FromArgb(160, 160, 160);
        }

        private void DashBoard_Load(object sender, EventArgs e)
        {

        }

        private void btnDashBoard_Click(object sender, EventArgs e)
        {
            books.Hide();
            lostb.Hide();
            binfo.Hide();
            Ibook.Hide();

            dbb.TopLevel = false;
            pnlDisplay.Controls.Add(dbb);
            dbb.BringToFront();
            dbb.Show();


            btnDashBoard.BackColor = Color.FromArgb(78, 184, 206);

            btnBooks.BackColor = Color.FromArgb(160, 160, 160);
            btnIssuedBooks.BackColor = Color.FromArgb(160, 160, 160);
            btnBookInfo.BackColor = Color.FromArgb(160, 160, 160);
            btnStudentsInfo.BackColor = Color.FromArgb(160, 160, 160);
            btnReturn.BackColor = Color.FromArgb(160, 160, 160);
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void returnBooksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BookReturned br = new BookReturned();
            br.Show();
            
        }

        private void lostBooksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //LostBooks


            books.Hide();
            binfo.Hide();

            lostb.TopLevel = false;
            pnlDisplay.Controls.Add(lostb);
            lostb.BringToFront();
            lostb.Show();

            try
            {

                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("Select ISBN_no as 'ISBN No',Name_of_Book as 'Book Tittle',Book_Author as 'Author',Book_Categories as 'Categories' ,Book_Status as 'Status' From table_inventorybooks where Book_Status = 'Lost'", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                LostBooks.instance.ldgv.DataSource = dt;
                

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            conn.Close();

            

            btnBooks.BackColor = Color.FromArgb(160, 160, 160);
            btnIssuedBooks.BackColor = Color.FromArgb(160, 160, 160);
            btnBookInfo.BackColor = Color.FromArgb(160, 160, 160);
            btnStudentsInfo.BackColor = Color.FromArgb(160, 160, 160);
            btnDashBoard.BackColor = Color.FromArgb(160, 160, 160);
            btnReturn.BackColor = Color.FromArgb(160,160,160);
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {

            books.Hide();
            lostb.Hide();
            binfo.Hide();
            Ibook.Hide();
            dbb.Hide();

            exbooks.TopLevel = false;
            pnlDisplay.Controls.Add(exbooks);
            exbooks.BringToFront();
            exbooks.Show();


            try
            {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand("Update bookissued SET Book_Status = @statuse WHERE Book_Return <= '" + DateTime.Now.ToString("yyyy-MM-dd hh:mm tt") + "' And Not Book_Status = 'Return'", conn);
                cmd.Parameters.AddWithValue("@statuse", "OverDue");
                cmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                MessageBox.Show("" + ex);
            }
            conn.Close();

            expiredbookspopulatetable();





            btnReturn.BackColor = Color.FromArgb(78, 184, 206);

            btnBooks.BackColor = Color.FromArgb(160, 160, 160);
            btnIssuedBooks.BackColor = Color.FromArgb(160, 160, 160);
            btnBookInfo.BackColor = Color.FromArgb(160, 160, 160);
            btnStudentsInfo.BackColor = Color.FromArgb(160, 160, 160);
            btnDashBoard.BackColor = Color.FromArgb(160, 160, 160);
        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ForgotPassword changepass = new ForgotPassword();

            changepass.TopLevel = false;
            pnlDisplay.Controls.Add(changepass);
            changepass.BringToFront();
            changepass.Show();
        }
    }
}
