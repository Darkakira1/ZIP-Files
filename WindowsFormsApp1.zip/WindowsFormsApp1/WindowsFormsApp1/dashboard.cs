﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp1
{



    public partial class DashBoard : Form
    {

        public static DashBoard instance;

        AddEditBooks books = new AddEditBooks();
        BooksInformation binfo = new BooksInformation();
        LostBooks lostb = new LostBooks();
        IssuedBook Ibook = new IssuedBook();
        DashboardButton dbb = new DashboardButton();
        ExpiredBooks exbooks = new ExpiredBooks();


        MySqlConnection conn = new MySqlConnection("server=127.0.0.1;port=3306;username=root;password=root123;database=librarydb");

     


        private void expiredbookspopulatetable()
        {
            try
            {
                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT IDissued as 'Issued No', Student_name as 'Person Name', ISBN_no as 'ISBN No.',Book_Tittle as 'Book Tittle', Book_Issued as 'Book Issued', Book_Return as 'Book Return',Book_Status as 'Book Status' FROM bookissued Where Not Book_Status = 'Return'", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                ExpiredBooks.instance.Edgv.DataSource = dt;
               
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            conn.Close();
        }


        private void addformPopulateTable_combobox()
        {
            string first = "--Select Categories--";
            try 
            { 
                DataGridViewCellStyle style = new DataGridViewCellStyle();
                style.ForeColor = Color.Red;
                //dataGridView1.Rows[0].Cells[4].Style = style;
                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("Select Accession‎_No as 'Accession No',Name_of_Book as 'Book Tittle',Book_Author as 'Author',Book_Categories as 'Categories', Book_quantity as 'Quantity' From table_inventorybooks Where NOT Book_Status = 'Lost'", conn);

                DataTable dt = new DataTable();
                adapter.Fill(dt);


                AddEditBooks.instance.advg.DataSource = dt;
                AddEditBooks.instance.Alabel.Text = $"Total Records: {AddEditBooks.instance.advg.RowCount}";

                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            //====================================================combobox===========================================================================

            AddEditBooks.instance.cb_add.Items.Clear();
            AddEditBooks.instance.cb_edit.Items.Clear();
            try
            {
                string sqlquery = "Select Distinct Book_Categories From table_inventorybooks Where NOT Book_Status = 'Lost'";
                conn.Open();
                MySqlCommand command = new MySqlCommand(sqlquery, conn);
                MySqlDataReader reader = command.ExecuteReader();


                AddEditBooks.instance.cb_add.Items.Add(first);
                AddEditBooks.instance.cb_edit.Items.Add(first);
                while (reader.Read())
                {
                    AddEditBooks.instance.cb_add.Items.Add(reader.GetString("Book_Categories"));
                    AddEditBooks.instance.cb_edit.Items.Add(reader.GetString("Book_Categories"));
                    
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("error" + ex);

            }
            conn.Close();


            AddEditBooks.instance.cb_add.SelectedIndex = 0;
            AddEditBooks.instance.cb_edit.SelectedIndex = 0;
        }

     

        private void bookinformation()
        {

            string firstindex = "All";
            
            //===============================================================populateTable============================================================
            try
            {
                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("Select Accession‎_No as 'Accession No',  Name_of_Book as 'Book Tittle', Book_quantity as 'Book Quantity', Book_Status as 'Status' From table_inventorybooks Where NOT Book_Status = 'Lost'", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                BooksInformation.instance.dgv.DataSource = dt;
                BooksInformation.instance.BItotal.Text = $"Total Records: {BooksInformation.instance.dgv.RowCount}";

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            conn.Close();

            //==================================================combobox=============================================================================
            BooksInformation.instance.cbcategories.Items.Clear();
            
            try
            {
                string sqlquery = "Select Distinct Book_Categories From table_inventorybooks Where NOT Book_Status = 'Lost'";
                conn.Open();
                MySqlCommand command = new MySqlCommand(sqlquery, conn);
                MySqlDataReader reader = command.ExecuteReader();

                BooksInformation.instance.cbcategories.Items.Add(firstindex);
                while (reader.Read())
                {
                    BooksInformation.instance.cbcategories.Items.Add(reader.GetString("Book_Categories"));
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("error" + ex);

            }
            conn.Close();

        }

        private void issuedbookformload()
        {

            string facultyid = "  --Select Faculty ID --";
            string Studentid = "  --Select Student ID--";
            string second = "      --Select Accession No--";
            try
            {
                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT IDissued as 'Issued No', Student_name as 'Person Name', Book_Tittle as 'Book Tittle', Book_Issued as 'Book Issued', Book_Return as 'Book Return'  FROM bookissued Where  Book_Status = 'Borrowed' ", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                IssuedBook.instance1.Idgv.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            conn.Close();

            //---------------------------------------++++++++ComboBox Student ID++++++++++----------------------------------------

         

            IssuedBook.instance1.cbstudent.Items.Clear() ;

           
            try
            {
                string sqlquery = "SELECT * FROM studentinfo";
                conn.Open();
                MySqlCommand command = new MySqlCommand(sqlquery, conn);
                MySqlDataReader reader = command.ExecuteReader();

                IssuedBook.instance1.cbstudent.Items.Add(Studentid);

                while (reader.Read())
                {

                    
                    IssuedBook.instance1.cbstudent.Items.Add(reader.GetString("ID"));
                    
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("error" + ex);

            }

            //---------------------------+++++++++++++=ComboBox Faculty ID=+++++++++++++++++---------------------------------
  

            IssuedBook.instance1.cbfaculty.Items.Clear();


            try
            {
                string sqlquery = "SELECT * FROM facultyinfo";
                conn.Open();
                MySqlCommand command1 = new MySqlCommand(sqlquery, conn);
                MySqlDataReader reader = command1.ExecuteReader();

                IssuedBook.instance1.cbfaculty.Items.Add(facultyid);

                //string MembersID = reader["ID"]  +,+ reader["FID"];

                while (reader.Read())
                {
                    IssuedBook.instance1.cbfaculty.Items.Add(reader.GetString("FID"));
                }

                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("error" + ex);

            }

            //-------------------------------------------+++++++++++++=ComboboxBooks=++++++++++++++++++++==+++---------------

            IssuedBook.instance1.cbaccession.Items.Clear();
        

            try
            {
                string sqlquery = "Select * From table_inventorybooks Where NOT Book_Status = 'Lost'";
                conn.Open();
                MySqlCommand command = new MySqlCommand(sqlquery, conn);
                MySqlDataReader reader = command.ExecuteReader();

                IssuedBook.instance1.cbaccession.Items.Add(second);
                while (reader.Read())
                {
                    IssuedBook.instance1.cbaccession.Items.Add(reader.GetString("Accession‎_No"));
                   
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("error" + ex);

            }

        }
        private void dashboardbuttonformload()
        {
            //============================================================books total ===========================================================
            try
            {

                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("Select ISBN_no as 'ISBN No',Name_of_Book as 'Book Tittle',Book_Author as 'Author',Book_Categories as 'Categories',Book_Status as 'Status', Book_quantity as 'Quantity' From table_inventorybooks Where NOT Book_Status = 'Lost'", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);


                
                DashboardButton.instance2.bookstotal.Text = dt.Rows.Count.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            conn.Close();
            //========================================================== student total =========================================================================

            try
            {

                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT * FROM studentinfo", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                DashboardButton.instance2.studenttotal.Text = dt.Rows.Count.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            conn.Close();

            //========================================================== Faculty total =============================================================

            try
            {

                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT * FROM facultyinfo", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                DashboardButton.instance2.facultytotal.Text = dt.Rows.Count.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            conn.Close();
            //======================================================== Book Issued Total =========================================================
            try
            {

                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT IDissued as 'Issued No', Student_name as 'Person Name', Book_Tittle as 'Book Tittle', Book_Issued as 'Book Issued', Book_Return as 'Book Return'  FROM bookissued Where  Book_Status = 'Borrowed' ", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                DashboardButton.instance2.issuedtotal.Text = dt.Rows.Count.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            conn.Close();
            //======================================================== Book Return Total ==========================================================
            try
            {

                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT IDissued as 'Issued No', Student_name as 'Person Name', Book_Tittle as 'Book Tittle', Book_Issued as 'Book Issued', Book_Return as 'Book Return'  FROM bookissued Where  Book_Status = 'Return' ", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                DashboardButton.instance2.returntotal.Text = dt.Rows.Count.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            conn.Close();
            //======================================================== Book Expired Total ============================================================
            try
            {

                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT IDissued as 'Issued No', Student_name as 'Person Name', Book_Tittle as 'Book Tittle', Book_Issued as 'Book Issued', Book_Return as 'Book Return'  FROM bookissued Where  Book_Status = 'OverDue' ", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                DashboardButton.instance2.expiredtotal.Text = dt.Rows.Count.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            conn.Close();
        }
        public DashBoard()
        {
            InitializeComponent();
            instance = this;

            books.Hide();
            lostb.Hide();
            binfo.Hide();
            Ibook.Hide();

            dbb.TopLevel = false;
            pnlDisplay.Controls.Add(dbb);
            dbb.BringToFront();
            dbb.Show();


            btnDashBoard.BackColor = Color.FromArgb(78, 184, 206);

          
        }

        private void btnBooks_Click(object sender, EventArgs e)
        {
            //Add/editBooks

            binfo.Hide();
            lostb.Hide();
            dbb.Hide();
            Ibook.Hide();

           

            books.TopLevel = false;
            pnlDisplay.Controls.Add(books);
            books.BringToFront();
            books.Show();

            addformPopulateTable_combobox();



            btnBooks.BackColor = Color.FromArgb(78, 184, 206);

            btnDashBoard.BackColor = Color.FromArgb(160, 160, 160);
            btnIssuedBooks.BackColor = Color.FromArgb(160, 160, 160);
            btnBookInfo.BackColor = Color.FromArgb(160, 160, 160);
            btnStudentsInfo.BackColor = Color.FromArgb(160, 160, 160);
            btnReturn.BackColor = Color.FromArgb(160, 160, 160);

        }

        private void button1_Click(object sender, EventArgs e)
        {

            //booksInformation

            books.Hide();
            lostb.Hide();
            dbb.Hide();
            Ibook.Hide();

            binfo.TopLevel = false;
            pnlDisplay.Controls.Add(binfo);
            binfo.BringToFront();
            binfo.Show();

            bookinformation(); ;
            //Comboboxref();


            btnBookInfo.BackColor = Color.FromArgb(78, 184, 206);

            btnBooks.BackColor = Color.FromArgb(160, 160, 160);
            btnIssuedBooks.BackColor = Color.FromArgb(160, 160, 160);
            btnDashBoard.BackColor = Color.FromArgb(160, 160, 160);
            btnStudentsInfo.BackColor = Color.FromArgb(160, 160, 160);
            btnReturn.BackColor = Color.FromArgb(160, 160, 160);

        }

        private void btnLostBooks_Click(object sender, EventArgs e)
        {
           

        }

        private void btnStudentsInfo_Click(object sender, EventArgs e)
        {
            //AddStudents

            AddStudent student = new AddStudent();
            books.Hide();
            lostb.Hide();
            dbb.Hide();
            Ibook.Hide();


            student.TopLevel = false;
            pnlDisplay.Controls.Add(student);
            student.BringToFront();
            student.Show();

            btnStudentsInfo.BackColor = Color.FromArgb(78, 184, 206);

            btnBooks.BackColor = Color.FromArgb(160, 160, 160);
            btnIssuedBooks.BackColor = Color.FromArgb(160, 160, 160);
            btnBookInfo.BackColor = Color.FromArgb(160, 160, 160);
            btnDashBoard.BackColor = Color.FromArgb(160, 160, 160);
            btnReturn.BackColor = Color.FromArgb(160, 160, 160);
        }

        private void studentInformationToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            StudentInformation Sinformatin = new StudentInformation();
            Sinformatin.Show();

        }

        private void facultyInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FacultyInfo finformation = new FacultyInfo();
            finformation.Show();
        }

        private void btnIssuedBooks_Click(object sender, EventArgs e)
        {
            //Issued Books

            books.Hide();
            lostb.Hide();
            binfo.Hide();


            

            Ibook.TopLevel = false;
            pnlDisplay.Controls.Add(Ibook);
            Ibook.BringToFront();
            Ibook.Show();


            issuedbookformload();

            

            btnIssuedBooks.BackColor = Color.FromArgb(78, 184, 206);

            btnBooks.BackColor = Color.FromArgb(160, 160, 160);
            btnDashBoard.BackColor = Color.FromArgb(160, 160, 160);
            btnBookInfo.BackColor = Color.FromArgb(160, 160, 160);
            btnStudentsInfo.BackColor = Color.FromArgb(160, 160, 160);
            btnReturn.BackColor = Color.FromArgb(160, 160, 160);
        }

        private void DashBoard_Load(object sender, EventArgs e)
        {

        }

        private void btnDashBoard_Click(object sender, EventArgs e)
        {
            books.Hide();
            lostb.Hide();
            binfo.Hide();
            Ibook.Hide();

            dbb.TopLevel = false;
            pnlDisplay.Controls.Add(dbb);
            dbb.BringToFront();
            dbb.Show();

            dashboardbuttonformload();
            
            btnDashBoard.BackColor = Color.FromArgb(78, 184, 206);

            btnBooks.BackColor = Color.FromArgb(160, 160, 160);
            btnIssuedBooks.BackColor = Color.FromArgb(160, 160, 160);
            btnBookInfo.BackColor = Color.FromArgb(160, 160, 160);
            btnStudentsInfo.BackColor = Color.FromArgb(160, 160, 160);
            btnReturn.BackColor = Color.FromArgb(160, 160, 160);
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void returnBooksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BookReturned br = new BookReturned();


            br.TopLevel = false;
            pnlDisplay.Controls.Add(br);
            br.BringToFront();
            br.Show();

        }

        private void lostBooksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //LostBooks


            books.Hide();
            binfo.Hide();

            lostb.TopLevel = false;
            pnlDisplay.Controls.Add(lostb);
            lostb.BringToFront();
            lostb.Show();

            try
            {

                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("Select Accession‎_No as 'Accession No',Name_of_Book as 'Book Tittle',Book_Author as 'Author',Book_Categories as 'Categories' ,Book_Status as 'Status' From table_inventorybooks where Book_Status = 'Lost'", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                LostBooks.instance.ldgv.DataSource = dt;


            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            conn.Close();



            btnBooks.BackColor = Color.FromArgb(160, 160, 160);
            btnIssuedBooks.BackColor = Color.FromArgb(160, 160, 160);
            btnBookInfo.BackColor = Color.FromArgb(160, 160, 160);
            btnStudentsInfo.BackColor = Color.FromArgb(160, 160, 160);
            btnDashBoard.BackColor = Color.FromArgb(160, 160, 160);
            btnReturn.BackColor = Color.FromArgb(160,160,160);
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {

            books.Hide();
            lostb.Hide();
            binfo.Hide();
            Ibook.Hide();
            dbb.Hide();

            exbooks.TopLevel = false;
            pnlDisplay.Controls.Add(exbooks);
            exbooks.BringToFront();
            exbooks.Show();


            try
            {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand("Update bookissued SET Book_Status = @statuse WHERE Book_Return <= '" + DateTime.Now.ToString("yyyy-MM-dd hh:mm tt") + "' And Not Book_Status = 'Return'", conn);
                cmd.Parameters.AddWithValue("@statuse", "OverDue");
                cmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                MessageBox.Show("" + ex);
            }
            conn.Close();

            expiredbookspopulatetable();





            btnReturn.BackColor = Color.FromArgb(78, 184, 206);

            btnBooks.BackColor = Color.FromArgb(160, 160, 160);
            btnIssuedBooks.BackColor = Color.FromArgb(160, 160, 160);
            btnBookInfo.BackColor = Color.FromArgb(160, 160, 160);
            btnStudentsInfo.BackColor = Color.FromArgb(160, 160, 160);
            btnDashBoard.BackColor = Color.FromArgb(160, 160, 160);
        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ForgotPassword changepass = new ForgotPassword();

            changepass.TopLevel = false;
            pnlDisplay.Controls.Add(changepass);
            changepass.BringToFront();
            changepass.Show();




            btnReturn.BackColor = Color.FromArgb(160, 160, 160);

            btnBooks.BackColor = Color.FromArgb(160, 160, 160);
            btnIssuedBooks.BackColor = Color.FromArgb(160, 160, 160);
            btnBookInfo.BackColor = Color.FromArgb(160, 160, 160);
            btnStudentsInfo.BackColor = Color.FromArgb(160, 160, 160);
            btnDashBoard.BackColor = Color.FromArgb(160, 160, 160);
        }
    }
}
