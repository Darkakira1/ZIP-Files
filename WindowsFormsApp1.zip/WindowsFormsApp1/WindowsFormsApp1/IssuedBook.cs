﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;

namespace WindowsFormsApp1
{
    public partial class IssuedBook : Form
    {

        MySqlConnection conn = new MySqlConnection("server=127.0.0.1;port=3306;username=root;password=root123;database=librarydb");

        DateTime mydt;
        //String bookclick;

        public static IssuedBook instance1;
        public DataGridView Idgv;
        //public Label Ilabel;

        public IssuedBook()
        {
            InitializeComponent();


            instance1 = this;
            Idgv = dataGridView1;
           

        }



        private void PopulateTable()
        {
            try
            {

                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT IDissued as 'Issued No', Student_name as 'Person Name', Book_Tittle as 'Book Tittle', Book_Issued as 'Book Issued', Book_Return as 'Book Return'  FROM bookissued Where  Book_Status = 'Borrowed' ", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            conn.Close();
        }
        private void ClearField()
        {
            cbFacultyID.SelectedIndex = -1;
            cbISBN.SelectedIndex = -1;
            cbStudentID.SelectedIndex = -1;
            lblFacultyName.Text = "";
            lblStudentName.Text = "";
            lblTittle.Text = "";
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void IssuedBook_Load(object sender, EventArgs e)
        {

            //lbltotalhours.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm");


            //String CurrentBID = dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[0].Value.ToString();

            PopulateTable();
            dtpReturn.Value = DateTime.Now;

            timer1.Start();
            txtTimeIssued.Text = DateTime.Now.ToString() ;


            //-------------------------------------------+++++++++++++=ComboboxBooks=++++++++++++++++++++==+++---------------



            try
            {
                string sqlquery = "Select * From table_inventorybooks Where NOT Book_Status = 'Lost'";
                conn.Open();
                MySqlCommand command = new MySqlCommand(sqlquery, conn);
                MySqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    cbISBN.Items.Add(reader.GetString("ISBN_no"));
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("error" + ex);

            }


            //---------------------------+++++++++++++=ComboBox Faculty ID=+++++++++++++++++---------------------------------





            try
            {
                string sqlquery = "SELECT * FROM facultyinfo";
                conn.Open();
                MySqlCommand command = new MySqlCommand(sqlquery, conn);
                MySqlDataReader reader = command.ExecuteReader();

                //string MembersID = reader["ID"]  +,+ reader["FID"];

                while (reader.Read())
                {
                    cbFacultyID.Items.Add(reader.GetString("FID"));


                }
                command.Dispose();
                reader.Close();
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("error" + ex);

            }


            //---------------------------------------++++++++ComboBox Student ID++++++++++----------------------------------------


            try
            {
                string sqlquery = "SELECT * FROM studentinfo";
                conn.Open();
                MySqlCommand command = new MySqlCommand(sqlquery, conn);
                MySqlDataReader reader = command.ExecuteReader();


                while (reader.Read())
                {
                    cbStudentID.Items.Add(reader.GetString("ID"));


                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("error" + ex);

            }

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void cbISBN_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                MySqlDataAdapter query = new MySqlDataAdapter("Select Name_of_Book, Book_Author, Book_Description, Book_Categories  From table_inventorybooks Where ISBN_no = '" + cbISBN.Text+"'" , conn);
                DataTable dt = new DataTable();
                query.Fill(dt);

                lblTittle.Text = "";
                lblAuthor.Text = "";
                rtbDescription.Text = "";
                lblbCategories.Text = "";

                lblTittle.Text = dt.Rows[0].ItemArray[0].ToString();
                lblAuthor.Text = dt.Rows[0].ItemArray[1].ToString();
                rtbDescription.Text = dt.Rows[0].ItemArray[2].ToString();
                lblbCategories.Text = dt.Rows[0].ItemArray[3].ToString();
            }
            catch (Exception)
            { }
            conn.Close();

        }

        private void cbFacultyID_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbStudentID.Enabled = false;
              if (cbFacultyID.Text == " " || cbFacultyID.Text == "")
            {
                cbStudentID.Enabled = true;
            }
            try
            {
                conn.Open();
                MySqlDataAdapter query = new MySqlDataAdapter("Select Faculty_Image , FullName,College_Dept  From facultyinfo Where FID = '" + cbFacultyID.Text + "' ", conn);
                DataTable dt = new DataTable();
                query.Fill(dt);

                pbPersonImage.Image = null;
                lblFacultyName.Text = "";
                lblDepartment.Text = "";


                lblFacultyName.Text = dt.Rows[0].ItemArray[1].ToString();
                lblDepartment.Text = dt.Rows[0].ItemArray[2].ToString();
                byte[] image = (byte[])dt.Rows[0].ItemArray[0];

                MemoryStream ms = new MemoryStream(image);
                pbPersonImage.Image = Image.FromStream(ms);
            }
            catch (Exception)
            { }
            conn.Close();
          
        }

        private void cbStudentID_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbFacultyID.Enabled = false;
            if (cbStudentID.Text == " " || cbStudentID.Text == "")
            {
                cbFacultyID.Enabled = true;
            }
            try
            {
                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT Student_Image, FullName, College_Dept FROM studentinfo where ID ='" + cbStudentID.Text + "' ", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                pbPersonImage.Image = null;
                lblStudentName.Text = "";
                lblDepartment.Text = "";

                lblStudentName.Text = dt.Rows[0].ItemArray[1].ToString();
                lblDepartment.Text = dt.Rows[0].ItemArray[2].ToString();



                byte[] image = (byte[])dt.Rows[0].ItemArray[0];


                MemoryStream ms = new MemoryStream(image);
                pbPersonImage.Image = Image.FromStream(ms);

            }
            catch (Exception)
            { }
            conn.Close();
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // var dt12 = dtpReturn.Value;

            if (dtpReturn.CustomFormat == "yyyy-MM-dd hh:mm tt")
            {
                var dt12 = dtpReturn.Value;

            }



            string FID = cbFacultyID.Text;
            string SID = cbStudentID.Text;
            string Fname = lblFacultyName.Text;
            string Sname = lblStudentName.Text;
            string Name = Fname + Sname;

            string Btittle = lblTittle.Text;
            string issued = txtTimeIssued.Text;
            string Return = dtpReturn.Text;
            string department = lblDepartment.Text;
            string categories = lblbCategories.Text;

            // DateTime dtnow = DateTime.Now;



            bool isvalid = true;



            if (Fname.Trim().Length <= 2 && Sname.Trim().Length <= 2)
            {
                MessageBox.Show("Input Name");
                isvalid = false;
            }


            if (Fname != "" && Sname != "")
            {
                MessageBox.Show("One Person Only");
                isvalid = false;
            }


            if (Btittle.Trim().Length <= 2)
            {
                MessageBox.Show("Input Tittle");
                isvalid = false;
            }

            DateTime dateissue = DateTime.Now;
            var datereturn = dtpReturn.Value;

            //if (dateissue >= datereturn)
            //{
            //    MessageBox.Show("Date Return is Greater than date issued.");
            //    isvalid = false;
            //}

            if (isvalid)
            {
                conn.Open();
                string cmdstring = "Insert Into bookissued(StudentID, FacultyID, Student_name,Book_Tittle, Book_Issued,Book_Return, Book_Status, ISBN_no, Department, Book_Categories) Values ( @sid, @fid, @Pname, @BTittle, @issued, @BReturn ,@status, '" + cbISBN.Text + "' , @department, @Categories)";
                MySqlCommand cmd = new MySqlCommand(cmdstring, conn);

                cmd.Parameters.AddWithValue("@sid", SID);
                cmd.Parameters.AddWithValue("@fid", FID);
                cmd.Parameters.AddWithValue("@Pname", Name);
                cmd.Parameters.AddWithValue("@BTittle", Btittle);
                cmd.Parameters.AddWithValue("@issued", issued);
                cmd.Parameters.AddWithValue("@BReturn", Return);
                cmd.Parameters.AddWithValue("@status", "Borrowed");
                cmd.Parameters.AddWithValue("@department", department);
                cmd.Parameters.AddWithValue("@Categories", categories);

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show(Name + " Inserted succesfully");
                    conn.Close();
                    PopulateTable();
                    ClearField();

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error" + ex);
                }
            }

            try
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand("Update table_inventorybooks SET  Book_quantity = Book_quantity -1 WHERE ISBN_no = '" + cbISBN.Text + "' ", conn);

                cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(""+ ex);
            }
            
            
        }

        private void button2_Click(object sender, EventArgs e)
        {


            String CurrentBID = dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[0].Value.ToString();

            DataGridViewCellStyle style = new DataGridViewCellStyle();
            style.ForeColor = Color.Red;

            dataGridView1.Rows[0].Cells[4].Style = style;


            //string text = DateTime.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture);


            DateTime dt2 = DateTime.Now;
            dt2.ToString("yyyy-MM-dd hh:mm tt", CultureInfo.InvariantCulture);
            
           

            var hours = (dt2 - mydt).TotalHours;
            var days = (dt2 - mydt).TotalDays;

            label11.Text = hours.ToString("0");
            //if (hours >= 0)
            //{
            //    var totals = hours * 2;


            //    try
            //    {
            //        conn.Open();
            //        MySqlCommand cmd = new MySqlCommand("Update bookissued SET Fine = @fine WHERE IDissued = " + CurrentBID, conn);


            //        cmd.Parameters.AddWithValue("@fine", totals);
            //        cmd.ExecuteNonQuery();

            //    }
            //    catch (Exception ex)
            //    {
            //        MessageBox.Show("" + ex);
            //    }
            //    conn.Close();
            //    PopulateTable();
            //}






            // lblfineInput.Text = days.ToString();


            //if (days >= 0)
            //{
            //    var dtotals = days * 5;
            //    lblfineInput.Text = dtotals.ToString("0");
            //}
            //else
            //{
            //    lblfineInput.Text = "0";

            //}

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            try
            {
                mydt = Convert.ToDateTime(dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString());
            }
            catch(Exception ex)
            { }


        }

        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            //DateTime dt2 = DateTime.Now;
            //dt2.ToString("yyyy-MM-dd hh:mm tt", CultureInfo.InvariantCulture);

            //try
            //{
            //        conn.Open();
            //    MySqlCommand cmd = new MySqlCommand("Update bookissued SET Book_Status = @statuse WHERE Book_Return <='"+dt2+"' " , conn); 
            //        cmd.Parameters.AddWithValue("@statuse", "Expired");
            //        cmd.ExecuteNonQuery();

            //    }
            //    catch (Exception ex)
            //    {
            //        MessageBox.Show("" + ex);
            //    }
            //    conn.Close();
            //    PopulateTable();
            //    ClearField();
            PopulateTable();
        }

        private void cbFacultyID_TextChanged(object sender, EventArgs e)
        {
            if (cbFacultyID.Text == "")
            {
                cbStudentID.Enabled = true;
                lblDepartment.Text = "";
                lblFacultyName.Text = "";
                pbPersonImage.Image = null;
            }
        }

        private void cbStudentID_TextChanged(object sender, EventArgs e)
        {
            if (cbStudentID.Text == "")
            {
                cbFacultyID.Enabled = true;
                lblDepartment.Text = "";
                lblStudentName.Text = "";
                pbPersonImage.Image = null;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
            txtTimeIssued.Text = DateTime.Now.ToString("yyyy-MM-dd hh:mm tt") ;
            timer1.Start();
        }
    }
}
