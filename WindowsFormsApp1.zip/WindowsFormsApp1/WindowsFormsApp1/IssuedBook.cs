﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp1
{
    public partial class IssuedBook : Form
    {

        MySqlConnection conn = new MySqlConnection("server=127.0.0.1;port=3306;username=root;password=root123;database=librarydb");

        DateTime mydt;
        String bookclick;


        public IssuedBook()
        {
            InitializeComponent();


        }



        private void PopulateTable()
        {
            try
            {

                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT IDissued as 'ID No', Student_name as 'Person Name', Book_Tittle as 'Book Tittle', Book_Issued as 'Book Issued', Book_Return as 'Book Return',Book_Status as 'Book Status' , Fine FROM bookissued", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;

                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
        }
        private void ClearField()
        {
                    cbFacultyID.SelectedIndex = -1;
                    cbISBN.SelectedIndex = -1;
                    cbStudentID.SelectedIndex = -1;
                    lblFacultyName.Text = "";
                    lblStudentName.Text = "";
                    lblTittle.Text = "";
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void IssuedBook_Load(object sender, EventArgs e)
        {
            
            //lbltotalhours.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm");


            //String CurrentBID = dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[0].Value.ToString();

            PopulateTable();
            dtpReturn.Value = DateTime.Now;


    
            //-------------------------------------------+++++++++++++=ComboboxBooks=++++++++++++++++++++==+++---------------



            try
            {
                string sqlquery = "Select * From table_inventorybooks Where NOT Book_Status = 'Lost'";
                conn.Open();
                MySqlCommand command = new MySqlCommand(sqlquery, conn);
                MySqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    cbISBN.Items.Add(reader.GetString("ISBN_no"));
                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("error" + ex);

            }


            //---------------------------+++++++++++++=ComboBox Faculty ID=+++++++++++++++++---------------------------------


            


            try
            {
                string sqlquery = "SELECT * FROM facultyinfo";
                conn.Open();
                MySqlCommand command = new MySqlCommand(sqlquery, conn);
                MySqlDataReader reader = command.ExecuteReader();

                //string MembersID = reader["ID"]  +,+ reader["FID"];

                while (reader.Read())
                {
                    cbFacultyID.Items.Add(reader.GetString("FID"));
                    

                }
                command.Dispose();
                reader.Close();
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("error" + ex);

            }


            //---------------------------------------++++++++ComboBox Student ID++++++++++----------------------------------------


            try
            {
                string sqlquery = "SELECT * FROM studentinfo";
                conn.Open();
                MySqlCommand command = new MySqlCommand(sqlquery, conn);
                MySqlDataReader reader = command.ExecuteReader();


                while (reader.Read())
                {
                    cbStudentID.Items.Add(reader.GetString("ID"));


                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("error" + ex);

            }

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void cbISBN_SelectedIndexChanged(object sender, EventArgs e)
        {

            try
            {
                conn.Open();
                string sqlquery = "Select * From table_inventorybooks Where ISBN_no = '" + cbISBN.Text + "' ";

                MySqlCommand command = new MySqlCommand(sqlquery, conn);
                MySqlDataReader reader = command.ExecuteReader();


                while (reader.Read())
                {
                    lblTittle.Text = reader.GetString("Name_of_Book");
                }



                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("error" + ex);

            }

        }

        private void cbFacultyID_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            try
            {
                conn.Open();
                string sqlquery = "Select * From facultyinfo Where FID = '" + cbFacultyID.Text + "' ";

                MySqlCommand command = new MySqlCommand(sqlquery, conn);
                MySqlDataReader reader = command.ExecuteReader();


                while (reader.Read())
                {
                    lblFacultyName.Text = reader.GetString("FullName");
                    
                }


                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("error" + ex);

            }

           
        }

        private void cbStudentID_SelectedIndexChanged(object sender, EventArgs e)
        {


            try
            {
                conn.Open();
                string sqlquery = "Select * From studentinfo Where ID = '" + cbStudentID.Text + "' ";

                MySqlCommand command = new MySqlCommand(sqlquery, conn);
                MySqlDataReader reader = command.ExecuteReader();


                while (reader.Read())
                {
                    lblStudentName.Text = reader.GetString("FullName");
                }


                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("error" + ex);

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {



            string FID = cbFacultyID.Text;
            string SID = cbStudentID.Text;
            string Fname = lblFacultyName.Text;
            string Sname = lblStudentName.Text;
            string Name = Fname + Sname;

            string Btittle = lblTittle.Text;
            string Return = dtpReturn.Text;

          

            

            bool isvalid = true;



           if (Fname.Trim().Length <= 2 && Sname.Trim().Length <= 2)
            {
                MessageBox.Show("Input Name");
                isvalid = false;
            }


           if (Fname != "" && Sname != "")
            {
                MessageBox.Show("One Person Only");
                isvalid = false;
            }


           if (Btittle.Trim().Length <= 2 )
            {
                MessageBox.Show("Input Tittle");
                isvalid = false;
            }


            if (isvalid)
            {
                conn.Open();
                string cmdstring = "Insert Into bookissued(StudentID, FacultyID, Student_name,Book_Tittle,Book_Return) Values ( @sid, @fid, @Pname, @BTittle, @BReturn )";
                MySqlCommand cmd = new MySqlCommand(cmdstring, conn);

                cmd.Parameters.AddWithValue("@sid", SID);
                cmd.Parameters.AddWithValue("@fid", FID);
                cmd.Parameters.AddWithValue("@Pname", Name);
                cmd.Parameters.AddWithValue("@BTittle", Btittle);
                //cmd.Parameters.AddWithValue("@BIssued", issued);
                cmd.Parameters.AddWithValue("@BReturn", Return);

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show(Name + " Inserted succesfully");
                    conn.Close();
                    PopulateTable();

                    //-------------------------------------------------=============ClearField===============---------------------------------------------------
                    ClearField();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error" + ex);
                }

              
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {


            String CurrentBID = dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[0].Value.ToString();

            DataGridViewCellStyle style = new DataGridViewCellStyle();
            style.ForeColor = Color.Red;

            dataGridView1.Rows[0].Cells[4].Style = style;


            //string text = DateTime.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture);


            DateTime dt2 = DateTime.Now;
            dt2.ToString("yyyy-MM-dd hh:mm", CultureInfo.InvariantCulture);
            
            var hours = (dt2 - mydt).TotalHours;
            var days = (dt2 - mydt).TotalDays;

           // lbltotalhours.Text = hours.ToString("0"); 
            //lblfineInput.Text = dt2.ToString();
            if (hours >= 0)
            {
                var totals = hours * 2;
                //lbltotalhours.Text = totals.ToString("0");
                try
                {
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand("Update bookissued SET Fine = @fine WHERE IDissued == " + CurrentBID, conn);


                    cmd.Parameters.AddWithValue("@fine", totals);
                    cmd.ExecuteNonQuery();

                }
                catch (Exception ex)
                {
                    MessageBox.Show("" + ex);
                }
                conn.Close();
                PopulateTable();
            }

            //else
            //{
            //    lbltotalhours.Text = "0";
            //}




           // lblfineInput.Text = days.ToString();


            //if (days >= 0)
            //{
            //    var dtotals = days * 5;
            //    lblfineInput.Text = dtotals.ToString("0");
            //}
            //else
            //{
            //    lblfineInput.Text = "0";

            //}

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            try
            {
                mydt = Convert.ToDateTime(dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString());
            }
            catch(Exception ex)
            { }


        }

        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            
            try
            {
                    conn.Open();
                MySqlCommand cmd = new MySqlCommand("Update bookissued SET Book_Status = @statuse WHERE Book_Return <= now() " , conn); 
                    cmd.Parameters.AddWithValue("@statuse", "Expired");
                    cmd.ExecuteNonQuery();

                }
                catch (Exception ex)
                {
                    MessageBox.Show("" + ex);
                }
                conn.Close();
                PopulateTable();
                ClearField();
        }

        private void cbFacultyID_DropDown(object sender, EventArgs e)
        {
            
        }


    }
}
