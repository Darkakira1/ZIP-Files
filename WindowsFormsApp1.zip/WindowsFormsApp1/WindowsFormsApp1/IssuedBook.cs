﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;
using System.Numerics;

namespace WindowsFormsApp1
{
    public partial class IssuedBook : Form
    {

        MySqlConnection conn = new MySqlConnection("server=127.0.0.1;port=3306;username=root;password=root123;database=librarydb");

        DateTime mydt;
        //String bookclick;

        public static IssuedBook instance1;
        public DataGridView Idgv;
        public ComboBox cbstudent;
        public ComboBox cbfaculty;
        public ComboBox cbaccession;
        //public Label Ilabel;

        public IssuedBook()
        {
            InitializeComponent();

            instance1 = this;
            Idgv = dataGridView1;
            cbstudent = cbStudentID;
            cbaccession = cbAccessionNo;
            cbfaculty = cbFacultyID1;
        }



        private void PopulateTable()
        {
            try
            {

                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT IDissued as 'Issued No', Student_name as 'Person Name', Book_Tittle as 'Book Tittle', Book_Issued as 'Book Issued', Book_Return as 'Book Return'  FROM bookissued Where  Book_Status = 'Borrowed' ", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            conn.Close();
        }
        private void ClearField()
        {
            cbFacultyID1.SelectedIndex = 0;
            cbAccessionNo.SelectedIndex = 0;
            cbStudentID.SelectedIndex = 0;
            lblFacultyName.Text = "";
            lblStudentName.Text = "";
            lblTittle.Text = "";
            lblISBN.Text = "";
            lblAuthor.Text = "";
            lblbCategories.Text = "";
        }

        private void quantity()
        {
            try
            {
                conn.Open();
                MySqlCommand cmd1 = new MySqlCommand("Update table_inventorybooks SET  Book_quantity = Book_quantity - 1 WHERE Accession‎_No = '" + cbAccessionNo.Text + "'", conn);
                cmd1.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("" + ex);
                conn.Close();
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void IssuedBook_Load(object sender, EventArgs e)
        {


            PopulateTable();
            dtpReturn.Value = DateTime.Now;

            timer1.Start();
            txtTimeIssued.Text = DateTime.Now.ToString() ;

            cbStudentID.SelectedIndex = 0;
            cbFacultyID1.SelectedIndex = 0;
            cbAccessionNo.SelectedIndex = 0;


         

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

  

        private void cbFacultyID_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            cbStudentID.Enabled = false;
              if (cbFacultyID1.SelectedIndex == 0 || cbFacultyID1.Text == "")
            {
                cbStudentID.SelectedIndex = 0;
                cbStudentID.Enabled = true;
            }
            try
            {
                conn.Open();
                MySqlDataAdapter query = new MySqlDataAdapter("Select Faculty_Image , FullName,College_Dept  From facultyinfo Where FID = '" + cbFacultyID1.Text + "' ", conn);
                DataTable dt = new DataTable();
                query.Fill(dt);

                pbPersonImage.Image = null;
                lblFacultyName.Text = "";
                lblDepartment.Text = "";


                lblFacultyName.Text = dt.Rows[0].ItemArray[1].ToString();
                lblDepartment.Text = dt.Rows[0].ItemArray[2].ToString();
                byte[] image = (byte[])dt.Rows[0].ItemArray[0];

                MemoryStream ms = new MemoryStream(image);
                pbPersonImage.Image = Image.FromStream(ms);
            }
            catch (Exception)
            { }
            conn.Close();
          
        }

        private void cbStudentID_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbFacultyID1.Enabled = false;
            if (cbStudentID.SelectedIndex == 0 || cbStudentID.Text == "")
            {
                cbFacultyID1.SelectedIndex = 0;
                cbFacultyID1.Enabled = true;
            }
            try
            {
                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT Student_Image, FullName, College_Dept FROM studentinfo where ID ='" + cbStudentID.Text + "' ", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);

                pbPersonImage.Image = null;
                lblStudentName.Text = "";
                lblDepartment.Text = "";

                lblStudentName.Text = dt.Rows[0].ItemArray[1].ToString();
                lblDepartment.Text = dt.Rows[0].ItemArray[2].ToString();



                byte[] image = (byte[])dt.Rows[0].ItemArray[0];


                MemoryStream ms = new MemoryStream(image);
                pbPersonImage.Image = Image.FromStream(ms);

            }
            catch (Exception)
            { }
            conn.Close();
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
          

            string FID = cbFacultyID1.Text;
            string SID = cbStudentID.Text;
            string Fname = lblFacultyName.Text;
            string Sname = lblStudentName.Text;
            string Name = Fname + Sname;

            string Btittle = lblTittle.Text;
            string issued = txtTimeIssued.Text;
            string Return = dtpReturn.Text;
            string department = lblDepartment.Text;
            string categories = lblbCategories.Text;

            // DateTime dtnow = DateTime.Now;


           
            MySqlDataAdapter query = new MySqlDataAdapter("Select Book_quantity From table_inventorybooks Where Accession‎_No = '"+cbAccessionNo.Text+"' " , conn);
            DataTable dt = new DataTable();
            query.Fill(dt);


            int quantityofbooks = Convert.ToInt32(dt.Rows[0].ItemArray[0].ToString());


            bool isvalid = true;

            do
            {

                if (Fname.Trim().Length <= 2 && Sname.Trim().Length <= 2)
                {
                    MessageBox.Show("Input Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    isvalid = false;
                    break;
                }


                if (Fname != "" && Sname != "")
                {
                    MessageBox.Show("One Person Only", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    isvalid = false;
                    break;
                }


                if (Btittle.Trim().Length <= 2)
                {
                    MessageBox.Show("Input Tittle", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    isvalid = false;
                    break;
                }

                DateTime dateissue = DateTime.Now;
                var datereturn = dtpReturn.Value;

                if (dateissue >= datereturn)
                {
                    MessageBox.Show("Date Return is Greater than date issued." , "Error" , MessageBoxButtons.OK, MessageBoxIcon.Error);
                    isvalid = false;
                    break;
                }
                if (quantityofbooks <= 0 )
                {
                    MessageBox.Show("No Stocks of books!");
                    isvalid = false;
                    break;
                }

                

                if (isvalid && quantityofbooks > 0 )
                {
                    DialogResult dr = MessageBox.Show("Books Issued", "Issued Books", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
                    if (dr == DialogResult.OK)
                    {
                        conn.Open();
                        string cmdstring = "Insert Into bookissued(StudentID, FacultyID, Student_name,Book_Tittle, Book_Issued,Book_Return, Book_Status, ISBN_no, Department, Book_Categories, Accession_no) Values ( @sid, @fid, @Pname, @BTittle, @issued, @BReturn ,@status, '" + lblISBN.Text + "' , @department, @Categories, '" + cbAccessionNo.Text + "')";
                        MySqlCommand cmd = new MySqlCommand(cmdstring, conn);

                        if (cbFacultyID1.Text == "  --Select Faculty ID --")
                        {
                            FID = "";
                        }
                        if (cbStudentID.Text == "  --Select Student ID--")
                        {
                            SID = "";
                        }
                        cmd.Parameters.AddWithValue("@sid", SID);
                        cmd.Parameters.AddWithValue("@fid", FID);
                        cmd.Parameters.AddWithValue("@Pname", Name);
                        cmd.Parameters.AddWithValue("@BTittle", Btittle);
                        cmd.Parameters.AddWithValue("@issued", issued);
                        cmd.Parameters.AddWithValue("@BReturn", Return);
                        cmd.Parameters.AddWithValue("@status", "Borrowed");
                        cmd.Parameters.AddWithValue("@department", department);
                        cmd.Parameters.AddWithValue("@Categories", categories);

                        try
                        {
                            cmd.ExecuteNonQuery();

                            conn.Close();
                            quantity();
                            PopulateTable();
                            ClearField();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error" + ex);
                            conn.Close();
                        }
                    }
                    else if (dr == DialogResult.Cancel) { }
                }
            } while (false);



        }

      

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            try
            {
                mydt = Convert.ToDateTime(dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString());
            }
            catch(Exception ex)
            { }


        }

        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            
        }


        private void cbFacultyID_TextChanged_1(object sender, EventArgs e)
        {
            if (cbFacultyID1.Text == ""|| cbFacultyID1.SelectedIndex == 0)
            {
                cbStudentID.Enabled = true;
                lblDepartment.Text = "";
                lblFacultyName.Text = "";
                pbPersonImage.Image = null;
            }
        }

        private void cbStudentID_TextChanged(object sender, EventArgs e)
        {
            if (cbStudentID.Text == "" || cbStudentID.SelectedIndex == 0)
            {
                cbFacultyID1.Enabled = true;
                lblDepartment.Text = "";
                lblStudentName.Text = "";
                pbPersonImage.Image = null;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
            txtTimeIssued.Text = DateTime.Now.ToString("yyyy-MM-dd hh:mm tt") ;
            timer1.Start();
        }

        private void cbAccessionNo_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                MySqlDataAdapter query = new MySqlDataAdapter("Select Name_of_Book, Book_Author, Book_Categories, ISBN_no  From table_inventorybooks Where Accession‎_No = '" + cbAccessionNo.Text + "'", conn);
                DataTable dt = new DataTable();
                query.Fill(dt);

                lblTittle.Text = "";
                lblAuthor.Text = "";
                lblbCategories.Text = "";
                lblISBN.Text = "";



                lblTittle.Text = dt.Rows[0].ItemArray[0].ToString();
                lblAuthor.Text = dt.Rows[0].ItemArray[1].ToString();
                
                lblbCategories.Text = dt.Rows[0].ItemArray[2].ToString();
                lblISBN.Text = dt.Rows[0].ItemArray[3].ToString();
            }
            catch (Exception)
            { }
            conn.Close();
        }

      
    }
}
