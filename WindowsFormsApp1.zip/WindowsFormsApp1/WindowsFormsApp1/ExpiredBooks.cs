﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;
using System.Globalization;

namespace WindowsFormsApp1
{
    public partial class ExpiredBooks : Form
    {
        public static ExpiredBooks instance;
        public DataGridView Edgv;
        public Label lblexpired;

        MySqlConnection conn = new MySqlConnection("server=127.0.0.1;port=3306;username=root;password=root123;database=librarydb");

        DateTime mydt;
        DateTime mydt1;
        public ExpiredBooks()
        {
            InitializeComponent();
        }
        private void PopulateTable()
        {
            try
            {

                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT IDissued as 'Issued No', Student_name as 'Person Name', ISBN_no as 'ISBN No.',Book_Tittle as 'Book Tittle', Book_Issued as 'Book Issued', Book_Return as 'Book Return',Book_Status as 'Book Status' FROM bookissued Where Not Book_Status = 'Return'", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dgvIssuedBooks.DataSource = dt;



            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            conn.Close();
        }

        private void clearfield()
        {
            txtIsbn.Text = "";
            txtTittle.Text = "";
            txtCategories.Text = "";
            txtName.Text = "";
            txtDepartment.Text = "";
            txtElapse.Text = "";
            txtFine.Text = "";


            
        }
        private void ExpiredBooks_Load(object sender, EventArgs e)
        {
            PopulateTable();
            instance = this;
            Edgv = dgvIssuedBooks;
            //lblexpired

            DateTime dateTime = new DateTime();
            label2.Text = dateTime.ToLongDateString() ;
 
        }

        private void dgvIssuedBooks_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                mydt = Convert.ToDateTime(dgvIssuedBooks.Rows[e.RowIndex].Cells[4].Value.ToString());
            }
            catch (Exception ex)
            { }

           
            lblIssuedNo.Text = dgvIssuedBooks.Rows[dgvIssuedBooks.CurrentCell.RowIndex].Cells[0].Value.ToString();
        }


        private void btnreturn_Click(object sender, EventArgs e)
        {

            string fn = txtFine.Text;
            var dt = DateTime.Now.ToString("yyyy-MM-dd hh:mm tt");


            DialogResult dr = MessageBox.Show("Returned Books?", "Returning Book", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dr == DialogResult.Yes)
            {

                try
                {
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand("Update bookissued SET Book_Status = @status, Fine = @fine, Return_time = @rTime WHERE IDissued = '" + lblIssuedNo.Text + "' ", conn);

                    cmd.Parameters.AddWithValue("@status", "Return");
                    cmd.Parameters.AddWithValue("@fine", fn);
                    cmd.Parameters.AddWithValue("@rTime", dt);
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("" + ex);
                }
                conn.Close();
                PopulateTable();
                clearfield();
            }
            else if (dr == DialogResult.No) 
            { }
        }

        private void btnSearchId_Click(object sender, EventArgs e)
        {
            try
            {

                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT IDissued as 'Issued No', Student_name as 'Person Name', ISBN_no as 'ISBN No.',Book_Tittle as 'Book Tittle', Book_Issued as 'Book Issued', Book_Return as 'Book Return',Book_Status as 'Book Status' FROM bookissued Where StudentID = '"+txtSnumber.Text+ "' And Not Book_Status = 'Return' And FacultyID = '"+txtFnumber.Text+"' And Not Book_Status = 'Return'", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dgvIssuedBooks.DataSource = dt;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            conn.Close();
        }

        private void lblIssuedNo_TextChanged(object sender, EventArgs e)
        {

            txtTittle.Text = "";
            txtCategories.Text = "";
            txtSnumber.Text = "";
            txtFnumber.Text = "";
            txtName.Text = "";
            txtDepartment.Text = "";
            txtIsbn.Text = "";
            txtAccession.Text = "";
            try
            {

                conn.Open();
                MySqlDataAdapter query = new MySqlDataAdapter("Select StudentID, FacultyID, Student_name, Department, Book_Tittle, Book_Categories, Fine, Book_Return, ISBN_no, Accession_no From bookissued Where IDissued = '" + lblIssuedNo.Text + "' And Not Book_Status = 'Return' ", conn);
                DataTable dt = new DataTable();
                query.Fill(dt);

                

                string student = dt.Rows[0].ItemArray[0].ToString();
                string faculty = dt.Rows[0].ItemArray[1].ToString();
                string membersname = dt.Rows[0].ItemArray[2].ToString();
                string department = dt.Rows[0].ItemArray[3].ToString();
                string tittle = dt.Rows[0].ItemArray[4].ToString();
                string categories = dt.Rows[0].ItemArray[5].ToString();
                string fine = dt.Rows[0].ItemArray[6].ToString();
                string ISBN = dt.Rows[0].ItemArray[8].ToString();
                string accession = dt.Rows[0].ItemArray[9].ToString();


                txtTittle.Text = tittle;
                txtCategories.Text = categories;
                txtSnumber.Text = student;
                txtFnumber.Text = faculty;
                txtName.Text = membersname;
                txtDepartment.Text = department;
                txtIsbn.Text = ISBN;
                txtAccession.Text = accession;
             

                mydt1 = Convert.ToDateTime(dt.Rows[0].ItemArray[7].ToString());

                DateTime dt2 = DateTime.Now;  
                //var hours = (dt2 - mydt1).TotalHours;
  
                TimeSpan x = dt2 - mydt1;
                double days = x.TotalDays;
                double hours = x.TotalHours;


                
                int numOfWeek = (int)Math.Floor(x.TotalDays / 7);
                hours = hours - (numOfWeek * 24);
                days = days - (numOfWeek * 7);
                // if difference is more than 1 week, then subtract hours with week difference

                DayOfWeek dt1_dow = mydt1.DayOfWeek; // System.DayOfWeek is enum, 0=Sunday, 1=Monday, etc
                DayOfWeek dt2_dow = dt2.DayOfWeek; // System.DayOfWeek is enum, 0=Sunday, 1=Monday, etc
                if ((int)dt1_dow > (int)dt2_dow)
                {
                    hours = hours - 24;
                    days = days - 1;
                   
                }

                if (days >= 0 && categories == "General References" || categories == "Nursing")
                {
                    
                    txtElapse.Text = days.ToString("0");
                    Decimal val1 = Decimal.Truncate((decimal)days);
                    var totals = val1 * 5;
                   
                    txtFine.Text = totals.ToString();
                }
                else if (days >= 0 && categories == "Reserved Books")
                {
                    txtElapse.Text = hours.ToString("0");
                    decimal val2 = decimal.Truncate((decimal)hours);
                    var totalhours = val2 * 2;

                    txtFine.Text = totalhours.ToString();
                }
                else
                {
                    txtFine.Text = "0";
                    txtElapse.Text = "0";
                }




            }
            catch (Exception)
            { }
            conn.Close();

            if (lblIssuedNo.Text == "")
            {
                clearfield();
            }
          
        }
        private void dgvIssuedBooks_KeyUp(object sender, KeyEventArgs e)
        {
            lblIssuedNo.Text = dgvIssuedBooks.Rows[dgvIssuedBooks.CurrentCell.RowIndex].Cells[0].Value.ToString();
        }

        private void dgvIssuedBooks_KeyDown(object sender, KeyEventArgs e)
        {
            lblIssuedNo.Text = dgvIssuedBooks.Rows[dgvIssuedBooks.CurrentCell.RowIndex].Cells[0].Value.ToString();
        }
        private void txtSnumber_TextChanged(object sender, EventArgs e)
        {
          if (txtSnumber.Text != "")
          {
             txtFnumber.Enabled = false;
          }
          else if (txtSnumber.Text == "")
          {
             txtFnumber.Enabled = true;
             clearfield();
          }
        }

        private void txtFnumber_TextChanged(object sender, EventArgs e)
        {
            if (txtFnumber.Text != "")
            {
                txtSnumber.Enabled = false;
            }
            else if (txtFnumber.Text == "")
            {
                txtSnumber.Enabled = true;
                clearfield();
            }
        }

        private void btnAccessionNo_Click(object sender, EventArgs e)
        {
            
            try
            {
                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT IDissued as 'Issued No', Student_name as 'Person Name', Accession_no as 'Accession No.',Book_Tittle as 'Book Tittle', Book_Issued as 'Book Issued', Book_Return as 'Book Return',Book_Status as 'Book Status' FROM bookissued Where Accession_no = '" + txtAccession.Text + "' And Not Book_Status = 'Return'", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dgvIssuedBooks.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            conn.Close();
        }
    }
}
