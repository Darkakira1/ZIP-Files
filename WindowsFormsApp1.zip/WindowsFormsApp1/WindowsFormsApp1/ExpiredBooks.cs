﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;
using System.Globalization;

namespace WindowsFormsApp1
{
    public partial class ExpiredBooks : Form
    {
        public static ExpiredBooks instance;
        public DataGridView Edgv;
        public Label lblexpired;

        MySqlConnection conn = new MySqlConnection("server=127.0.0.1;port=3306;username=root;password=root123;database=librarydb");

        DateTime mydt;
        DateTime mydt1;
        public ExpiredBooks()
        {
            InitializeComponent();
        }
        private void PopulateTable()
        {
            try
            {

                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT IDissued as 'Issued No', Student_name as 'Person Name', ISBN_no as 'ISBN No.',Book_Tittle as 'Book Tittle', Book_Issued as 'Book Issued', Book_Return as 'Book Return',Book_Status as 'Book Status' FROM bookissued Where Not Book_Status = 'Return'", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dgvIssuedBooks.DataSource = dt;



            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            conn.Close();
        }

        private void clearfield()
        {
            txtIsbn.Text = "";
            txtTittle.Text = "";
            txtCategories.Text = "";
            txtName.Text = "";
            txtDepartment.Text = "";
            txtElapse.Text = "";
            txtFine.Text = "";


            
        }
        private void ExpiredBooks_Load(object sender, EventArgs e)
        {
            PopulateTable();
            instance = this;
            Edgv = dgvIssuedBooks;
            //lblexpired

            DateTime dateTime = new DateTime();
            label2.Text = dateTime.ToLongDateString() ;
 
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {


            //DateTime dtstatus = DateTime.Now;
            //dtstatus.ToString("dd-MM-yyyy hh:mm tt", CultureInfo.InvariantCulture);

            //label1.Text = DateTime.Now.ToString();
            try
            {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand("Update bookissued SET Book_Status = @statuse WHERE Book_Return <= '" + DateTime.Now.ToString("dd-MM-yyyy hh:mm tt") + "' And Not Book_Status = 'Return'", conn);
                cmd.Parameters.AddWithValue("@statuse", "OverDue");
                cmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                MessageBox.Show("" + ex);
            }
            conn.Close();
            PopulateTable();


           
            //DataGridViewCellStyle style = new DataGridViewCellStyle();
            //style.ForeColor = Color.Red;

            //dgvIssuedBooks.Rows[0].Cells[4].Style = style;


            //string text = DateTime.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture);      
            //label1.Text = hours.ToString("0");


        }

        private void dgvIssuedBooks_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                mydt = Convert.ToDateTime(dgvIssuedBooks.Rows[e.RowIndex].Cells[4].Value.ToString());
            }
            catch (Exception ex)
            { }

           
            lblIssuedNo.Text = dgvIssuedBooks.Rows[dgvIssuedBooks.CurrentCell.RowIndex].Cells[0].Value.ToString();
        }


        private void btnreturn_Click(object sender, EventArgs e)
        {

            try
            {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand("Update bookissued SET Book_Status = @status WHERE IDissued = '" + lblIssuedNo.Text + "' ", conn);

                cmd.Parameters.AddWithValue("@status", "Return");
                cmd.ExecuteNonQuery();
                MessageBox.Show("Book is Return");
            }
            catch (Exception ex)
            {
                MessageBox.Show("" + ex);
            }
            conn.Close();
            PopulateTable();
            clearfield();
        }

        private void btnSearchId_Click(object sender, EventArgs e)
        {
            try
            {

                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT IDissued as 'Issued No', Student_name as 'Person Name', ISBN_no as 'ISBN No.',Book_Tittle as 'Book Tittle', Book_Issued as 'Book Issued', Book_Return as 'Book Return',Book_Status as 'Book Status' FROM bookissued Where StudentID = '"+txtSnumber.Text+ "' And Not Book_Status = 'Return' And FacultyID = '"+txtFnumber.Text+"' And Not Book_Status = 'Return'", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dgvIssuedBooks.DataSource = dt;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            conn.Close();
        }

        private void lblIssuedNo_TextChanged(object sender, EventArgs e)
        {

            txtTittle.Text = "";
            txtCategories.Text = "";
            txtSnumber.Text = "";
            txtFnumber.Text = "";
            txtName.Text = "";
            txtDepartment.Text = "";
            txtIsbn.Text = "";
            try
            {

                conn.Open();
                MySqlDataAdapter query = new MySqlDataAdapter("Select StudentID, FacultyID, Student_name, Department, Book_Tittle, Book_Categories, Fine, Book_Return, ISBN_no From bookissued Where IDissued = '" + lblIssuedNo.Text + "' And Not Book_Status = 'Return' ", conn);
                DataTable dt = new DataTable();
                query.Fill(dt);

                

                string student = dt.Rows[0].ItemArray[0].ToString();
                string faculty = dt.Rows[0].ItemArray[1].ToString();
                string membersname = dt.Rows[0].ItemArray[2].ToString();
                string department = dt.Rows[0].ItemArray[3].ToString();
                string tittle = dt.Rows[0].ItemArray[4].ToString();
                string categories = dt.Rows[0].ItemArray[5].ToString();
                string fine = dt.Rows[0].ItemArray[6].ToString();
                string ISBN = dt.Rows[0].ItemArray[8].ToString();


                txtTittle.Text = tittle;
                txtCategories.Text = categories;
                txtSnumber.Text = student;
                txtFnumber.Text = faculty;
                txtName.Text = membersname;
                txtDepartment.Text = department;
                txtIsbn.Text = ISBN;
             

                mydt1 = Convert.ToDateTime(dt.Rows[0].ItemArray[7].ToString());

                DateTime dt2 = DateTime.Now;


              

              
                
                //var hours = (dt2 - mydt1).TotalHours;


              
                TimeSpan x = dt2 - mydt1;
                double hours = x.TotalHours;

                int numOfWeek = (int)Math.Floor(x.TotalDays / 7);
                hours = hours - (numOfWeek * 24);
                // if difference is more than 1 week, then subtract hours with week difference

                DayOfWeek dt1_dow = mydt1.DayOfWeek; // System.DayOfWeek is enum, 0=Sunday, 1=Monday, etc
                DayOfWeek dt2_dow = dt2.DayOfWeek; // System.DayOfWeek is enum, 0=Sunday, 1=Monday, etc
                if ((int)dt1_dow > (int)dt2_dow)
                {
                    hours = hours - 24;
                   
                }

                if (hours >= 0)
                {
                    txtElapse.Text = hours.ToString("0");
                    var totals = hours * 2;

                    txtFine.Text = totals.ToString("0");
                }
                else
                {
                    txtFine.Text = "0";
                    txtElapse.Text = "0";
                }

            }
            catch (Exception)
            { }
            conn.Close();

            if (lblIssuedNo.Text == "")
            {
                clearfield();
            }
          
        }
        private void dgvIssuedBooks_KeyUp(object sender, KeyEventArgs e)
        {
            lblIssuedNo.Text = dgvIssuedBooks.Rows[dgvIssuedBooks.CurrentCell.RowIndex].Cells[0].Value.ToString();
        }

        private void dgvIssuedBooks_KeyDown(object sender, KeyEventArgs e)
        {
            lblIssuedNo.Text = dgvIssuedBooks.Rows[dgvIssuedBooks.CurrentCell.RowIndex].Cells[0].Value.ToString();
        }
        private void txtSnumber_TextChanged(object sender, EventArgs e)
        {
          if (txtSnumber.Text != "")
          {
             txtFnumber.Enabled = false;
          }
          else
          {
             txtFnumber.Enabled = true;
             clearfield();
          }
        }

        private void txtFnumber_TextChanged(object sender, EventArgs e)
        {
            if (txtFnumber.Text != "")
            {
                txtSnumber.Enabled = false;
            }
            else
            {
                txtSnumber.Enabled = true;
                clearfield();
            }
        }
    }
}
