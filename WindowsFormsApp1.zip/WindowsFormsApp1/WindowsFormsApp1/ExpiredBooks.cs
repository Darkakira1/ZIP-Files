﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;
using System.Globalization;

namespace WindowsFormsApp1
{
    public partial class ExpiredBooks : Form
    {

        MySqlConnection conn = new MySqlConnection("server=127.0.0.1;port=3306;username=root;password=root123;database=librarydb");

        DateTime mydt;
        public ExpiredBooks()
        {
            InitializeComponent();
        }
        private void PopulateTable()
        {
            try
            {

                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT IDissued as 'ID No', Student_name as 'Person Name', Book_Tittle as 'Book Tittle', Book_Issued as 'Book Issued', Book_Return as 'Book Return',Book_Status as 'Book Status' , Fine FROM bookissued", conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dgvIssuedBooks.DataSource = dt;



            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
            conn.Close();
        }
        private void ExpiredBooks_Load(object sender, EventArgs e)
        {
            PopulateTable();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {


            //DateTime dtstatus = DateTime.Now;
            //dtstatus.ToString("dd-MM-yyyy hh:mm tt", CultureInfo.InvariantCulture);

            //label1.Text = DateTime.Now.ToString();
            try
            {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand("Update bookissued SET Book_Status = @statuse WHERE Book_Return <= '" + DateTime.Now.ToString("dd-MM-yyyy hh:mm tt") + "'", conn) ;
                cmd.Parameters.AddWithValue("@statuse", "OverDue");
                cmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                MessageBox.Show("" + ex);
            }
            conn.Close();
            PopulateTable();


            String CurrentBID = dgvIssuedBooks.Rows[dgvIssuedBooks.CurrentCell.RowIndex].Cells[0].Value.ToString();

            DataGridViewCellStyle style = new DataGridViewCellStyle();
            style.ForeColor = Color.Red;

            dgvIssuedBooks.Rows[0].Cells[4].Style = style;


            //string text = DateTime.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture);


           


            
            //label1.Text = hours.ToString("0");
           
                try
                {
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand("Update bookissued SET Fine = @fine WHERE Book_Status = 'OverDue'", conn);
              
                
                DateTime dt2 = DateTime.Now;
                dt2.ToString("dd-MM-yyyy hh:mm tt", CultureInfo.InvariantCulture);
                var hours = (dt2 - mydt).TotalHours;
                var days = (dt2 - mydt).TotalDays;



                

                cmd.Parameters.AddWithValue("@fine", hours);
                    cmd.ExecuteNonQuery();

                }
                catch (Exception ex)
                {
                    MessageBox.Show("" + ex);
                }
                conn.Close();
                PopulateTable();
        

        }

        private void dgvIssuedBooks_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                mydt = Convert.ToDateTime(dgvIssuedBooks.Rows[e.RowIndex].Cells[4].Value.ToString());
            }
            catch (Exception ex)
            { }
        }
    }
}
