﻿
namespace WindowsFormsApp1
{
    partial class DashBoard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DashBoard));
            this.btnBooks = new System.Windows.Forms.Button();
            this.btnLostBook = new System.Windows.Forms.Button();
            this.btnLostBooks = new System.Windows.Forms.Button();
            this.btnStudentsInfo = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.studentInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentInformationToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.facultyInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pnlDisplay = new System.Windows.Forms.Panel();
            this.btnIssuedBooks = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnBooks
            // 
            this.btnBooks.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnBooks.FlatAppearance.BorderSize = 0;
            this.btnBooks.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBooks.Location = new System.Drawing.Point(3, 75);
            this.btnBooks.Name = "btnBooks";
            this.btnBooks.Size = new System.Drawing.Size(128, 35);
            this.btnBooks.TabIndex = 0;
            this.btnBooks.Text = "Add/Edit Books";
            this.btnBooks.UseVisualStyleBackColor = false;
            this.btnBooks.Click += new System.EventHandler(this.btnBooks_Click);
            // 
            // btnLostBook
            // 
            this.btnLostBook.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnLostBook.FlatAppearance.BorderSize = 0;
            this.btnLostBook.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLostBook.Location = new System.Drawing.Point(3, 157);
            this.btnLostBook.Name = "btnLostBook";
            this.btnLostBook.Size = new System.Drawing.Size(128, 35);
            this.btnLostBook.TabIndex = 1;
            this.btnLostBook.Text = "Books Information";
            this.btnLostBook.UseVisualStyleBackColor = false;
            this.btnLostBook.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnLostBooks
            // 
            this.btnLostBooks.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnLostBooks.FlatAppearance.BorderSize = 0;
            this.btnLostBooks.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLostBooks.Location = new System.Drawing.Point(3, 116);
            this.btnLostBooks.Name = "btnLostBooks";
            this.btnLostBooks.Size = new System.Drawing.Size(128, 35);
            this.btnLostBooks.TabIndex = 2;
            this.btnLostBooks.Text = "Lost Book";
            this.btnLostBooks.UseVisualStyleBackColor = false;
            this.btnLostBooks.Click += new System.EventHandler(this.btnLostBooks_Click);
            // 
            // btnStudentsInfo
            // 
            this.btnStudentsInfo.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnStudentsInfo.FlatAppearance.BorderSize = 0;
            this.btnStudentsInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStudentsInfo.Location = new System.Drawing.Point(3, 198);
            this.btnStudentsInfo.Name = "btnStudentsInfo";
            this.btnStudentsInfo.Size = new System.Drawing.Size(128, 35);
            this.btnStudentsInfo.TabIndex = 3;
            this.btnStudentsInfo.Text = "Add Students";
            this.btnStudentsInfo.UseVisualStyleBackColor = false;
            this.btnStudentsInfo.Click += new System.EventHandler(this.btnStudentsInfo_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.studentInformationToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1034, 24);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // studentInformationToolStripMenuItem
            // 
            this.studentInformationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.studentInformationToolStripMenuItem1,
            this.facultyInformationToolStripMenuItem});
            this.studentInformationToolStripMenuItem.Name = "studentInformationToolStripMenuItem";
            this.studentInformationToolStripMenuItem.Size = new System.Drawing.Size(137, 20);
            this.studentInformationToolStripMenuItem.Text = "Golden Gate members";
            // 
            // studentInformationToolStripMenuItem1
            // 
            this.studentInformationToolStripMenuItem1.Name = "studentInformationToolStripMenuItem1";
            this.studentInformationToolStripMenuItem1.Size = new System.Drawing.Size(181, 22);
            this.studentInformationToolStripMenuItem1.Text = "Student Information";
            this.studentInformationToolStripMenuItem1.Click += new System.EventHandler(this.studentInformationToolStripMenuItem1_Click);
            // 
            // facultyInformationToolStripMenuItem
            // 
            this.facultyInformationToolStripMenuItem.Name = "facultyInformationToolStripMenuItem";
            this.facultyInformationToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.facultyInformationToolStripMenuItem.Text = "Faculty Information";
            this.facultyInformationToolStripMenuItem.Click += new System.EventHandler(this.facultyInformationToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel1.Controls.Add(this.btnIssuedBooks);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.btnBooks);
            this.panel1.Controls.Add(this.btnStudentsInfo);
            this.panel1.Controls.Add(this.btnLostBooks);
            this.panel1.Controls.Add(this.btnLostBook);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 24);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(133, 598);
            this.panel1.TabIndex = 5;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(26, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(72, 66);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // pnlDisplay
            // 
            this.pnlDisplay.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlDisplay.Location = new System.Drawing.Point(133, 24);
            this.pnlDisplay.Name = "pnlDisplay";
            this.pnlDisplay.Size = new System.Drawing.Size(901, 598);
            this.pnlDisplay.TabIndex = 6;
            // 
            // btnIssuedBooks
            // 
            this.btnIssuedBooks.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnIssuedBooks.FlatAppearance.BorderSize = 0;
            this.btnIssuedBooks.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnIssuedBooks.Location = new System.Drawing.Point(2, 239);
            this.btnIssuedBooks.Name = "btnIssuedBooks";
            this.btnIssuedBooks.Size = new System.Drawing.Size(128, 35);
            this.btnIssuedBooks.TabIndex = 5;
            this.btnIssuedBooks.Text = "Issued Books";
            this.btnIssuedBooks.UseVisualStyleBackColor = false;
            this.btnIssuedBooks.Click += new System.EventHandler(this.btnIssuedBooks_Click);
            // 
            // DashBoard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1034, 622);
            this.Controls.Add(this.pnlDisplay);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "DashBoard";
            this.Text = "DashBoard";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBooks;
        private System.Windows.Forms.Button btnLostBook;
        private System.Windows.Forms.Button btnLostBooks;
        private System.Windows.Forms.Button btnStudentsInfo;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem studentInformationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentInformationToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem facultyInformationToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel pnlDisplay;
        private System.Windows.Forms.Button btnIssuedBooks;
    }
}