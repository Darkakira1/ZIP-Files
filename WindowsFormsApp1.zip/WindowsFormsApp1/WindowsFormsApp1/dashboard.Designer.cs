﻿
namespace WindowsFormsApp1
{
    partial class DashBoard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DashBoard));
            this.btnBooks = new System.Windows.Forms.Button();
            this.btnBookInfo = new System.Windows.Forms.Button();
            this.btnStudentsInfo = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.studentInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentInformationToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.facultyInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.returnHistoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lostBooksToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnReturn = new System.Windows.Forms.Button();
            this.btnDashBoard = new System.Windows.Forms.Button();
            this.btnIssuedBooks = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pnlDisplay = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.changePasswordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnBooks
            // 
            this.btnBooks.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(160)))), ((int)(((byte)(160)))));
            this.btnBooks.FlatAppearance.BorderSize = 0;
            this.btnBooks.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBooks.ForeColor = System.Drawing.Color.Black;
            this.btnBooks.Location = new System.Drawing.Point(2, 179);
            this.btnBooks.Name = "btnBooks";
            this.btnBooks.Size = new System.Drawing.Size(128, 35);
            this.btnBooks.TabIndex = 0;
            this.btnBooks.Text = "Add/Edit Books";
            this.btnBooks.UseVisualStyleBackColor = false;
            this.btnBooks.Click += new System.EventHandler(this.btnBooks_Click);
            // 
            // btnBookInfo
            // 
            this.btnBookInfo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(160)))), ((int)(((byte)(160)))));
            this.btnBookInfo.FlatAppearance.BorderSize = 0;
            this.btnBookInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBookInfo.ForeColor = System.Drawing.Color.Black;
            this.btnBookInfo.Location = new System.Drawing.Point(3, 220);
            this.btnBookInfo.Name = "btnBookInfo";
            this.btnBookInfo.Size = new System.Drawing.Size(128, 35);
            this.btnBookInfo.TabIndex = 1;
            this.btnBookInfo.Text = "Books Information";
            this.btnBookInfo.UseVisualStyleBackColor = false;
            this.btnBookInfo.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnStudentsInfo
            // 
            this.btnStudentsInfo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(160)))), ((int)(((byte)(160)))));
            this.btnStudentsInfo.FlatAppearance.BorderSize = 0;
            this.btnStudentsInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStudentsInfo.ForeColor = System.Drawing.Color.Black;
            this.btnStudentsInfo.Location = new System.Drawing.Point(2, 261);
            this.btnStudentsInfo.Name = "btnStudentsInfo";
            this.btnStudentsInfo.Size = new System.Drawing.Size(128, 35);
            this.btnStudentsInfo.TabIndex = 3;
            this.btnStudentsInfo.Text = "Add Members";
            this.btnStudentsInfo.UseVisualStyleBackColor = false;
            this.btnStudentsInfo.Click += new System.EventHandler(this.btnStudentsInfo_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.SlateGray;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.studentInformationToolStripMenuItem,
            this.viewToolStripMenuItem,
            this.changePasswordToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1100, 24);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // studentInformationToolStripMenuItem
            // 
            this.studentInformationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.studentInformationToolStripMenuItem1,
            this.facultyInformationToolStripMenuItem});
            this.studentInformationToolStripMenuItem.Name = "studentInformationToolStripMenuItem";
            this.studentInformationToolStripMenuItem.Size = new System.Drawing.Size(137, 20);
            this.studentInformationToolStripMenuItem.Text = "Golden Gate members";
            // 
            // studentInformationToolStripMenuItem1
            // 
            this.studentInformationToolStripMenuItem1.Name = "studentInformationToolStripMenuItem1";
            this.studentInformationToolStripMenuItem1.Size = new System.Drawing.Size(181, 22);
            this.studentInformationToolStripMenuItem1.Text = "Student Information";
            this.studentInformationToolStripMenuItem1.Click += new System.EventHandler(this.studentInformationToolStripMenuItem1_Click);
            // 
            // facultyInformationToolStripMenuItem
            // 
            this.facultyInformationToolStripMenuItem.Name = "facultyInformationToolStripMenuItem";
            this.facultyInformationToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.facultyInformationToolStripMenuItem.Text = "Faculty Information";
            this.facultyInformationToolStripMenuItem.Click += new System.EventHandler(this.facultyInformationToolStripMenuItem_Click);
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.returnHistoryToolStripMenuItem,
            this.lostBooksToolStripMenuItem});
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.viewToolStripMenuItem.Text = "View";
            // 
            // returnHistoryToolStripMenuItem
            // 
            this.returnHistoryToolStripMenuItem.Name = "returnHistoryToolStripMenuItem";
            this.returnHistoryToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.returnHistoryToolStripMenuItem.Text = "Return History";
            this.returnHistoryToolStripMenuItem.Click += new System.EventHandler(this.returnBooksToolStripMenuItem_Click);
            // 
            // lostBooksToolStripMenuItem
            // 
            this.lostBooksToolStripMenuItem.Name = "lostBooksToolStripMenuItem";
            this.lostBooksToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.lostBooksToolStripMenuItem.Text = "Lost Books";
            this.lostBooksToolStripMenuItem.Click += new System.EventHandler(this.lostBooksToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel1.Controls.Add(this.btnReturn);
            this.panel1.Controls.Add(this.btnDashBoard);
            this.panel1.Controls.Add(this.btnIssuedBooks);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.btnBooks);
            this.panel1.Controls.Add(this.btnStudentsInfo);
            this.panel1.Controls.Add(this.btnBookInfo);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 24);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(133, 626);
            this.panel1.TabIndex = 5;
            // 
            // btnReturn
            // 
            this.btnReturn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(160)))), ((int)(((byte)(160)))));
            this.btnReturn.FlatAppearance.BorderSize = 0;
            this.btnReturn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReturn.ForeColor = System.Drawing.Color.Black;
            this.btnReturn.Location = new System.Drawing.Point(3, 343);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.Size = new System.Drawing.Size(128, 35);
            this.btnReturn.TabIndex = 7;
            this.btnReturn.Text = "Return Books";
            this.btnReturn.UseVisualStyleBackColor = false;
            this.btnReturn.Click += new System.EventHandler(this.btnReturn_Click);
            // 
            // btnDashBoard
            // 
            this.btnDashBoard.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(160)))), ((int)(((byte)(160)))));
            this.btnDashBoard.FlatAppearance.BorderSize = 0;
            this.btnDashBoard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDashBoard.ForeColor = System.Drawing.Color.Black;
            this.btnDashBoard.Location = new System.Drawing.Point(3, 138);
            this.btnDashBoard.Name = "btnDashBoard";
            this.btnDashBoard.Size = new System.Drawing.Size(128, 35);
            this.btnDashBoard.TabIndex = 6;
            this.btnDashBoard.Text = "DashBoard";
            this.btnDashBoard.UseVisualStyleBackColor = false;
            this.btnDashBoard.Click += new System.EventHandler(this.btnDashBoard_Click);
            // 
            // btnIssuedBooks
            // 
            this.btnIssuedBooks.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(160)))), ((int)(((byte)(160)))));
            this.btnIssuedBooks.FlatAppearance.BorderSize = 0;
            this.btnIssuedBooks.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnIssuedBooks.ForeColor = System.Drawing.Color.Black;
            this.btnIssuedBooks.Location = new System.Drawing.Point(3, 302);
            this.btnIssuedBooks.Name = "btnIssuedBooks";
            this.btnIssuedBooks.Size = new System.Drawing.Size(128, 35);
            this.btnIssuedBooks.TabIndex = 5;
            this.btnIssuedBooks.Text = "Issued Books";
            this.btnIssuedBooks.UseVisualStyleBackColor = false;
            this.btnIssuedBooks.Click += new System.EventHandler(this.btnIssuedBooks_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(30, 9);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(72, 66);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // pnlDisplay
            // 
            this.pnlDisplay.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.pnlDisplay.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlDisplay.Location = new System.Drawing.Point(133, 24);
            this.pnlDisplay.Name = "pnlDisplay";
            this.pnlDisplay.Size = new System.Drawing.Size(967, 626);
            this.pnlDisplay.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.SlateGray;
            this.label1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label1.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(1075, 1);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(23, 22);
            this.label1.TabIndex = 14;
            this.label1.Text = "X";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // changePasswordToolStripMenuItem
            // 
            this.changePasswordToolStripMenuItem.Name = "changePasswordToolStripMenuItem";
            this.changePasswordToolStripMenuItem.Size = new System.Drawing.Size(113, 20);
            this.changePasswordToolStripMenuItem.Text = "Change Password";
            this.changePasswordToolStripMenuItem.Click += new System.EventHandler(this.changePasswordToolStripMenuItem_Click);
            // 
            // DashBoard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(36)))), ((int)(((byte)(49)))));
            this.ClientSize = new System.Drawing.Size(1100, 650);
            this.Controls.Add(this.pnlDisplay);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "DashBoard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DashBoard";
            this.Load += new System.EventHandler(this.DashBoard_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBooks;
        private System.Windows.Forms.Button btnBookInfo;
        private System.Windows.Forms.Button btnStudentsInfo;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem studentInformationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentInformationToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem facultyInformationToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel pnlDisplay;
        private System.Windows.Forms.Button btnIssuedBooks;
        private System.Windows.Forms.Button btnDashBoard;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem returnHistoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lostBooksToolStripMenuItem;
        private System.Windows.Forms.Button btnReturn;
        private System.Windows.Forms.ToolStripMenuItem changePasswordToolStripMenuItem;
    }
}