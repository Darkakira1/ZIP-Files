﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;

namespace WindowsFormsApp1
{
    public partial class AddEditBooks : Form
    {


        public static AddEditBooks instance;
        public DataGridView advg;
        public Label Alabel;

        MySqlConnection conn = new MySqlConnection("server=127.0.0.1;port=3306;username=root;password=root123;database=librarydb");

        string imgLocation = "";
        string imgLocation_edit = "";

        private void clearfield()
        {
            txtISBN_add.Clear();
            txtNameBook_Add.Clear();
            txtAuthor_Add.Clear();
            cbBookCategories_add.Clear();
            rtbDescription.Clear();
            txtPublish.Clear();
            nudQuantity.Value = 0;
        }

        private void PopulateTable()
        {
            try
            {

                DataGridViewCellStyle style = new DataGridViewCellStyle();
                style.ForeColor = Color.Red;
                
                //dataGridView1.Rows[0].Cells[4].Style = style;

                conn.Open();
                MySqlDataAdapter adapter = new MySqlDataAdapter("Select ISBN_no as 'ISBN',Name_of_Book as 'Book Tittle',Book_Author as 'Author',Book_Categories as 'Categories',Book_Status as 'Status' ,Book_quantity as 'Quantity' From table_inventorybooks Where NOT Book_Status = 'Lost'", conn);
                
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dgvAdd_edit.DataSource = dt;
               
                lblTotal.Text = $"Total Records: {dgvAdd_edit.RowCount}";
                conn.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
        }
        public AddEditBooks()
        {
            InitializeComponent();
            instance = this;
            
            advg = dgvAdd_edit;
            Alabel = lblTotal;
        }


        private void AddEditBooks_Load(object sender, EventArgs e)
        {
            PopulateTable();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {

            
            int ISBN;
            string tittle = txtNameBook_Add.Text;
            string Author = txtAuthor_Add.Text;
            string categories = cbBookCategories_add.Text;
            string publish = txtPublish.Text;
            int quantity = Convert.ToInt32(nudQuantity.Value);
            string descrip = rtbDescription.Text;
            byte[] image= null;

            try
            {


                FileStream stream = new FileStream(imgLocation, FileMode.Open, FileAccess.Read);
                BinaryReader brs = new BinaryReader(stream);

                image = brs.ReadBytes((int)stream.Length);
            }
            catch (Exception)
            { }


            bool isvalid = true;

            if (tittle.Trim().Length <=2 || !int.TryParse(txtISBN_add.Text, out ISBN))
            {
                MessageBox.Show("Pleasse Enter Proper Tittle or a Valid ISBN no.");
                isvalid = false;
            }
            if (isvalid)
            {
                conn.Open();
                string cmdstring = "Insert Into table_inventorybooks(ISBN_no,Name_of_Book,Book_Author,Book_Categories,Book_Status,Book_Publish, Book_quantity,Book_Description, Book_Image ) Values ('" + txtISBN_add.Text+ "', @name_of_book, @book_author, @book_categories, @book_status ,@dPublish, @bQuantity, @bDescription, @bimage)";
                MySqlCommand cmd = new MySqlCommand(cmdstring, conn);
                cmd.Parameters.AddWithValue("@name_of_book", tittle);
                cmd.Parameters.AddWithValue("@book_author", Author);
                cmd.Parameters.AddWithValue("@book_categories", categories);
                cmd.Parameters.AddWithValue("@dPublish", publish);
                cmd.Parameters.AddWithValue("@bQuantity", quantity);
                cmd.Parameters.AddWithValue("@bDescription", descrip);
                cmd.Parameters.AddWithValue("@book_status", "Active");

                cmd.Parameters.AddWithValue("@bimage", image);

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show(tittle+ " Inserted succesfully");
                    
                    clearfield();
                }
                catch (Exception)
                {
                    MessageBox.Show("Same ISBN");

                }
                conn.Close();
            }
            PopulateTable();
            
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
           
            String  CurrentBID = dgvAdd_edit.Rows[dgvAdd_edit.CurrentCell.RowIndex].Cells[0].Value.ToString();
            
            int ISBN_edit;
            string btittle_edit = txtBookTittle_edit.Text;
            string Author_edit = txtAuthor_Edit.Text;
            string categories_edit = txtcategories_Edit.Text;
            string statusradio_edit = "";
            string publish_edit = txtPublish_Edit.Text;
            int quantity_edit = Convert.ToInt32(nudQuantity_Edit.Value);
            string descrip_edit = rtbDescription_edit.Text;
            byte[] image_edit = null;


            try
            {
                FileStream stream = new FileStream(imgLocation_edit, FileMode.Open, FileAccess.Read);
                BinaryReader brs = new BinaryReader(stream);

                image_edit = brs.ReadBytes((int)stream.Length);
            }
            catch (Exception)
            { }



            if (rbActive_edit.Checked)
            {
                statusradio_edit += "Active";
            }
            if (rbLost_Edit.Checked)
            {
                statusradio_edit += "Lost";
                MessageBox.Show("Are You Sure The Book Is lost? ", "Warning" , MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            }

            bool IsValid = true;

            if (btittle_edit.Trim().Length <= 2 || !int.TryParse(txtISBN_edit.Text, out ISBN_edit))
            {
                MessageBox.Show("Pleasse Enter Proper Tittle or a Valid ISBN no.");
                IsValid = false;
            }

            if (IsValid)
            {

                try
                {
                    conn.Open();

                    MySqlCommand cmd = new MySqlCommand("Update table_inventorybooks SET ISBN_no= '" + txtISBN_edit.Text+ "', Name_of_Book=@name_of_book, Book_Author=@bookauthor, Book_Categories=@book_categories, Book_Status=@book_status, Book_Publish = @publish_edit, Book_quantity = @bQuantity_edit, Book_Description = @bDescription_edit, Book_Image = @image_edit WHERE ISBN_no = " + CurrentBID, conn);
                    
                    //cmd.Parameters.AddWithValue("@isbn_edit", ISBN_edit);
                    cmd.Parameters.AddWithValue("@name_of_book", btittle_edit);
                    cmd.Parameters.AddWithValue("@bookauthor", Author_edit);
                    cmd.Parameters.AddWithValue("@book_categories", categories_edit);
                    cmd.Parameters.AddWithValue("@book_status", statusradio_edit);
                    cmd.Parameters.AddWithValue("@publish_edit", publish_edit);
                    cmd.Parameters.AddWithValue("@bQuantity_edit", quantity_edit);
                    cmd.Parameters.AddWithValue("@bDescription_edit", descrip_edit);

                    cmd.Parameters.AddWithValue("@image_edit", image_edit);
                  


                    cmd.ExecuteNonQuery();
                    if (statusradio_edit == "Active") {
                        MessageBox.Show(btittle_edit + " Update Success");
                          }

                    //BooksInformation.instance.dgv.;

                    
                    PopulateTable();
                    clearfield();

                }
                catch (Exception ex) {
                    MessageBox.Show("Error" + ex);
                }
                conn.Close();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

           
            String CurrentBID = dgvAdd_edit.Rows[dgvAdd_edit.CurrentCell.RowIndex].Cells[0].Value.ToString();
            try
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand("DELETE FROM table_inventorybooks WHERE ISBN_no =" + CurrentBID, conn);
                cmd.ExecuteNonQuery();
               
                MessageBox.Show("Succesfully Deleted");
                PopulateTable();
            }
            catch (Exception ex) 
            {
                MessageBox.Show("Error " + ex);
            }
                conn.Close();
        }


        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                string sqlquery = "Select ISBN_no as 'ISBN no',Name_of_Book as 'Book Tittle', Book_Author as 'Author',Book_Categories as 'Categories', Book_Status as 'Status', Book_quantity as 'Quantity' From table_inventorybooks where ISBN_no like '" + txtSearch.Text + "%' AND NOT Book_Status = 'Lost' or Name_of_Book like '" + txtSearch.Text + "%' AND NOT Book_Status = 'Lost'  ";
                conn.Open();

                MySqlCommand sqlCommand = new MySqlCommand(sqlquery, conn);
                MySqlDataAdapter sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                DataTable dt = new DataTable();
                sqlDataAdapter.Fill(dt);
                dgvAdd_edit.DataSource = dt;

                lblTotal.Text = $"Total Records: {dgvAdd_edit.RowCount}";
               
            }
            catch (Exception)
            { }
            conn.Close();


            if (dgvAdd_edit.SelectedRows.Count > 0)
            {
                
                string CurrentBID = dgvAdd_edit.Rows[dgvAdd_edit.CurrentCell.RowIndex].Cells[0].Value.ToString();
                if (CurrentBID != null)
                {
                    pbImage_edit.Image = null;
                    rtbDescription_edit.Text = "";
                    txtPublish_Edit.Text = "";
                    nudQuantity_Edit.Value = 0;

                    try
                    {
                        conn.Open();
                        MySqlDataAdapter query = new MySqlDataAdapter("Select Book_Publish, Book_quantity, Book_Description , Book_Image   From table_inventorybooks Where ISBN_no = " + CurrentBID, conn);
                        DataTable dt = new DataTable();
                        query.Fill(dt);


                        string dpublish = dt.Rows[0].ItemArray[0].ToString();
                        string description = dt.Rows[0].ItemArray[2].ToString();
                        int quantity = Convert.ToInt32(dt.Rows[0].ItemArray[1].ToString());


                        txtPublish_Edit.Text = dpublish;
                        rtbDescription_edit.Text = description;
                        nudQuantity_Edit.Value = quantity;

                        byte[] image = (byte[])dt.Rows[0].ItemArray[3];
                        MemoryStream ms = new MemoryStream(image);
                        pbImage_edit.Image = Image.FromStream(ms);

                    }
                    catch (Exception ex)
                    { MessageBox.Show("" + ex); }
                    conn.Close();
                }
            }

            if (txtSearch.Text == "")
            {
                PopulateTable();

                try
                {
                    conn.Open();
                    string CurrentBID = dgvAdd_edit.Rows[dgvAdd_edit.CurrentCell.RowIndex].Cells[0].Value.ToString();
                    MySqlDataAdapter query = new MySqlDataAdapter("Select Book_Publish, Book_quantity, Book_Description , Book_Image   From table_inventorybooks Where ISBN_no = " + CurrentBID, conn);
                    DataTable dt = new DataTable();
                    query.Fill(dt);


                    string dpublish = dt.Rows[0].ItemArray[0].ToString();
                    string description = dt.Rows[0].ItemArray[2].ToString();
                    int quantity = Convert.ToInt32(dt.Rows[0].ItemArray[1].ToString());


                    txtPublish_Edit.Text = dpublish;
                    rtbDescription_edit.Text = description;
                    nudQuantity_Edit.Value = quantity;

                    byte[] image = (byte[])dt.Rows[0].ItemArray[3];
                    MemoryStream ms = new MemoryStream(image);
                    pbImage_edit.Image = Image.FromStream(ms);

                }
                catch (Exception ex)
                { MessageBox.Show("" + ex); }
                conn.Close();
            } 
        }



        private void btnchImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Choose Image(*.jpg; *.png; *.gif)|*.jpg; *.png; *.gif| All Files *.*|*.*";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                imgLocation = ofd.FileName.ToString();
                pbbookimage.ImageLocation = imgLocation;
            }
        }


        #region Label And panel Change Color
        private void txtISBN_add_Enter(object sender, EventArgs e)
        {
            pn1.BackColor = Color.FromArgb(78, 184, 206);
            lbl1.ForeColor = Color.FromArgb(78, 184, 206);

            pn2.BackColor = Color.WhiteSmoke;
            pn3.BackColor = Color.WhiteSmoke;
            pn4.BackColor = Color.WhiteSmoke;
            pn5.BackColor = Color.WhiteSmoke;
            pn6.BackColor = Color.WhiteSmoke;
            pn7.BackColor = Color.WhiteSmoke;
            pn8.BackColor = Color.WhiteSmoke;
            pn9.BackColor = Color.WhiteSmoke;
            pn10.BackColor = Color.WhiteSmoke;

            lbl2.ForeColor = Color.WhiteSmoke;
            lbl3.ForeColor = Color.WhiteSmoke;
            lbl4.ForeColor = Color.WhiteSmoke;
            lbl5.ForeColor = Color.WhiteSmoke;
            lbl6.ForeColor = Color.WhiteSmoke;
            lbl7.ForeColor = Color.WhiteSmoke;
            lbl8.ForeColor = Color.WhiteSmoke;
            lbl9.ForeColor = Color.WhiteSmoke;
            lbl10.ForeColor = Color.WhiteSmoke;
        }

        private void txtNameBook_Add_Enter(object sender, EventArgs e)
        {
            pn2.BackColor = Color.FromArgb(78, 184, 206);
            lbl2.ForeColor = Color.FromArgb(78, 184, 206);

            pn1.BackColor = Color.WhiteSmoke;
            pn3.BackColor = Color.WhiteSmoke;
            pn4.BackColor = Color.WhiteSmoke;
            pn5.BackColor = Color.WhiteSmoke;
            pn6.BackColor = Color.WhiteSmoke;
            pn7.BackColor = Color.WhiteSmoke;
            pn8.BackColor = Color.WhiteSmoke;
            pn9.BackColor = Color.WhiteSmoke;
            pn10.BackColor = Color.WhiteSmoke;

            lbl1.ForeColor = Color.WhiteSmoke;
            lbl3.ForeColor = Color.WhiteSmoke;
            lbl4.ForeColor = Color.WhiteSmoke;
            lbl5.ForeColor = Color.WhiteSmoke;
            lbl6.ForeColor = Color.WhiteSmoke;
            lbl7.ForeColor = Color.WhiteSmoke;
            lbl8.ForeColor = Color.WhiteSmoke;
            lbl9.ForeColor = Color.WhiteSmoke;
            lbl10.ForeColor = Color.WhiteSmoke;
        }

        private void txtAuthor_Add_Enter(object sender, EventArgs e)
        {
            pn3.BackColor = Color.FromArgb(78, 184, 206);
            lbl3.ForeColor = Color.FromArgb(78, 184, 206);

            pn2.BackColor = Color.WhiteSmoke;
            pn1.BackColor = Color.WhiteSmoke;
            pn4.BackColor = Color.WhiteSmoke;
            pn5.BackColor = Color.WhiteSmoke;
            pn6.BackColor = Color.WhiteSmoke;
            pn7.BackColor = Color.WhiteSmoke;
            pn8.BackColor = Color.WhiteSmoke;
            pn9.BackColor = Color.WhiteSmoke;
            pn10.BackColor = Color.WhiteSmoke;

            lbl2.ForeColor = Color.WhiteSmoke;
            lbl1.ForeColor = Color.WhiteSmoke;
            lbl4.ForeColor = Color.WhiteSmoke;
            lbl5.ForeColor = Color.WhiteSmoke;
            lbl6.ForeColor = Color.WhiteSmoke;
            lbl7.ForeColor = Color.WhiteSmoke;
            lbl8.ForeColor = Color.WhiteSmoke;
            lbl9.ForeColor = Color.WhiteSmoke;
            lbl10.ForeColor = Color.WhiteSmoke;
        }

        private void cbBookCategories_add_Enter(object sender, EventArgs e)
        {
            pn4.BackColor = Color.FromArgb(78, 184, 206);
            lbl4.ForeColor = Color.FromArgb(78, 184, 206);

            pn2.BackColor = Color.WhiteSmoke;
            pn3.BackColor = Color.WhiteSmoke;
            pn1.BackColor = Color.WhiteSmoke;
            pn5.BackColor = Color.WhiteSmoke;
            pn6.BackColor = Color.WhiteSmoke;
            pn7.BackColor = Color.WhiteSmoke;
            pn8.BackColor = Color.WhiteSmoke;
            pn9.BackColor = Color.WhiteSmoke;
            pn10.BackColor = Color.WhiteSmoke;

            lbl2.ForeColor = Color.WhiteSmoke;
            lbl3.ForeColor = Color.WhiteSmoke;
            lbl1.ForeColor = Color.WhiteSmoke;
            lbl5.ForeColor = Color.WhiteSmoke;
            lbl6.ForeColor = Color.WhiteSmoke;
            lbl7.ForeColor = Color.WhiteSmoke;
            lbl8.ForeColor = Color.WhiteSmoke;
            lbl9.ForeColor = Color.WhiteSmoke;
            lbl10.ForeColor = Color.WhiteSmoke;
        }

        private void txtPublish_Enter(object sender, EventArgs e)
        {
            pn5.BackColor = Color.FromArgb(78, 184, 206);
            lbl5.ForeColor = Color.FromArgb(78, 184, 206);

            pn2.BackColor = Color.WhiteSmoke;
            pn3.BackColor = Color.WhiteSmoke;
            pn4.BackColor = Color.WhiteSmoke;
            pn1.BackColor = Color.WhiteSmoke;
            pn6.BackColor = Color.WhiteSmoke;
            pn7.BackColor = Color.WhiteSmoke;
            pn8.BackColor = Color.WhiteSmoke;
            pn9.BackColor = Color.WhiteSmoke;
            pn10.BackColor = Color.WhiteSmoke;

            lbl2.ForeColor = Color.WhiteSmoke;
            lbl3.ForeColor = Color.WhiteSmoke;
            lbl4.ForeColor = Color.WhiteSmoke;
            lbl1.ForeColor = Color.WhiteSmoke;
            lbl6.ForeColor = Color.WhiteSmoke;
            lbl7.ForeColor = Color.WhiteSmoke;
            lbl8.ForeColor = Color.WhiteSmoke;
            lbl9.ForeColor = Color.WhiteSmoke;
            lbl10.ForeColor = Color.WhiteSmoke;
        }

        private void txtISBN_edit_Enter(object sender, EventArgs e)
        {
            pn6.BackColor = Color.FromArgb(78, 184, 206);
            lbl6.ForeColor = Color.FromArgb(78, 184, 206);

            pn2.BackColor = Color.WhiteSmoke;
            pn3.BackColor = Color.WhiteSmoke;
            pn4.BackColor = Color.WhiteSmoke;
            pn5.BackColor = Color.WhiteSmoke;
            pn1.BackColor = Color.WhiteSmoke;
            pn7.BackColor = Color.WhiteSmoke;
            pn8.BackColor = Color.WhiteSmoke;
            pn9.BackColor = Color.WhiteSmoke;
            pn10.BackColor = Color.WhiteSmoke;

            lbl2.ForeColor = Color.WhiteSmoke;
            lbl3.ForeColor = Color.WhiteSmoke;
            lbl4.ForeColor = Color.WhiteSmoke;
            lbl5.ForeColor = Color.WhiteSmoke;
            lbl1.ForeColor = Color.WhiteSmoke;
            lbl7.ForeColor = Color.WhiteSmoke;
            lbl8.ForeColor = Color.WhiteSmoke;
            lbl9.ForeColor = Color.WhiteSmoke;
            lbl10.ForeColor = Color.WhiteSmoke;
        }

        private void txtBookTittle_edit_Enter(object sender, EventArgs e)
        {
            pn7.BackColor = Color.FromArgb(78, 184, 206);
            lbl7.ForeColor = Color.FromArgb(78, 184, 206);

            pn2.BackColor = Color.WhiteSmoke;
            pn3.BackColor = Color.WhiteSmoke;
            pn4.BackColor = Color.WhiteSmoke;
            pn5.BackColor = Color.WhiteSmoke;
            pn6.BackColor = Color.WhiteSmoke;
            pn1.BackColor = Color.WhiteSmoke;
            pn8.BackColor = Color.WhiteSmoke;
            pn9.BackColor = Color.WhiteSmoke;
            pn10.BackColor = Color.WhiteSmoke;

            lbl2.ForeColor = Color.WhiteSmoke;
            lbl3.ForeColor = Color.WhiteSmoke;
            lbl4.ForeColor = Color.WhiteSmoke;
            lbl5.ForeColor = Color.WhiteSmoke;
            lbl6.ForeColor = Color.WhiteSmoke;
            lbl1.ForeColor = Color.WhiteSmoke;
            lbl8.ForeColor = Color.WhiteSmoke;
            lbl9.ForeColor = Color.WhiteSmoke;
            lbl10.ForeColor = Color.WhiteSmoke;
        }

        private void txtAuthor_Edit_Enter(object sender, EventArgs e)
        {
            pn8.BackColor = Color.FromArgb(78, 184, 206);
            lbl8.ForeColor = Color.FromArgb(78, 184, 206);

            pn2.BackColor = Color.WhiteSmoke;
            pn3.BackColor = Color.WhiteSmoke;
            pn4.BackColor = Color.WhiteSmoke;
            pn5.BackColor = Color.WhiteSmoke;
            pn6.BackColor = Color.WhiteSmoke;
            pn7.BackColor = Color.WhiteSmoke;
            pn1.BackColor = Color.WhiteSmoke;
            pn9.BackColor = Color.WhiteSmoke;
            pn10.BackColor = Color.WhiteSmoke;

            lbl2.ForeColor = Color.WhiteSmoke;
            lbl3.ForeColor = Color.WhiteSmoke;
            lbl4.ForeColor = Color.WhiteSmoke;
            lbl5.ForeColor = Color.WhiteSmoke;
            lbl6.ForeColor = Color.WhiteSmoke;
            lbl7.ForeColor = Color.WhiteSmoke;
            lbl1.ForeColor = Color.WhiteSmoke;
            lbl9.ForeColor = Color.WhiteSmoke;
            lbl10.ForeColor = Color.WhiteSmoke;
        }

        private void txtcategories_Edit_Enter(object sender, EventArgs e)
        {
            pn9.BackColor = Color.FromArgb(78, 184, 206);
            lbl9.ForeColor = Color.FromArgb(78, 184, 206);

            pn2.BackColor = Color.WhiteSmoke;
            pn3.BackColor = Color.WhiteSmoke;
            pn4.BackColor = Color.WhiteSmoke;
            pn5.BackColor = Color.WhiteSmoke;
            pn6.BackColor = Color.WhiteSmoke;
            pn7.BackColor = Color.WhiteSmoke;
            pn8.BackColor = Color.WhiteSmoke;
            pn1.BackColor = Color.WhiteSmoke;
            pn10.BackColor = Color.WhiteSmoke;

            lbl2.ForeColor = Color.WhiteSmoke;
            lbl3.ForeColor = Color.WhiteSmoke;
            lbl4.ForeColor = Color.WhiteSmoke;
            lbl5.ForeColor = Color.WhiteSmoke;
            lbl6.ForeColor = Color.WhiteSmoke;
            lbl7.ForeColor = Color.WhiteSmoke;
            lbl8.ForeColor = Color.WhiteSmoke;
            lbl1.ForeColor = Color.WhiteSmoke;
            lbl10.ForeColor = Color.WhiteSmoke;
        }

        private void textBox2_Enter(object sender, EventArgs e)
        {
            pn10.BackColor = Color.FromArgb(78, 184, 206);
            lbl10.ForeColor = Color.FromArgb(78, 184, 206);

            pn2.BackColor = Color.WhiteSmoke;
            pn3.BackColor = Color.WhiteSmoke;
            pn4.BackColor = Color.WhiteSmoke;
            pn5.BackColor = Color.WhiteSmoke;
            pn6.BackColor = Color.WhiteSmoke;
            pn7.BackColor = Color.WhiteSmoke;
            pn8.BackColor = Color.WhiteSmoke;
            pn9.BackColor = Color.WhiteSmoke;
            pn1.BackColor = Color.WhiteSmoke;

            lbl2.ForeColor = Color.WhiteSmoke;
            lbl3.ForeColor = Color.WhiteSmoke;
            lbl4.ForeColor = Color.WhiteSmoke;
            lbl5.ForeColor = Color.WhiteSmoke;
            lbl6.ForeColor = Color.WhiteSmoke;
            lbl7.ForeColor = Color.WhiteSmoke;
            lbl8.ForeColor = Color.WhiteSmoke;
            lbl9.ForeColor = Color.WhiteSmoke;
            lbl1.ForeColor = Color.WhiteSmoke;
        }



        #endregion

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Choose Image(*.jpg; *.png; *.gif)|*.jpg; *.png; *.gif| All Files *.*|*.*";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                imgLocation_edit = ofd.FileName.ToString();
                pbImage_edit.ImageLocation = imgLocation_edit;
            }
        }

        private void dgvAdd_edit_SelectionChanged(object sender, EventArgs e)
        {
            txtISBN_edit.Text = "";
            txtBookTittle_edit.Text = "";
            txtAuthor_Edit.Text = "";
            txtcategories_Edit.Text = "";
            string rbstatus0 = "";
            //txtPublish_Edit.Text = "";
            int quantity_Edit = Convert.ToInt32(nudQuantity_Edit.Value);



            txtISBN_edit.Text = dgvAdd_edit.Rows[dgvAdd_edit.CurrentCell.RowIndex].Cells[0].Value.ToString();
            txtBookTittle_edit.Text = dgvAdd_edit.Rows[dgvAdd_edit.CurrentCell.RowIndex].Cells[1].Value.ToString();
            txtAuthor_Edit.Text = dgvAdd_edit.Rows[dgvAdd_edit.CurrentCell.RowIndex].Cells[2].Value.ToString();
            txtcategories_Edit.Text = dgvAdd_edit.Rows[dgvAdd_edit.CurrentCell.RowIndex].Cells[3].Value.ToString();
            rbstatus0 = dgvAdd_edit.Rows[dgvAdd_edit.CurrentCell.RowIndex].Cells[4].Value.ToString();


            if (rbstatus0 == "Active")
            {
                rbActive_edit.Checked = true;
            }
            else if (rbstatus0 == "Lost")
            {
                rbLost_Edit.Checked = true;

            }


            if (dgvAdd_edit.SelectedRows.Count > 0)
            {
               
                string CurrentBID = dgvAdd_edit.Rows[dgvAdd_edit.CurrentCell.RowIndex].Cells[0].Value.ToString();
                if (CurrentBID != null)
                {
                    pbImage_edit.Image = null;
                    rtbDescription_edit.Text = "";
                    txtPublish_Edit.Text = "";
                    nudQuantity_Edit.Value = 0;

                    try
                    {
                        conn.Open();
                        MySqlDataAdapter query = new MySqlDataAdapter("Select Book_Publish, Book_quantity, Book_Description , Book_Image   From table_inventorybooks Where ISBN_no = " + CurrentBID, conn);
                        DataTable dt = new DataTable();
                        query.Fill(dt);


                        string dpublish = dt.Rows[0].ItemArray[0].ToString();
                        string description = dt.Rows[0].ItemArray[2].ToString();
                        int quantity = Convert.ToInt32(dt.Rows[0].ItemArray[1].ToString());


                        txtPublish_Edit.Text = dpublish;
                        rtbDescription_edit.Text = description;
                        nudQuantity_Edit.Value = quantity;

                        byte[] image = (byte[])dt.Rows[0].ItemArray[3];
                        MemoryStream ms = new MemoryStream(image);
                        pbImage_edit.Image = Image.FromStream(ms);

                    }
                    catch (Exception ex)
                    { }
                    conn.Close();
                }
            }
        }
    }
}
