﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace WindowsFormsApp1
{
    public partial class ForgotPassword : Form
    {


       MySqlConnection conn = new MySqlConnection("server=127.0.0.1;port=3306;username=root;password=root123;database=librarydb");

        public ForgotPassword()
        {
            InitializeComponent();
        }

        private void ForgotPassword_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string userinput = txtUserName.Text;
            string answerinput = txtAnswer.Text;
            string newpass = txtNewPass.Text;
            string confirmpass = txtConfirmPass.Text;



            //try
            //{
            //    string sqlquery = "Select * From table_account";
            //    conn.Open();
            //    MySqlCommand command = new MySqlCommand(sqlquery, conn);
            //    MySqlDataReader reader = command.ExecuteReader();

            //    while (reader.Read())
            //    {
            //        string dbuser;
            //        string dbanswer;

            //        dbuser = (reader.GetString("Username"));
            //        dbanswer = (reader.GetString("Answer"));

            //        if (dbuser == userinput && dbanswer == answerinput && newpass == confirmpass)
            //        {
            //            conn.Close();
            //            try
            //            {
            //                conn.Open();
            //                MySqlCommand cmd = new MySqlCommand("Update table_account SET Password = '" + newpass + "' Where Username = '" + userinput + "' And Answer = '" + answerinput + "' ", conn);
            //                cmd.ExecuteNonQuery();
            //                MessageBox.Show("Password Change Successfully");

            //            }
            //            catch (Exception ex)
            //            {
            //                MessageBox.Show("" + ex);
            //            }

            //        }

            //    }
            //    conn.Close();
            //}
            //catch (Exception ex)
            //{
            //}





            //if (newpass == confirmpass) 
            //{
            //    try
            //    {
            //        conn.Open();
            //        MySqlCommand cmd = new MySqlCommand("Update table_account SET Password = '" + newpass + "' Where Username = '" + userinput + "' And Answer = '" + answerinput + "' ", conn);
            //        cmd.ExecuteNonQuery();
            //        //MessageBox.Show("NO error");
            //        conn.Close();
            //    }
            //    catch (Exception ex)
            //    {
            //        MessageBox.Show("" + ex);
            //    }
            //}
            //else
            //{
            //    MessageBox.Show("New Password and confirmpass Not match!");
            //}


            //try
            //{
            //    conn.Open();
            //    MySqlCommand cmd = new MySqlCommand("Update table_account SET Password = if(Username = '"+userinput+"' and Answer = '"+answerinput+"' , Password) WHERE Username  = '"+userinput+"'",  conn);


            //    //cmd.Parameters.AddWithValue("@pass", newpass);
            //    cmd.ExecuteNonQuery();
            //    MessageBox.Show("Change Password Succesfully");
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show("" + ex);
            //}
            //conn.Close();
            bool isValid = true;

            string dbuser;
            string dbanswer;

            string sqlquery = "Select * From table_account Where Username = '"+userinput+"' and Answer = '"+answerinput+"'";
            conn.Open();
            MySqlCommand command = new MySqlCommand(sqlquery, conn);
            MySqlDataReader reader = command.ExecuteReader();

            if (reader.Read())
            {
                dbuser = reader.GetString("Username");
                dbanswer = reader.GetString("Answer");
                conn.Close();
                if (isValid && dbuser == userinput && dbanswer == answerinput && newpass == confirmpass)
                {


                    try
                    {
                        conn.Open();
                        MySqlCommand cmd = new MySqlCommand("Update table_account SET Password = '" + newpass + "' Where Username = '" + userinput + "' And Answer = '" + answerinput + "' ", conn);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Password Change Successfully");
                        conn.Close();

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("" + ex);
                    }
                }
                else if (newpass != confirmpass)
                {
                    MessageBox.Show("New Pass and Confirm Pass Not match!!");
                }
            }
            
            else
            {
                MessageBox.Show("Incorrect Username OR Answer!!");
                conn.Close();
            }



            
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Form1 fr = new Form1();
            fr.Show();
            Close();
        }
    }
}
