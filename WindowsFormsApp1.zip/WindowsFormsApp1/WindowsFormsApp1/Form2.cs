﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace WindowsFormsApp1
{
    public partial class ForgotPassword : Form
    {


       MySqlConnection conn = new MySqlConnection("server=127.0.0.1;port=3306;username=root;password=root123;database=librarydb");

        public ForgotPassword()
        {
            InitializeComponent();
        }

        private void ForgotPassword_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            string newpass = txtNewPass.Text;
            string confirmpass = txtConfirmPass.Text;

            if (newpass == confirmpass)
            {
                try
                {
                    conn.Open();
                    MySqlDataAdapter query = new MySqlDataAdapter("Select Password From table_account Where Username = '" + txtUserName.Text + "' ", conn);
                    DataTable dt = new DataTable();
                    query.Fill(dt);

                    string oldpass = dt.Rows[0].ItemArray[0].ToString();

                    if (oldpass == txtOldPass.Text)
                    {
                        try
                        {

                            MySqlCommand cmd = new MySqlCommand("Update table_account SET Password= @pass WHERE Username = '" + txtUserName.Text + "'", conn);

                            cmd.Parameters.AddWithValue("@pass", newpass);
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("Password Change", "Success", MessageBoxButtons.OK, MessageBoxIcon.None);

                            txtOldPass.Text = "";
                            txtNewPass.Text = "";
                            txtConfirmPass.Text = "";

                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("" + ex);
                        }
                        
                    }
                    else if (oldpass != txtOldPass.Text)
                    {
                        MessageBox.Show("Old Password not Match" ,"Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                   
                }
                catch (Exception ex)
                {
                    MessageBox.Show(""+ ex);
                }
                conn.Close();
            }
            else if (txtNewPass.Text != txtConfirmPass.Text)
            {
                MessageBox.Show("New password and Confirm Password Not match", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


            
        }


    }
}
